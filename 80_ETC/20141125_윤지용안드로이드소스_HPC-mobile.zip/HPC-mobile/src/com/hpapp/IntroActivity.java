package com.hpapp;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;

import com.daou.smartpush.ConstValue.ConstValue;
import com.daou.smartpush.servermodel.PushErrorCode;
import com.daou.smartpush.servermodel.callback.IPushServerInterface;
import com.daou.smartpush.smartpushmng.SmartPushManager;
import com.hpapp.activity.HPCActivity;
import com.hpapp.popup.PopupTutorial;
import com.hpapp.res.Const;
import com.hpapp.util.Debug_Log;
import com.hpapp.util.NetworkUtil;
import com.hpapp.util.SharedPref;


public class IntroActivity extends Activity {
	
	private SmartPushManager mSmartPushManager;
	boolean neverShowTutorial;
	String kakaolink, menutype;

    @SuppressLint("NewApi")
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        Debug_Log.Log_E(this, "IntroActivity.onCreate()");
        SharedPref pref = new SharedPref(this, Const.SP_KEY);
        
        // Setting에서 로그아웃시 popupYN을 N으로 해두기 때문에 앱 다시 실행시에는 Y로 바꿔줘야함.
        pref.putSharedPreference(Const.SP_MAINPOPUP, "Y");
        
        neverShowTutorial = pref.getBooleanSharedPreference(Const.SP_NEVER_SHOW_TUTORIAL,false);
        
        // push
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
           	new AsyncPush().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        else
        	new AsyncPush().execute();

        ImageView logo = (ImageView) findViewById(R.id.intro_logo);
        
		Animation anim = new AlphaAnimation(0.0f, 1.0f);
		anim.setAnimationListener(new AnimationListener() {
			
			@Override
			public void onAnimationStart(Animation arg0) {
				// TODO Auto-generated method stub
				// DB파일 복사
				new AsyncCopyDB().execute();
			}
			
			@Override
			public void onAnimationRepeat(Animation arg0) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onAnimationEnd(Animation arg0) {
				// TODO Auto-generated method stub
				
				Intent intent = getIntent();
				String decode_result = "";
				if(Intent.ACTION_VIEW.equals(intent.getAction())) {
					Uri uri = intent.getData();
					try {
						decode_result = URLDecoder.decode(uri.toString(), "UTF-8");
						 Uri uri_encode = Uri.parse(decode_result);
					Const.ACTION_URL = uri_encode.getQueryParameter("actionurl");
					Const.ACTION_TYPE = uri_encode.getQueryParameter("type");
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						Debug_Log.Log_E(this, "UnsupportedEncodingException : " + e.getMessage());
					}
					kakaolink = uri.getQueryParameter("hpeventurl");
					menutype = uri.getQueryParameter("where");
					Debug_Log.Log_E(this, "uri decode_result: " + decode_result);
					Debug_Log.Log_E(this, "uri : " + uri.toString());
					Debug_Log.Log_E(this, "Const.ACTION_TYPE : " + Const.ACTION_TYPE);
					Debug_Log.Log_E(this, "Const.ACTION_URL : " + Const.ACTION_URL);
					Debug_Log.Log_E(this, "kakaolink : " + kakaolink);
					Debug_Log.Log_E(this, "menutype : " + menutype);
					
				}
				
				if(NetworkUtil.chkNetwork(IntroActivity.this) && !neverShowTutorial){
					intent = new Intent(IntroActivity.this, PopupTutorial.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.putExtra("kakaolink", kakaolink);
					intent.putExtra("params", getIntent().getStringExtra("params"));
					intent.putExtra("seq", getIntent().getStringExtra("seq"));
					intent.putExtra("callMain", true);
					intent.putExtra("where", menutype);
					startActivity(intent);
					overridePendingTransition(0,0);
				}else{
					intent = new Intent(IntroActivity.this, HPCActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.putExtra("kakaolink", kakaolink);
					intent.putExtra("params", getIntent().getStringExtra("params"));
					intent.putExtra("seq", getIntent().getStringExtra("seq"));
					intent.putExtra(ConstValue.IntentKey.MSG_TAG, getIntent().getStringExtra(ConstValue.IntentKey.MSG_TAG));
					intent.putExtra("where", menutype);
					startActivity(intent);
					overridePendingTransition(R.anim.alpha_show, R.anim.alpha_hide);
				}
				finish();
			}
		});
		anim.setFillEnabled(true);
		anim.setFillAfter(true);
        anim.setDuration(1000);
        logo.startAnimation(anim);
    }

    /**
     * asset폴더의 DB파일을 복사한다.
     */
    private class AsyncCopyDB extends AsyncTask<Void, Void, Boolean>{

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
//			progressDialog = ProgressDialog.show(getDialogContext(), "", "초기데이터 생성중입니다...", true, true);
		}
    	
		@Override
		protected Boolean doInBackground(Void... params) {
			// TODO Auto-generated method stub
			AssetManager am = getBaseContext().getResources().getAssets();
			
			// copy for dbFile
			String dbFile = getBaseContext().getDatabasePath("happypoint.db").getPath();
			String dbDir = dbFile.substring(0, dbFile.lastIndexOf("/"));
			File dir = new File(dbDir);
			File f = new File(dbFile);
			
			if(!dir.exists())
				dir.mkdirs();
			
			FileOutputStream fos = null;
			BufferedOutputStream bos = null;
			InputStream is = null;
			BufferedInputStream bis = null;
			try{
				is = am.open("happypoint.db", AssetManager.ACCESS_BUFFER);
				bis = new BufferedInputStream(is);
	 
				if(f.length()!=is.available()){
					if (f.exists()) {
						// 만약에 파일이 있다면 지우고 다시 생성
						f.delete();
						f.createNewFile();
					}else{
						f = new File(dbFile);
					}
					
					fos = new FileOutputStream(f);
					bos = new BufferedOutputStream(fos);
		 
					int read = -1;
					byte[] buffer = new byte[1024];

					while ((read = bis.read(buffer, 0, 1024)) != -1) {
						bos.write(buffer, 0, read);
					}
					bos.flush();
		 
					bis.close();
					is.close();
					bos.close();
					fos.close();
				}
			}catch(IOException e){
				e.printStackTrace();
				return false;
			}finally{
				if( bis != null ){
					try {
						bis.close();
					} catch (IOException e) {}
				}
				if( is != null ){
					try {
						is.close();
					} catch (IOException e) {}
				}
				if( bos != null ){
					try {
						bos.close();
					} catch (IOException e) {}
				}
				if( fos != null ){
					try {
						fos.close();
					} catch (IOException e) {}
				}
			}
			// end of copy
			
			return true;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result){
//				progressDialog.dismiss();
			}
		}
    }
    
    private class AsyncPush extends AsyncTask<Void, Void, Void>{

    	@Override
    	protected void onPreExecute() {
    		// TODO Auto-generated method stub
    		super.onPreExecute();
    	}
    	
		@Override
		protected Void doInBackground(Void... arg0) {
			// TODO Auto-generated method stub
			
			// push에 대한 관리를 하는 manager 객체를 얻어 옵니다.
	        mSmartPushManager = SmartPushManager.getInstance();

	        mSmartPushManager.setOnRegistrationListener(mIregistraionServerInterface, IntroActivity.this);
	        // device를 등록 하고 service를 시작하는 과정 입니다. (app 실행시마다 실행하여야 합니다.)
	        mSmartPushManager.start(IntroActivity.this);
			
	        return null;
		}
    	
		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
		}
		
	    /**
	     * pushServer device(regId 등록 ) 결과 Listener 입니다.
	     */
	    private IPushServerInterface mIregistraionServerInterface = new IPushServerInterface() {
	    	@Override
	    	public String getResponseResult() {
	    		return null;
	    	}

	    	@Override
	    	public Object getResponseObject() {
	    		return null;
	    	}

	    	@Override
	    	public void sendResult(String result, Object obj) {

			    if (result.equals(PushErrorCode.RESULT_CODE_200) || result.equals(PushErrorCode.RESULT_CODE_201)) {
			    // RESULT_CODE_200 : 처음으로 device 등록할때 result code 입니다.
			    // RESULT_CODE_201 : 이미 device가 등록 되어 있을때 result code 입니다.
			    // Device정보와 Push 발송을 위한 Mapping정보 전달 
//			    	
//			    	SharedPref pref = new SharedPref(IntroActivity.this, Const.SP_KEY);
//			    	UserBean user = HappyPointSync.user;
//			    	boolean isAuth = pref.getBooleanSharedPreference(Const.SP_AUTH);
//			    	
//					String card_no="", hpc_no="";
//					if(user!=null){
//						card_no = pref.getSharedPreference(Const.SP_CARDNO);
//						hpc_no = user.getUserNo();
//						mSmartPushManager.setUserMappingKey(mIsetMappingKeyServerInterface, hpc_no, card_no, IntroActivity.this);
//					}

	            } else {
	                    // error code 참조
	            	Log.i("PUSH ERROR", "user mapping key 설정을 하지 못했습니다.");
	            }
	    	}
	    };
    }

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Debug_Log.Log_E(this, "IntroActivity.onResume() ");
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		Debug_Log.Log_E(this, "IntroActivity.onPause() ");
		finish();
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Debug_Log.Log_E(this, "IntroActivity.onDestroy() ");
	}
}
