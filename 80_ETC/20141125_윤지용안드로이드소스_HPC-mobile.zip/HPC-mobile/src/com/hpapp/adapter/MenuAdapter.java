package com.hpapp.adapter;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.UUID;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hpapp.R;
import com.hpapp.activity.HPCActivity;
import com.hpapp.activity.HPCWebActivity;
import com.hpapp.activity.LoginActivity;
import com.hpapp.activity.SettingActivity;
import com.hpapp.bean.UserBean;
import com.hpapp.popup.PopupTutorial;
import com.hpapp.res.Const;
import com.hpapp.util.Debug_Log;
import com.hpapp.util.NetworkUtil;
import com.hpapp.util.SEEDUtil;
import com.hpapp.util.SharedPref;
import com.hpapp.util.StringUtils;

public class MenuAdapter {

	public static Activity activity;
	public static ImageButton menuCard, menuPoint, menuEvent, menuGift, menuMore, menuClub, menuCoupon, menuInfo, menuSetting, menuGuide;
	public static ImageView newEvent, newHappy, newNotice, newVersion, newGift;
	public static LinearLayout menuMain, menuSub;
	public static TextView titleTop;
	public static boolean isMoving, statusOpen, clicked;
	public static String delegateUrl;
	public static int menuHeight;
	public static Handler mHdlr = new Handler(Looper.myLooper()){
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch(msg.what)
			{
			case 99:
//				activity.onBackPressed();
				break;
			}
		}
	};

	public static void setBottomMenu(Activity act, View view){
		activity = act;
		
		menuCard = (ImageButton) view.findViewById(R.id.menu_card);
		menuPoint = (ImageButton) view.findViewById(R.id.menu_point);
		menuEvent = (ImageButton) view.findViewById(R.id.menu_event);
		menuGift = (ImageButton) view.findViewById(R.id.menu_gift);
		menuMore = (ImageButton) view.findViewById(R.id.menu_more);
		menuClub = (ImageButton) view.findViewById(R.id.menu_happyclub);
		menuCoupon = (ImageButton) view.findViewById(R.id.menu_coupon);
		menuInfo = (ImageButton) view.findViewById(R.id.menu_introduce);
		menuSetting = (ImageButton) view.findViewById(R.id.menu_setting);
		menuMain = (LinearLayout) view.findViewById(R.id.menu_main);
		menuSub = (LinearLayout) view.findViewById(R.id.menu_sub);
		
		menuCard.setOnClickListener(menuListener);
		menuPoint.setOnClickListener(menuListener);
		menuEvent.setOnClickListener(menuListener);
		menuGift.setOnClickListener(menuListener);
		menuMore.setOnClickListener(menuListener);
		menuClub.setOnClickListener(menuListener);
		menuCoupon.setOnClickListener(menuListener);
		menuInfo.setOnClickListener(menuListener);
		menuSetting.setOnClickListener(menuListener);

		menuGuide = (ImageButton) view.findViewById(R.id.menu_guide);
		menuGuide.setOnClickListener(menuListener);
		
		newEvent = (ImageView) view.findViewById(R.id.new_event);
		newHappy = (ImageView) view.findViewById(R.id.new_happy);
		newNotice = (ImageView) view.findViewById(R.id.new_notice);
		newVersion = (ImageView) view.findViewById(R.id.new_version);
		newGift = (ImageView) view.findViewById(R.id.new_gift);
		
		setNewIcon();
	}
	
	public static OnClickListener menuListener = new OnClickListener() {
		@Override
		public void onClick(View v){
			// TODO Auto-generated method stub
			Debug_Log.Log_E(this, "MenuAdapter.OnClickListener()");
			if(isMoving || clicked){
				return;
			}
			clicked = true;
			
			new Handler().postDelayed(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					// 더블클릭 방지
					clicked = false;
				}
			}, 1000);
			
			SharedPref pref = new SharedPref(activity, Const.SP_KEY);
			UserBean user = HappyPointSync.user;

			Const.CURRENT_TAB = v.getId();
			Intent intent = null;
			

			NetworkUtil netUtil = new NetworkUtil(activity, mHdlr);
			if(R.id.menu_more == v.getId()){
				if(menuSub.getVisibility()==View.VISIBLE){
					menuMore(false);
				}else{
					menuMore(true);
				}
				return;
			}else if(R.id.menu_card == v.getId()){
				intent = new Intent(activity, HPCActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
				activity.startActivity(intent);
				return;
			}else{
				if(!netUtil.checkNetwokState())
					return;
			}
			
			boolean isAuth = pref.getBooleanSharedPreference(Const.SP_AUTH);
			Debug_Log.Log_E(this, "MenuAdapter.OnClickListener().isAuth : " + isAuth);
			if(isAuth){
				String url="", param="";
				String phoneNum = "", userId = "", userPwd="", userName = "", cardNo="", mberNo="";

				if(user!=null){
//					userId = pref.getSharedPreference(Const.SP_ID);
//					userPwd = pref.getSharedPreference(Const.SP_PWD);
					mberNo = user.getUserNo();
					userId = user.getUserId();
					userPwd = user.getUserPwd();
					userName = user.getUserName();
					phoneNum = user.getPhoneNumber();
					cardNo = pref.getSharedPreference(Const.SP_CARDNO);
//					cardNo = user.getMobileCardNo();
				}else{
					Debug_Log.Log_E(this, "MenuAdapter.OnClickListener().user==null ");
					intent = new Intent(activity, LoginActivity.class);
					intent.putExtra("menuId", v.getId());
					activity.startActivityForResult(intent, Const.REQ_LOGIN_SUBMENU);
				}
				
				switch(v.getId())
				{
				case R.id.menu_point:
					url = Const.LINK_MY_POINT;
					try {
						if (!StringUtils.isEmpty(delegateUrl)) {
							url = delegateUrl;
							delegateUrl = null;
						}
//						param = "W_ID="+userId+"&W_PASSWD="+URLEncoder.encode(userPwd,"euc-kr")+"&W_NAME="+userName+"&mdn="+phoneNum;
						param = "W_ID=" + userId + "&W_PASSWD=" + URLEncoder.encode(SEEDUtil.encrypt(userPwd), "utf-8") + "&W_NAME=" + userName + "&mdn=" + phoneNum + "&hpcNo=" + mberNo + "&verA="
								+ getVersionCode() + "&cardnum=" + cardNo;
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					intent = new Intent(activity, HPCWebActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					intent.putExtra("url", url);
					intent.putExtra("param", param);
					if(activity.getClass()==HPCWebActivity.class){
						activity.finish();
					}
					activity.startActivity(intent);
					break;
				case R.id.menu_event:
					url = Const.LINK_EVENT;
					
					if(!StringUtils.isEmpty(delegateUrl)){
						url = delegateUrl;
						delegateUrl = null;
					}
					param = "W_ID="+userId+"&cardnum="+cardNo + "&verA=" + getVersionCode()+"&hpcNo="+mberNo;
					
					intent = new Intent(activity, HPCWebActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					intent.putExtra("url", url);
					intent.putExtra("param", param);
					if(activity.getClass()==HPCWebActivity.class){
						activity.finish();
					}
					activity.startActivity(intent);
					if(Const.ISNEW_EVENT){
						pref.putSharedPreference(Const.SP_EVENT_KEY, Const.ISNEW_EVENT_KEY);
						Const.ISNEW_EVENT=false;
					}
					break;
				case R.id.menu_gift:
					url = Const.LINK_GIFT;
					if(!StringUtils.isEmpty(delegateUrl)){
						url = delegateUrl;
						delegateUrl = null;
						Debug_Log.Log_E(this, "LINK_GIFT.delegateUrl : "  +delegateUrl);
					}
					
					param = "mbNo="+mberNo+"&cardnum="+cardNo+"&buyerMdn="+phoneNum+"&type=P";
//					param = "W_ID="+userId+"&token="+getDevicesUUID(activity)+"&term=A&buyerMdn="+phoneNum+"&W_NAME="+userName;
					
					intent = new Intent(activity, HPCWebActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					intent.putExtra("url", url);
					intent.putExtra("param", param);
					if(activity.getClass()==HPCWebActivity.class){
						activity.finish();
					}
					activity.startActivity(intent);
					if(Const.ISNEW_GIFT) {
						pref.putSharedPreference(Const.SP_GIFT_KEY, Const.ISNEW_GIFT_KEY);
						Const.ISNEW_GIFT = false;
					}
					menuSelected();
					break;
				case R.id.menu_happyclub:
					url = Const.LINK_HAPPYCLUB;
					if (!StringUtils.isEmpty(delegateUrl)) {
						url = delegateUrl;
						delegateUrl = null;
					}
					intent = new Intent(activity, HPCWebActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					intent.putExtra("url", url);
					intent.putExtra("param", param);
					if(activity.getClass()==HPCWebActivity.class){
						activity.finish();
					}
					activity.startActivity(intent);
					if(Const.ISNEW_HAPPY){
						Const.ISNEW_HAPPY=false;
					}
					break;
				case R.id.menu_coupon:
					url = Const.LINK_COUPON;
					if (!StringUtils.isEmpty(delegateUrl)) {
						url = delegateUrl;
						delegateUrl = null;
					}
					param = "W_ID="+userId+"&cardnum="+cardNo;

					intent = new Intent(activity, HPCWebActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					intent.putExtra("url", url);
					intent.putExtra("param", param);
					if(activity.getClass()==HPCWebActivity.class){
						activity.finish();
					}
					activity.startActivity(intent);
					break;
				case R.id.menu_introduce:
					url = Const.LINK_INFO;
					// 튜토리얼 메뉴 보이기(version=1)
					param = "version=1";

					if(!StringUtils.isEmpty(delegateUrl)){
						url = delegateUrl;
						delegateUrl = null;
					}

					intent = new Intent(activity, HPCWebActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					intent.putExtra("url", url);
					intent.putExtra("param", param);
					if(activity.getClass()==HPCWebActivity.class){
						activity.finish();
					}
					activity.startActivity(intent);
					if(Const.ISNEW_NOTICE){
						pref.putSharedPreference(Const.SP_NOTICE_KEY, Const.ISNEW_NOTICE_KEY);
						Const.ISNEW_NOTICE=false;
					}
					break;
				case R.id.menu_setting:
					intent = new Intent(activity, SettingActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					activity.startActivity(intent);
					if(Const.ISNEW_VERSION){
						Const.ISNEW_VERSION=false;
					}
					break;
				case R.id.btn_game:
					url = Const.LINK_HAPPYRANK;
					
					intent = new Intent(activity, HPCWebActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					intent.putExtra("url", url);
					intent.putExtra("param", param);
					if(activity.getClass()==HPCWebActivity.class){
						activity.finish();
					}
					activity.startActivity(intent);
					break;
				case R.id.menu_guide:
					intent = new Intent(activity, PopupTutorial.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.putExtra("callMain", false);
					activity.startActivity(intent);
					break;
				}
			}else{
				String url="", param="";
				
				switch(v.getId())
				{
				case R.id.menu_point:
					String userName = pref.getSharedPreference(Const.SP_NAME);
					String ci = pref.getSharedPreference(Const.SP_CI);

					if(!StringUtils.isEmpty(ci)){
						try {
							url = Const.LINK_MY_POINT;
							param = "W_NAME="+URLEncoder.encode(userName,"utf-8")+"&W_CI="+URLEncoder.encode(ci,"utf-8");
						} catch (UnsupportedEncodingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						intent = new Intent(activity, HPCWebActivity.class);
						intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
						intent.putExtra("url", url);
						intent.putExtra("param", param);
						if(activity.getClass()==HPCWebActivity.class){
							activity.finish();
						}
						activity.startActivity(intent);
					}else{
						Debug_Log.Log_E(this, "MenuAdapter.OnClickListener().StringUtils.isEmpty(ci ");
						intent = new Intent(activity, LoginActivity.class);
						intent.putExtra("menuId", v.getId());
						activity.startActivityForResult(intent, Const.REQ_LOGIN_SUBMENU);
					}
					break;
				case R.id.menu_introduce:
					url = Const.LINK_INFO;
					// 튜토리얼 메뉴 보이기(version=1)
					param = "version=1";

					if(!StringUtils.isEmpty(delegateUrl)){
						url = delegateUrl;
						delegateUrl = null;
					}

					intent = new Intent(activity, HPCWebActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					intent.putExtra("url", url);
					intent.putExtra("param", param);
					if(activity.getClass()==HPCWebActivity.class){
						activity.finish();
					}
					activity.startActivity(intent);
					if(Const.ISNEW_NOTICE){
						pref.putSharedPreference(Const.SP_NOTICE_KEY, Const.ISNEW_NOTICE_KEY);
						Const.ISNEW_NOTICE=false;
					}
					break;
				case R.id.menu_guide:
					intent = new Intent(activity, PopupTutorial.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.putExtra("callMain", false);
					activity.startActivity(intent);
					
					// SNS이벤트 테스트
//					url = Const.LINK_TEST_SNS;
//					
//					intent = new Intent(activity, HPCWebActivity.class);
//					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
//					intent.putExtra("url", url);
//					intent.putExtra("param", param);
//					if(activity.getClass()==HPCWebActivity.class){
//						activity.finish();
//					}
//					activity.startActivity(intent);
					break;
				default:
					Debug_Log.Log_E(this, "MenuAdapter.OnClickListener().default ");
					intent = new Intent(activity, LoginActivity.class);
					intent.putExtra("menuId", v.getId());
					activity.startActivityForResult(intent, Const.REQ_LOGIN_SUBMENU);
				}
				
				// 아이콘 카운트 초기화
//		    	int count=0;
//		    	intent = new Intent("android.intent.action.BADGE_COUNT_UPDATE");
//		    	intent.putExtra("badge_count", count);
//		    	intent.putExtra("badge_count_package_name", "com.hpapp");
//		    	intent.putExtra("badge_count_class_name","com.hpapp.IntroActivity");
//		    	activity.sendBroadcast(intent);

				// SNS이벤트 테스트
//				url = Const.LINK_EVENT_SNS;
//				
//				intent = new Intent(activity, HPCWebActivity.class);
//				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//				intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
//				intent.putExtra("url", url);
//				intent.putExtra("param", param);
//				if(activity.getClass()==HPCWebActivity.class){
//					activity.finish();
//				}
//				activity.startActivity(intent);

			}
			activity.overridePendingTransition(0, 0);
		}
	};
	
	private static void menuMore (final boolean viewMore){
		Animation ani = null;

		if(menuHeight==0)
			menuHeight = menuSub.getMeasuredHeight();
		
		if(viewMore){
			ani = new TranslateAnimation(0, 0, 0, -menuHeight);
		}else{
			ani = new TranslateAnimation(0, 0, 0, menuHeight);
		}
		ani.setFillEnabled(true);
		ani.setFillBefore(true);
		ani.setDuration(500);
		ani.setAnimationListener(new AnimationListener() {
			@Override
			public void onAnimationStart(Animation arg0) {
				// TODO Auto-generated method stub
				if(viewMore){
					menuSub.setVisibility(View.VISIBLE);
				}
				isMoving = true;
			}
			
			@Override
			public void onAnimationRepeat(Animation arg0) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void onAnimationEnd(Animation arg0) {
				// TODO Auto-generated method stub
				if(!viewMore){
					menuSub.setVisibility(View.INVISIBLE);
					RelativeLayout.LayoutParams param = new RelativeLayout.LayoutParams(menuMain.getLayoutParams());
					param.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
					menuMain.setLayoutParams(param);
					statusOpen = false;
				}else{
					RelativeLayout.LayoutParams param = new RelativeLayout.LayoutParams(menuMain.getLayoutParams());
					param.addRule(RelativeLayout.ABOVE, R.id.menu_sub);
					menuMain.setLayoutParams(param);
					statusOpen = true;
				}
				isMoving = false;
			}
		});
		menuMain.startAnimation(ani);
	}
	
	public static void menuSelected(){
		menuCard.setSelected(false);
		menuPoint.setSelected(false);
		menuEvent.setSelected(false);
		menuGift.setSelected(false);
		menuClub.setSelected(false);
		menuCoupon.setSelected(false);
		menuInfo.setSelected(false);
		menuSetting.setSelected(false);

		switch(Const.CURRENT_TAB)
		{
		case R.id.menu_card:
			menuCard.setSelected(true);
			break;
		case R.id.menu_point:
			if(titleTop!=null)
				titleTop.setText("MY메뉴");
			menuPoint.setSelected(true);
			break;
		case R.id.menu_event:
			if(titleTop!=null)
				titleTop.setText("이벤트");
			menuEvent.setSelected(true);
			break;
		case R.id.menu_gift:
			if(titleTop!=null)
				titleTop.setText("선물하기");
			menuGift.setSelected(true);
			break;
		case R.id.menu_happyclub:
			if(titleTop!=null)
				titleTop.setText("해피클럽");
			menuClub.setSelected(true);
			break;
		case R.id.menu_coupon:
			if(titleTop!=null)
				titleTop.setText("적립쿠폰");
			menuCoupon.setSelected(true);
			break;
		case R.id.menu_introduce:
			if(titleTop!=null)
				titleTop.setText("안내");
			menuInfo.setSelected(true);
			break;
		case R.id.menu_setting:
			if(titleTop!=null)
				titleTop.setText("설정");
			menuSetting.setSelected(true);
			break;
		case R.id.btn_game:
			if(titleTop!=null)
				titleTop.setText("해피클럽");
			menuClub.setSelected(true);
			break;
		case R.id.btn_point:
			if(titleTop!=null)
				titleTop.setText("MY메뉴");
			menuPoint.setSelected(true);
			break;
		case R.id.top_btn_prepaid:
			if(titleTop!=null)
				titleTop.setText("던킨");
			menuCard.setSelected(false);
			menuPoint.setSelected(false);
			menuEvent.setSelected(false);
			menuGift.setSelected(false);
			menuClub.setSelected(false);
			menuCoupon.setSelected(false);
			menuInfo.setSelected(false);
			menuSetting.setSelected(false);
			break;
		}
		
		if(statusOpen){
			menuMore(false);
		}else{
			menuSub.setVisibility(View.INVISIBLE);
			RelativeLayout.LayoutParams param = new RelativeLayout.LayoutParams(menuMain.getLayoutParams());
			param.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
			menuMain.setLayoutParams(param);
		}
	}
	
	/**
	 * 신규 아이템 N표시
	 */
	public static void setNewIcon(){
		if(Const.ISNEW_EVENT)
			newEvent.setVisibility(ImageView.VISIBLE);
		else
			newEvent.setVisibility(ImageView.GONE);
		if(Const.ISNEW_HAPPY)
			newHappy.setVisibility(ImageView.VISIBLE);
		else
			newHappy.setVisibility(ImageView.GONE);
		if(Const.ISNEW_NOTICE)
			newNotice.setVisibility(ImageView.VISIBLE);
		else
			newNotice.setVisibility(ImageView.GONE);
		if(Const.ISNEW_VERSION)
			newVersion.setVisibility(ImageView.VISIBLE);
		else
			newVersion.setVisibility(ImageView.GONE);
		if(Const.ISNEW_GIFT)
			newGift.setVisibility(ImageView.VISIBLE);
		else
			newGift.setVisibility(ImageView.GONE);
	}
	
	/**
	 * UUID 생성
	 * @param mContext
	 * @return
	 */
	private static String getDevicesUUID(Context mContext){
		final TelephonyManager tm = (TelephonyManager) mContext.getSystemService(Context.TELEPHONY_SERVICE);
		final String tmDevice, tmSerial, androidId;

		tmDevice = "" + tm.getDeviceId();
		tmSerial = "" + tm.getSimSerialNumber();
		androidId = "" + android.provider.Settings.Secure.getString(mContext.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);

		UUID deviceUuid = new UUID(androidId.hashCode(), ((long)tmDevice.hashCode() << 32) | tmSerial.hashCode());

		String deviceId = deviceUuid.toString();
		return deviceId;
	}

	public static void setHeaderTextview(TextView tv){
		titleTop = tv;
	}
	
	public static void performClick(int menuId, String url){
		Debug_Log.Log_E(activity, "performClick().menuId : " + menuId);
		Debug_Log.Log_E(activity, "performClick().url : " + url);
		if(!StringUtils.isEmpty(url)){
			if(url.startsWith("http://") || url.startsWith("https://"))
				delegateUrl = url;
			else
				delegateUrl = Const.HOST_URL_SPC+url;
		}
		Debug_Log.Log_E(activity, "performClick().delegateUrl : " + delegateUrl);
		if(menuId == Const.MENU_ID_CARD){
			menuCard.performClick();
		}else if(menuId == Const.MENU_ID_POINT){
			menuPoint.performClick();
		}else if(menuId == Const.MENU_ID_EVENT){
			menuEvent.performClick();
		}else if(menuId == Const.MENU_ID_GIFT){
			menuGift.performClick();
		}else if(menuId == Const.MENU_ID_CLUB){
			menuClub.performClick();
		}else if(menuId == Const.MENU_ID_COUPON){
			menuCoupon.performClick();
		}else if(menuId == Const.MENU_ID_INFO){
			menuInfo.performClick();
		}else if(menuId == Const.MENU_ID_SETTING){
			menuSetting.performClick();
		}else if(menuId == Const.MENU_ID_DUNKIN){
			UserBean user = HappyPointSync.user;
			String urlStr = Const.HOST_URL_DUNKIN;
			SharedPref pref = new SharedPref(activity, Const.SP_KEY);
			if (user != null) {
				Const.CURRENT_TAB = R.id.top_btn_prepaid;
				Debug_Log.Log_E(activity, "HPCActivty.prepaid.OnClickListener()HOST_URL_DUNKIN");
				String	mberNo = user.getUserNo();
				String phoneNum = user.getPhoneNumber();
				String cardNo = pref.getSharedPreference(Const.SP_CARDNO);
				
				String param = "mbNo="+mberNo+"&cardnum="+cardNo+"&buyerMdn="+phoneNum;
				
				Intent intent = new Intent(activity, HPCWebActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
				intent.putExtra("url", urlStr);
				intent.putExtra("param", param);
				activity.startActivity(intent);
			} else if (HappyPointSync.user == null) {
				Debug_Log.Log_E(activity, "HPCActivty.prepaid.OnClickListener() -> Login");
				Intent intent = new Intent(activity, LoginActivity.class);
				activity.startActivity(intent);
			}
		}
	}
	
	// 현재 어플 버전코드 가져오기
	public static String getVersionCode(){
		String version = "";
		try 
		{
		    PackageManager packageManager = activity.getPackageManager();
		    PackageInfo info =  packageManager.getPackageInfo(activity.getPackageName(), PackageManager.GET_META_DATA);
		    version = info.versionName;
		    int code = info.versionCode;
		    
		    Log.d("versionInfo", "version = " + version + ", code = " + code);
		 } 
		catch(NameNotFoundException e) 
		{
			e.printStackTrace();
		 }

		return version;
	}
	
}
