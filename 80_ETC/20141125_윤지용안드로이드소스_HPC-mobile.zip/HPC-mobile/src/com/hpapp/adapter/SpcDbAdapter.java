package com.hpapp.adapter;

import java.util.Map;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.hpapp.util.StringUtils;

public class SpcDbAdapter {

//	public static final String[] COLUMN_STOREINFO = {"shop_id","brand_name","brand_area","address","tel","latitude","longitude","open_date"};
	public static final String[] COLUMN_STOREINFO = {"shop_id","brand_code","brand_name","brand_area","city","district","tel","zipcode","address","address_new","ktec_x","ktec_y","latitude","longitude"};
	private static final String TAG = "SPCDBAdapter";
	private DatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;

	/**
	 * 
	 * Database creation sql statement
	 */
	private static final String DATABASE_NAME = "happypoint.db";
	private static final int DATABASE_VERSION = 4;
	private final Context mCtx;

	private static class DatabaseHelper extends SQLiteOpenHelper {

		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			StringBuffer query = new StringBuffer();
			query.append("create table store_info");
			query.append("(");
			query.append("shop_id integer primary key autoincrement, ");
			query.append("brand_code text not null, ");
			query.append("brand_name text not null, ");
			query.append("brand_area text not null, ");
			query.append("city text not null, ");
			query.append("district text not null, ");
			query.append("tel text not null, ");
			query.append("zipcode text not null, ");
			query.append("address text not null, ");
			query.append("address_new text not null, ");
			query.append("ktec_x numeric not null, ");
			query.append("ktec_y numeric not null, ");
			query.append("longitude numeric not null, ");
			query.append("latitude numeric not null ");
			query.append(");");
			db.execSQL(query.toString());

			db.execSQL("create table area_list(area_id integer primary key autoincrement, city text not null, district text not null, town text not null);");
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");
//			db.execSQL("DROP TABLE IF EXISTS store_info");
//			db.execSQL("DROP TABLE IF EXISTS area_list");
//			onCreate(db);
			StringBuffer query = null;
			
			switch(oldVersion)
			{
			case 1:
////		업데이트내용 DB파일에 포함됨.
//				query = new StringBuffer();
//				query.append("insert into store_info");
//				query.append("(");
//				query.append("brand_code, brand_name, brand_area, city, district, tel, zipcode, address, address_new, ktec_x, ktec_y, longitude, latitude");
//				query.append(")");
//				query.append(" values(");
//				query.append("'0002','파리바게뜨','부산당리','부산광역시','사하구','051-201-2268','604828','부산광역시 사하구 당리동 312-19','',489027,279088,128.974375,35.105595");
//				query.append(");");
//				db.execSQL(query.toString());
			case 2:
				query = new StringBuffer();
				query.append("insert into store_info");
				query.append("(");
				query.append("brand_code, brand_name, brand_area, city, district, tel, zipcode, address, address_new, ktec_x, ktec_y, longitude, latitude");
				query.append(")");
				query.append(" values(");
				query.append("'0002','파리바게뜨','숭실대','서울특별시','동작구','02-825-8077','156881','서울특별시 동작구 상도동 475-9번지','서울특별시 상도로 360번지',307588,544371,126.9526547,37.49681385");
				query.append(");");
				db.execSQL(query.toString());
				
				query = new StringBuffer();
				query.append("insert into store_info");
				query.append("(");
				query.append("brand_code, brand_name, brand_area, city, district, tel, zipcode, address, address_new, ktec_x, ktec_y, longitude, latitude");
				query.append(")");
				query.append(" values(");
				query.append("'0002','파리바게뜨','운정해솔','경기도','파주시','031-945-8504','413190','경기도 파주시 와동동 1303-2번지','경기도 파주시 와동동 1303-2번지',290148,570620,126.7559040,37.7322030");
				query.append(");");
				db.execSQL(query.toString());
			case 3:
				query = new StringBuffer();
				query.append("insert into store_info");
				query.append("(");
				query.append("brand_code, brand_name, brand_area, city, district, tel, zipcode, address, address_new, ktec_x, ktec_y, longitude, latitude");
				query.append(")");
				query.append(" values(");
				query.append("'3000','배스킨라빈스','운정해솔마을','경기도','파주시','031-945-3133','413190','경기도 파주시 와동동 1-12번지 윤정프라자 1층','경기도 파주시 와동동 1-12번지 윤정프라자 1층',290038,570549,126.7559070,37.7322010");
				query.append(");");
				db.execSQL(query.toString());
			}
		}

	}

	public SpcDbAdapter(Context ctx) {
		this.mCtx = ctx;
	}

	public SpcDbAdapter open() throws SQLException {
		mDbHelper = new DatabaseHelper(mCtx);
		mDb = mDbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		mDbHelper.close();
	}

	public boolean existStore(){
		this.open();
		String query = "select count(*) as totalCnt from store_info;";
		
		Cursor cursor = mDb.rawQuery(query, null);
		
		cursor.moveToFirst();
		int cnt = Integer.parseInt(cursor.getString(0));
		cursor.close();
		this.close();
		return (cnt>0)?true:false;
	}
	
	public boolean existArea(){
		this.open();
		String query = "select count(*) as totalCnt from area_list;";
		
		Cursor cursor = mDb.rawQuery(query, null);
		
		cursor.moveToFirst();
		int cnt = Integer.parseInt(cursor.getString(0));
		cursor.close();
		this.close();
		return (cnt>0)?true:false;
	}
	
	public void createAreaList(){
		mDb.execSQL("create table area_list(area_id integer primary key autoincrement, city text not null, district text not null, town text not null);");
	}
	
	public long insertStoreInfo(Map<String, String> colData) {
		ContentValues initialValues = new ContentValues();
		initialValues.put(COLUMN_STOREINFO[1], colData.get("brandCode"));
		initialValues.put(COLUMN_STOREINFO[2], colData.get("brandName"));
		initialValues.put(COLUMN_STOREINFO[3], colData.get("brandArea"));
		initialValues.put(COLUMN_STOREINFO[4], colData.get("city"));
		initialValues.put(COLUMN_STOREINFO[5], colData.get("district"));
		initialValues.put(COLUMN_STOREINFO[6], colData.get("tel"));
		initialValues.put(COLUMN_STOREINFO[7], colData.get("zipcode"));
		initialValues.put(COLUMN_STOREINFO[8], colData.get("address"));
		initialValues.put(COLUMN_STOREINFO[9], colData.get("addressNew"));
		initialValues.put(COLUMN_STOREINFO[10], colData.get("ktecX"));
		initialValues.put(COLUMN_STOREINFO[11], colData.get("ktecY"));
		initialValues.put(COLUMN_STOREINFO[12], colData.get("latitude"));
		initialValues.put(COLUMN_STOREINFO[13], colData.get("longitude"));
		
		return mDb.insert("store_info", null, initialValues);
	}

	public long insertAddress(Map<String, String> colData) {
		ContentValues initialValues = new ContentValues();
		initialValues.put("city", colData.get("city"));
		initialValues.put("district", colData.get("district"));
		initialValues.put("town", colData.get("town"));
		return mDb.insert("area_list", null, initialValues);
	}

	public boolean updateTable(long rowId, String brandName, String brandArea) {
		ContentValues args = new ContentValues();
		args.put("brand_name", brandName);
		args.put("brand_area", brandArea);
		return mDb.update("store_info", args, "shop_id=" + rowId, null) > 0;
	}

	public boolean deleteStoreInfo(long rowId) {
		Log.i("Delete called", "value__" + rowId);
		return mDb.delete("store_info", "shop_id=" + rowId, null) > 0;
	}

	/**
	 * 전체 가맹점 정보 가져오기
	 * @param area
	 * @return
	 */
	public Cursor fetchStoreList() {
		Cursor mCursor = mDb.query("store_info", new String[] { "shop_id", "brand_name", "brand_area", "address", "tel", "latitude", "longitude" }, null, null, null, null, null);

		return mCursor;
	}

	/**
	 * 해당지역 매장정보 가져오기
	 * @param area
	 * @return
	 */
	public Cursor fetchStoreList(String area) {
		Cursor mCursor = mDb.query("store_info", new String[] { "shop_id", "brand_name", "brand_area", "address", "tel", "latitude", "longitude" }, "address like '%"+area+"%'", null, null, null, null);

		return mCursor;
	}

	/**
	 * 검색 결과 매장정보 가져오기
	 * @param area
	 * @return
	 */
	public Cursor fetchStoreList(String brand, String city, String dist, String town) {
		
		StringBuffer sb = new StringBuffer();
		sb.append(" 1=1");
		if(!StringUtils.isEmpty(brand))
			sb.append(" and brand_name='"+brand+"'");
		if(!StringUtils.isEmpty(city))
			sb.append(" and address like '%"+city+"%'");
		if(!StringUtils.isEmpty(dist))
			sb.append(" and address like '%"+dist+"%'");
		if(!StringUtils.isEmpty(town)){
			if(town.length()>2)
				town = town.substring(0,2);
			
			sb.append(" and address like '%"+town+"%'");
		}
		
		Cursor mCursor = mDb.query("store_info", new String[] { "shop_id", "brand_name", "brand_area", "address", "tel", "latitude", "longitude" }, 
				sb.toString(), null, null, null, null);

		return mCursor;
	}

	/**
	 * 매장정보 가져오기
	 * @param rowId
	 * @return
	 * @throws SQLException
	 */
	public Cursor fetchStore(long rowId) throws SQLException {
		Cursor mCursor = mDb.query(true, "store_info", new String[] { "shop_id", "brand_name", "brand_area", "address", "tel", "latitude", "longitude" }, "shop_id" + rowId, null, null, null, null, null);

		return mCursor;
	}
	
	/**
	 * 가맹점 리스트 가져오기
	 * @return
	 * @throws SQLException
	 */
	public Cursor fetchBrandList() throws SQLException {
		Cursor mCursor = mDb.query(true, "store_info", new String[] {"brand_name"}, null, null, "brand_name", null, null, null);

		return mCursor;
	}

	/**
	 * 시/도 목록 가져오기
	 * @return
	 * @throws SQLException
	 */
	public Cursor fetchCityList() throws SQLException {
		Cursor mCursor = mDb.query(true, "area_list", new String[] {"city"}, null, null, "city", null, null, null);

		return mCursor;
	}

	/**
	 * 시/군/구 목록 가져오기
	 * @param city
	 * @return
	 * @throws SQLException
	 */
	public Cursor fetchDistrictList(String city) throws SQLException {
		Cursor mCursor = mDb.query(true, "area_list", new String[] {"district"}, "city='"+city+"'", null, "district", null, null, null);

		return mCursor;
	}

	/**
	 * 동/읍/면 목록 가져오기
	 * @param city
	 * @param district
	 * @return
	 * @throws SQLException
	 */
	public Cursor fetchTownList(String city, String district) throws SQLException {
		Cursor mCursor = mDb.query(true, "area_list", new String[] {"town"}, "city='"+city+"' and district='"+district+"'", null, "town", null, null, null);

		return mCursor;
	}

}
