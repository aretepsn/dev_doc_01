package com.hpapp.adapter;

import java.util.List;

import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.hpapp.res.CMR;
import com.hpapp.res.Const;
import com.hpapp.util.SAHandlerEx;
import com.hpapp.util.SRStringSpliter;

	/**
	 * 웹뷰에서 수신되는 이벤트를 처리한다.
	 * 
	 * @author hjlee
	 *
	 */
public  class ShinHelpClient extends WebViewClient {
	
	private Context mContext;
	private Handler mParentHandler;
	private WebView mWebView;
	
	public ShinHelpClient(Context context, Handler mPaymentResultHandler, WebView webview) {
		// TODO Auto-generated constructor stub
		super();
		
		mContext = context;
		mParentHandler = mPaymentResultHandler;
		mWebView = webview;
	}
	
		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			super.onPageStarted(view, url, favicon);
			if(Const.LOG_FLAG){
				Log.d(Const.LOG_TAG, "onPageStarted : " + url.toString());
			}
			showProgress(CMR.string.process_job);
		}
		
		@Override
		public void onPageFinished(WebView view, String url) {
			super.onPageFinished(view, url);
			if(Const.LOG_FLAG){
				Log.d(Const.LOG_TAG, "onPageFinished : " + url.toString());
			}
			closeProgress();
		}
		
		@Override
		public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
			super.onReceivedError(view, errorCode, description, failingUrl);
			
			if(Const.LOG_FLAG){
				Log.d(Const.LOG_TAG, "onReceivedError -> errorCode = " + errorCode);
			}
		}
		
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, final String url) {
			if(Const.LOG_FLAG){
				Log.d(Const.LOG_TAG, url.toString());
			}
			
			//APP://resultCmd?resultCd=1111
			if (url.toLowerCase().startsWith("app://resultcmd")) {
				String url2 = url.toLowerCase();
				int index = url2.indexOf("?");
				url2 = url2.substring(index+1);
				SRStringSpliter sp = new SRStringSpliter(url2,"=");
				String[] tokens = sp.getTokens();
				if(tokens==null||tokens.length==0){
					super.shouldOverrideUrlLoading(view, url);
				}
				
				if(tokens[0].equalsIgnoreCase("resultcd")==false)
				 return super.shouldOverrideUrlLoading(view, url);
					
				if(tokens[1].equalsIgnoreCase("1111")==true)
				{
					SAHandlerEx ha = new SAHandlerEx(mParentHandler);
					ha.putString("errCode", "1111");
					ha.sendMessage(CMR.event.payment_process_cancel);
					return true;
				}else{
					SAHandlerEx ha = new SAHandlerEx(mParentHandler);
					ha.putString("errCode", tokens[1]);
					ha.sendMessage(CMR.event.payment_process_error);
					return true;
				}
			}
			
			// 로딩되어야할 URL이 "app://resultCmd"이면 결제화면에서 처리 결과가 리턴되는 것임. 
			if (url.toLowerCase().startsWith("app://resulthappyconpayment")) {
				String resultCd = "";
//				String ordrNo = "";
//				String ordrAmt = "";
//				String ordrDttm = "";
				
				int index = url.indexOf("?");
				String[] params = null;
				if (index > 0) {
				    params = url.substring(index+1).split("&");   
				    for (String param : params) {   
				        String split[] = param.split("=");   
				    	if ("resultCd".equals(split[0])) {
				    		resultCd = split[1];
				    		break;
				    	}
				    }
				}
				
				// 응답코드가 '0000'이면 정상처리된 것이고 아니면, 취소 또는 장애가 발생한 것임.
				// 두 경우다 메시지를 출력하고 액티비티를 종료시킨다.
				if ("0000".equals(resultCd)) {
					if(Const.LOG_FLAG){
						Log.d(Const.LOG_TAG, "카드결제가 완료되었습니다.");
					}
					
					SAHandlerEx ha = new SAHandlerEx(mParentHandler);
					ha.putString("errCode", "0000");
					ha.sendMessage(CMR.event.payment_process_success);
				}
				else {
					if(Const.LOG_FLAG){
						Log.d(Const.LOG_TAG, "카드결제가 취소되었습니다.");
					}
					
					if("9999".equals(resultCd)){
						SAHandlerEx ha = new SAHandlerEx(mParentHandler);
						ha.putString("errCode", "9999");
						ha.sendMessage(CMR.event.payment_process_error);
					}
					else if("1111".equals(resultCd)){
						//viewChanger.showPreviousView();
						SAHandlerEx ha = new SAHandlerEx(mParentHandler);
						ha.putString("errCode", "1111");
						ha.sendMessage(CMR.event.payment_process_cancel);
					}
				}
				return true;
			}
			else if (url.toLowerCase().startsWith("market://")) {
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "market:// : " + url);
				}
			    Intent   intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url)); 
			    mContext.startActivity(intent);
			    return true;
			}else if (url.toLowerCase().startsWith("http://mobileservice.v3webhard.com")) {
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "http://mobileservice.v3webhard.com: " + url);
				}
			    Intent   intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url)); 
			    mContext.startActivity(intent);
			    return true;
//			}else if (url.toLowerCase().startsWith("ahnlabv3mobileplus:")) {
//				if (Const.LOG_FLAG) {
//					Log.d(Const.LOG_TAG, "ahnlabv3mobileplus: " + url);
//				}
//				Intent   intent = new Intent(Intent.ACTION_DEFAULT, Uri.parse(url)); 
//				mContext.startActivity(intent);
//				return true;
			}
			else if (url.toLowerCase().startsWith("ahnlabv3mobileplus:")) {
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "ahnlabv3mobileplus : " + url);
					Log.d(Const.LOG_TAG, "ahnlabv3mobileplus : " + Uri.parse(url));
				}
				
				PackageManager pkgMgr = mContext.getPackageManager();
				Intent intent = new Intent(Intent.ACTION_DEFAULT, Uri.parse("ahnlabv3mobileplus:"));
				List<ResolveInfo> mApps = pkgMgr.queryIntentActivities(intent, 0);
				if (mApps.size() > 0) {
					return true;
				}
				return false;
			}
			else if (url.toLowerCase().startsWith("vguardcheck://")) {
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "vguard : " + url);
					Log.d(Const.LOG_TAG, "vguard : " + Uri.parse(url));
				}

				PackageManager pkgMgr = mContext.getPackageManager();
				Intent intent = new Intent(Intent.ACTION_DEFAULT, Uri.parse("vguardcheck://"));
				List<ResolveInfo> mApps = pkgMgr.queryIntentActivities(intent, 0);
				if (mApps.size() > 0) {
					return true;
				}
				return false;
			}
			else if (url.toLowerCase().startsWith("vguardstart://")  
					|| url.toLowerCase().startsWith("vguardend://")) {
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "vguard : " + url);
					Log.d(Const.LOG_TAG, "vguard : " + Uri.parse(url));
				}
				
//				if( url.toLowerCase().startsWith("vguardend://") ){
//					
//					return super.shouldOverrideUrlLoading(view, url);
//				}
				
			    Intent   intent = new Intent(Intent.ACTION_DEFAULT, Uri.parse(url)); 
			    mContext.startActivity(intent);  				
			    return true;
			}//ispmobile: isp 인증요청하기
			else if (url.toLowerCase().startsWith("ispmobile:"))
			{
				try{
			    Intent   intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
			    // intent.addCategory(Intent.CATEGORY_BROWSABLE);ACTION_DEFAULT ACTION_VIEW
			    mContext.startActivity(intent);
			    //((Activity) mContext).startActivityForResult(intent, 100);
			    	
				}catch(ActivityNotFoundException e){
					Toast.makeText(mContext, CMR.err.happycon_inavlid_plugin, Toast.LENGTH_SHORT).show();
					
				}catch(Exception e){
					
				}
				
			    return true;
			}else
			{
				view.stopLoading();
				if(!url.contains("close")){
					view.loadUrl(url);
				}

				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "shouldOverrideUrlLoading : " + url.toString());
				}
				return false;
			}
		}
		
		private ProgressDialog mProgressDialog;
		public void showProgress(String contents)
		{
			if(mProgressDialog!=null)
				closeProgress();
			mProgressDialog = ProgressDialog.show(mContext, "", contents, true, false);
		}
		
		public void closeProgress()
		{
			if(mProgressDialog!=null && mProgressDialog.isShowing()){
				mProgressDialog.dismiss();
				try {
					Thread.sleep(300);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		@Override
		public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
			// TODO Auto-generated method stub
			//return super.shouldOverrideKeyEvent(view, event);
			int keyCode = event.getKeyCode();
			if ((keyCode == KeyEvent.KEYCODE_DPAD_LEFT) && mWebView.canGoBack()) {
				mWebView.goBack();
						return true;
			} else if ((keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) && mWebView.canGoForward()) {
				mWebView.goForward();
						return true;
			}
			
			return false;

			
		}
		
	}