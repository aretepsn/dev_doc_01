package com.hpapp.adapter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import android.content.Context;
import android.provider.Settings.Secure;
import android.util.Log;
import android.widget.Toast;

import com.hpapp.bean.UserBean;
import com.hpapp.res.Const;
import com.hpapp.util.SEEDUtil;
import com.hpapp.util.SharedPref;
import com.hpapp.util.StringUtils;

public class HappyPointSync {

	public static UserBean user;

	Context context;
	/*
	 * 기본 생성
	 */
	public HappyPointSync(Context ctx){
		this.context = ctx;
	}
	
	private String connectHttpsXML(String uriStr, String[] params, String encoding){
		URL url = null;
		StringBuffer resp = new StringBuffer();

		try{
			URI uri = new URI(uriStr);
			url = uri.toURL();
			HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
			
			con.setDoOutput(true);
			con.setDoInput(true);
			con.setUseCaches(false);
			con.setConnectTimeout(5000);
			
			StringBuffer sb = new StringBuffer();
			if(params!=null && params.length>0){
				for(int i=0;i<params.length;i++){
					if(i>0)
						sb.append("&");
					sb.append(params[i]);
				}
			}
			
			con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			con.setRequestProperty("Content-length", String.valueOf(sb.toString().length()));
			con.setRequestMethod("POST");

			OutputStreamWriter output = new OutputStreamWriter(con.getOutputStream());
			output.write(sb.toString());
			output.flush();
			
			int resCode = 0;
			resCode = con.getResponseCode();
			
			if(resCode < 400){
				String line = "";
				
				BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "euc-kr"));
				while((line=br.readLine())!=null){
					resp.append(line);
				}
				br.close();
			}else{
				Log.d(Const.LOG_TAG, "데이터를 가져오는데 실패 하였습니다. 오류코드 : "+resCode);
				return "500";
			}
			
		}catch(Exception e){
			e.printStackTrace();
			return "500";
		}

		return resp.toString().substring(resp.toString().indexOf("<?xml"));
	}

	private String connectHttpXML(String uriStr, String[] params, String encoding){
		URL url = null;
		StringBuffer resp = new StringBuffer();

		try{
			URI uri = new URI(uriStr);
			url = uri.toURL();
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			
			con.setDoOutput(true);
			con.setDoInput(true);
			con.setUseCaches(false);
			con.setConnectTimeout(5000);
			
			StringBuffer sb = new StringBuffer();
			if(params!=null && params.length>0){
				for(int i=0;i<params.length;i++){
					if(i>0)
						sb.append("&");
					sb.append(params[i]);
				}
			}
			
			con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			con.setRequestProperty("Content-length", String.valueOf(sb.toString().length()));
			con.setRequestMethod("POST");

			OutputStreamWriter output = new OutputStreamWriter(con.getOutputStream());
			output.write(sb.toString());
			output.flush();
			
			int resCode = 0;
			resCode = con.getResponseCode();
			
			if(resCode < 400){
				String line = "";
				
				BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), encoding));
				while((line=br.readLine())!=null){
					resp.append(line);
				}
				br.close();
			}else{
				Log.d(Const.LOG_TAG, "데이터를 가져오는데 실패 하였습니다. 오류코드 : "+resCode);
				return "500";
			}
			
		}catch(Exception e){
			e.printStackTrace();
			return "500";
		}
		
		String returnResp = "";
		
		if(resp!=null && resp.toString().indexOf("<?xml")>-1){
			returnResp = resp.toString().substring(resp.toString().indexOf("<?xml"));
		}

		return returnResp;
	}

	private String getNodeValue(Element rootElem, String xpath){
		String returnVal = "";
		
		try {
			NodeList list = XPathAPI.selectNodeList(rootElem.getFirstChild(), xpath);
			
			if(list!=null){
				returnVal = list.item(0).getTextContent();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return "";
		}
		
		return returnVal;
	}
	
	/**
	 * 카드회원체크 및 정상카드배열 가져오기 
	 * @param param1 ID or NAME
	 * @param param2 PWD or JUMIN
	 * @return
	 */
	public Map<String,String> actionLogin(int accessType, String param1, String param2, String loginType){
		Map<String,String> result = new HashMap<String,String>();
		String uri = "";
		String xmlStr = "";
		SharedPref pref = new SharedPref(context, Const.SP_KEY);
		pref.putSharedPreference(Const.SP_AUTHTYPE, accessType);
		boolean logUpdate = pref.getBooleanSharedPreference(Const.SP_FIRST_UPDATE);

		if(StringUtils.isEmpty(param1) || StringUtils.isEmpty(param2) ){
			pref.putSharedPreference(Const.SP_AUTH, false);
			return result;
		}
				
		if(accessType == Const.TYPE_ACC_ID){
//			if(Const.IS_TEST){
//				uri = Const.URI_LOGIN_ID_V2;
//				
//				String[] params = new String[3];
//				try {
//					params[0] = "W_ID="+param1;
//					params[1] = "W_PASSWD="+URLEncoder.encode(param2,"euc-kr");
//					params[2] = "W_PATH=MMM";
//				} catch (UnsupportedEncodingException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//				xmlStr = connectHttpsXML(uri, params);
//			}else{
				uri = Const.URI_LOGIN_ID_V3;
//				uri ="http://api.happypointcard.com/front_v2/login/cardInfo_v2.asp";
				
				String[] params = new String[10];
				try {
					String spUserName = pref.getSharedPreference(Const.SP_NAME);
					String spCardNum = pref.getSharedPreference(Const.SP_CARDNO);
					
					if(!StringUtils.isEmpty(spUserName))
						spCardNum = "";

					params[0] = "gubun=I";
					params[1] = "W_ID="+param1;
//					params[2] = "W_PASSWD="+URLEncoder.encode(param2,"euc-kr");
					params[2] = "W_PASSWD="+URLEncoder.encode(SEEDUtil.encrypt(param2),"utf-8");
					params[3] = "W_CI=";
					params[4] = "W_NAME=";
					params[5] = "W_PATH="+((!logUpdate)?"F":loginType);
					params[6] = "cardnum="+spCardNum;
					params[7] = "deviceType=A";
					params[8] = "deviceId="+URLEncoder.encode(Secure.getString(context.getContentResolver(), Secure.ANDROID_ID), "euc-kr");
					params[9] = "deviceToken=";
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(uri.indexOf("https://")>-1)
					xmlStr = connectHttpsXML(uri, params, "euc-kr");
				else
					xmlStr = connectHttpXML(uri, params, "euc-kr");
//			}

		}else if(accessType == Const.TYPE_ACC_NAME){
			uri = Const.URI_LOGIN_NAME;
			
			String[] params = new String[2];
			params[0] = "W_NAME="+param1;
			params[1] = "W_JUMIN="+param2;

			if(uri.indexOf("https://")>-1)
				xmlStr = connectHttpsXML(uri, params, "euc-kr");
			else
				xmlStr = connectHttpXML(uri, params, "euc-kr");

		}else if(accessType == Const.TYPE_ACC_NAME_V2){
			if(!logUpdate){
				uri = Const.URI_LOGIN_ID_V3;
				String[] params = new String[10];
				try {
					params[0] = "gubun=P";
					params[1] = "W_ID=";
					params[2] = "W_PASSWD=";
					params[3] = "W_CI="+param1;
					params[4] = "W_NAME="+param2;
					params[5] = "W_PATH=F";
					params[6] = "cardnum="+pref.getSharedPreference(Const.SP_CARDNO);
					params[7] = "deviceType=A";
					params[8] = "deviceId="+URLEncoder.encode(Secure.getString(context.getContentResolver(), Secure.ANDROID_ID), "euc-kr");
					params[9] = "deviceToken=";
					
					if(uri.indexOf("https://")>-1)
						xmlStr = connectHttpsXML(uri, params, "euc-kr");
					else
						xmlStr = connectHttpXML(uri, params, "euc-kr");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				uri = Const.URI_LOGIN_NAME_V2;
				
				String[] params = new String[3];
				params[0] = "W_NAME="+param1;
				params[1] = "W_CI="+param2;
				params[2] = "W_PATH=MMM";

				if(uri.indexOf("https://")>-1)
					xmlStr = connectHttpsXML(uri, params, "euc-kr");
				else
					xmlStr = connectHttpXML(uri, params, "euc-kr");
			}

		}else{
			pref.putSharedPreference(Const.SP_AUTH, false);
			return result;
		}

		if(Const.LOG_FLAG){
			Log.d(Const.LOG_TAG, xmlStr);
		}
		
		if(!StringUtils.isEmpty(xmlStr) && !"500".equals(xmlStr)){
			try {
				InputSource is = new InputSource(new StringReader(xmlStr));
				
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();
				Document doc = db.parse(is);
				
				// root노드 구하기
				Element root = doc.getDocumentElement();
				
				// 응답 결과 코드
				String rspCd = getNodeValue(root, "//rsp/rsp_cd");
				result.put("rspCode", rspCd);

				// 추천인 Y/N
				String recommendYn = getNodeValue(root, "//rsp/recommendYn");
				result.put("recommendYn", recommendYn);
				
				// 추천인 Title
				String recommendTitle = getNodeValue(root, "//rsp/recommendTitle");
				result.put("recommendTitle", recommendTitle);
				
				// 추천인 Content
				String recommendContent = getNodeValue(root, "//rsp/recommendContent");
				result.put("recommendContent", recommendContent);
				
				// 쿠폰요청 Y/N
				String incardYn = getNodeValue(root, "//rsp/incardYn");
				result.put("incardYn", incardYn);
				
				if(rspCd.equals("00") || rspCd.equals("13")){
					pref.putSharedPreference(Const.SP_FIRST_UPDATE, true);
					if(user==null)
						user = new UserBean();
					
					if(accessType == Const.TYPE_ACC_ID){
						user.setUserId(param1);
						user.setUserPwd(param2);
						user.setUserName(getNodeValue(root, "//info/mb_name"));
						user.setMobileCardNo(getNodeValue(root, "//info/mb_card_no"));

						pref.putSharedPreference(Const.SP_NAME, null);
						pref.putSharedPreference(Const.SP_IDNUM, null);
						pref.putSharedPreference(Const.SP_CI, null);
					}else if(accessType == Const.TYPE_ACC_NAME){
						user.setUserName(param1);
						user.setIdNumber(param2);
						String cardsNo=getNodeValue(root, "//info/mb_card_no");
						user.setCardsNo((StringUtils.isEmpty(cardsNo))?null:cardsNo.split(","));
					}else if(accessType == Const.TYPE_ACC_NAME_V2){
						user.setUserName(param1);
						user.setCi(pref.getSharedPreference(Const.SP_CI));
						user.setMobileCardNo(getNodeValue(root, "//info/mb_card_no"));
						user.setUserClMent(getNodeValue(root, "//info/mb_cl_ment"));
					}
					user.setAccessType(accessType);
					user.setGrade(getNodeValue(root, "//info/mb_grade"));
					user.setGradeName(getNodeValue(root, "//info/mb_grade_nm"));
					user.setUserNo(getNodeValue(root, "//info/mb_no"));
					user.setUserCl(getNodeValue(root, "//info/mb_cl_cd"));
					user.setUserClName(getNodeValue(root, "//info/mb_cl_nm"));
					user.setPhoneNumber(getNodeValue(root, "//info/mb_cp"));
					
					pref.putSharedPreference(Const.SP_HPCNO, user.getUserNo());
					pref.putSharedPreference(Const.SP_CLASS, user.getUserCl());
					pref.putSharedPreference(Const.SP_AUTH, true);
					pref.putSharedPreference(Const.SP_RECOMMEND, recommendYn);
					pref.putSharedPreference(Const.SP_RECOMMEND_TITLE, recommendTitle);
					pref.putSharedPreference(Const.SP_RECOMMEND_CONTENT, recommendContent);
				}else{
					if(Const.LOG_FLAG){
						Log.d(Const.LOG_TAG, "로그인 실패::"+getNodeValue(root, "//rsp/rsp_msg"));
					}
					result.put("rspMsg", getNodeValue(root, "//rsp/rsp_msg"));
					pref.putSharedPreference(Const.SP_AUTH, false);
				}
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				pref.putSharedPreference(Const.SP_AUTH, false);
				if(Const.LOG_FLAG){
					Log.d(Const.LOG_TAG, "로그인 할 수 없습니다. (ParserConfigurationException)");
				}
//				Toast.makeText(context, "로그인 할 수 없습니다. (ParserConfigurationException)", Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				pref.putSharedPreference(Const.SP_AUTH, false);
				if(Const.LOG_FLAG){
					Log.d(Const.LOG_TAG, "로그인 할 수 없습니다. (SAXException)");
				}
//				Toast.makeText(context, "로그인 할 수 없습니다. (SAXException)", Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				pref.putSharedPreference(Const.SP_AUTH, false);
				if(Const.LOG_FLAG){
					Log.d(Const.LOG_TAG, "로그인 할 수 없습니다. (IOException)");
				}
//				Toast.makeText(context, "로그인 할 수 없습니다. (IOException)", Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			} catch (NullPointerException e) {
				pref.putSharedPreference(Const.SP_AUTH, false);
				if(Const.LOG_FLAG){
					Log.d(Const.LOG_TAG, "로그인 할 수 없습니다. (NullPointerException)");
				}
//				Toast.makeText(context, "로그인 할 수 없습니다. (NullPointerException)", Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
		}else if("500".equals(xmlStr)){
			result.put("rspCode", "500");
			result.put("rspMsg", "로그인 할 수 없습니다. 잠시 후 다시 시도해 주세요.");
			pref.putSharedPreference(Const.SP_AUTH, false);
			Log.d(Const.LOG_TAG, "로그인 할 수 없습니다. 잠시 후 다시 시도해 주세요.");
		}else{
			result.put("rspCode", "-99");
			result.put("rspMsg", "네트워크 오류로 로그인 할 수 없습니다");
			pref.putSharedPreference(Const.SP_AUTH, false);
			Log.d(Const.LOG_TAG, "네트워크 오류로 로그인 할 수 없습니다");
		}
		return result;
	}
	
	/**
	 * 비회원 사용자 주민번호로 CI값 가져오기
	 * @param param
	 * @return
	 */
	public void setCiByJumin(String param){
		String uri = "";
		String xmlStr = "";
		
		if(StringUtils.isEmpty(param)){
			return;
		}
		
		uri = Const.URI_CI_JUMIN;
			
		String[] params = new String[2];
		params[0] = "W_JUMIN="+param;
		params[1] = "W_PATH=MMM";
			
		if(uri.indexOf("https://")>-1)
			xmlStr = connectHttpsXML(uri, params, "euc-kr");
		else
			xmlStr = connectHttpXML(uri, params, "euc-kr");

		if(Const.LOG_FLAG){
			Log.d(Const.LOG_TAG, xmlStr);
		}
		
		if(xmlStr!=null && xmlStr!=""){
			try {
				InputSource is = new InputSource(new StringReader(xmlStr));
				
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();
				Document doc = db.parse(is);
				
				// root노드 구하기
				Element root = doc.getDocumentElement();
				
				// 응답 결과 코드
				String rspCd = getNodeValue(root, "//rsp/rsp_cd");
				
				if(rspCd.equals("00")){
					SharedPref pref = new SharedPref(context, Const.SP_KEY);
						String ciCode = getNodeValue(root, "//info/mb_ipin_ci");
					
						if(!StringUtils.isEmpty(ciCode)){
							pref.putSharedPreference(Const.SP_CI, ciCode);
							pref.putSharedPreference(Const.SP_IDNUM, null);
						}
				}else{
					if(Const.LOG_FLAG){
						Log.d(Const.LOG_TAG, "CI 가져오기 실패::"+getNodeValue(root, "//rsp/rsp_msg"));
					}
				}
			} catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				if(Const.LOG_FLAG){
					Log.d(Const.LOG_TAG, "CI를 가져올 수 없습니다. (ParserConfigurationException)");
				}
//				Toast.makeText(context, "로그인 할 수 없습니다. (ParserConfigurationException)", Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				if(Const.LOG_FLAG){
					Log.d(Const.LOG_TAG, "CI를 가져올 수 없습니다. (SAXException)");
				}
//				Toast.makeText(context, "로그인 할 수 없습니다. (SAXException)", Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				if(Const.LOG_FLAG){
					Log.d(Const.LOG_TAG, "CI를 가져올 수 없습니다. (IOException)");
				}
//				Toast.makeText(context, "로그인 할 수 없습니다. (IOException)", Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			} catch (NullPointerException e) {
				if(Const.LOG_FLAG){
					Log.d(Const.LOG_TAG, "CI를 가져올 수 없습니다. (NullPointerException)");
				}
//				Toast.makeText(context, "로그인 할 수 없습니다. (NullPointerException)", Toast.LENGTH_SHORT).show();
				e.printStackTrace();
			}
		}else{
			Toast.makeText(context.getApplicationContext(), "오류로 CI를 가져올 수 없습니다.", Toast.LENGTH_SHORT).show();
		}
	}

}
