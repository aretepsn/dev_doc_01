/************************************************
 * Created on [2010. 5. 1.]
 *
 * Copyright (C) 2010 crowehj
 * Project       :    
 * FileName      :  
 * Version       : 1.0
 * Author        : crowehj
 * 
 * Platform      : Windows XP, etc.
 * Compiler      : JDK 1.6.2
 * Comment       : 
 * last Modified : 
 *  
 * ETC           : 
 *      
 ***********************************************/
package com.hpapp.util;

/************************************************
 * Created on 2010. 5. 1.
 * Description   :
 * Author        : crowehj
 ***********************************************/

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

public class SADynamicLayout {
	
	private LinearLayout _linear_layout;
//	private LinearLayout.LayoutParams _params;
	private Context _context;
	
	public final static  int  FP = ViewGroup.LayoutParams.FILL_PARENT;
	public final static  int  WC = ViewGroup.LayoutParams.WRAP_CONTENT;
	
	
	public static final int TRUE = -1;
    public static final int LEFT_OF = 0;
    public static final int RIGHT_OF = 1;
    public static final int ABOVE = 2;
    public static final int BELOW = 3;
    public static final int ALIGN_BASELINE = 4;
    public static final int ALIGN_LEFT = 5;
    public static final int ALIGN_TOP = 6;
    public static final int ALIGN_RIGHT = 7;
    public static final int ALIGN_BOTTOM = 8;
    public static final int ALIGN_PARENT_LEFT = 9;
    public static final int ALIGN_PARENT_TOP = 10;
    public static final int ALIGN_PARENT_RIGHT = 11;
    public static final int ALIGN_PARENT_BOTTOM = 12;
    public static final int CENTER_IN_PARENT = 13;
    public static final int CENTER_HORIZONTAL = 14;
    public static final int CENTER_VERTICAL = 15;
    
	
	public SADynamicLayout(Context context)
	{
		_context = context;
		
		_linear_layout = new LinearLayout ( context );
		_linear_layout.setOrientation(LinearLayout.VERTICAL); 
		
		new LinearLayout.LayoutParams ( LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT );
	}
	
	public SADynamicLayout(Context context, int w, int h)
	{
		_context = context;
		
		_linear_layout = new LinearLayout ( context );
		_linear_layout.setOrientation(LinearLayout.VERTICAL); 
		
		new LinearLayout.LayoutParams ( w, h );
	}
	

	public void setHorizontal()
	{
		_linear_layout.setOrientation(LinearLayout.HORIZONTAL);
	}
	
	public void setVirtical()
	{
		_linear_layout.setOrientation(LinearLayout.VERTICAL);	
	}
	
	/**
	 * @param id
	 * @param w
	 * @param h
	 * @return
	 */
	public WebView addWebView(int id) {
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams ( LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT );
		WebView et = new WebView(_context);
		et.setId(id);
		_linear_layout.addView(et, params);
		return et;
	}
	
	/**
	 * @param id
	 * @param text
	 */
	public void addTextView(int id, String text) 
	{
		// TODO Auto-generated method stub
		TextView tv = new TextView(_context);
		tv.setId(id);
		tv.setText(text);
		
		_linear_layout.addView(tv);
		
	}
	
	public void addTextView(int id, TextView tv, LinearLayout.LayoutParams paramsLL ) 
	{
		// TODO Auto-generated method stub
		tv.setId(id);
		_linear_layout.addView(tv, paramsLL);
	}

	public void addTextView(int id, ImageView tv, LinearLayout.LayoutParams paramsLL ) 
	{
		// TODO Auto-generated method stub
		tv.setId(id);
		_linear_layout.addView(tv, paramsLL);
	}
	
	public void addView(int id, View tv, LinearLayout.LayoutParams paramsLL ) 
	{
		// TODO Auto-generated method stub
		tv.setId(id);
		_linear_layout.addView(tv, paramsLL);
	}


	/**
	 * @return
	 */
	public View getView() 
	{
		return _linear_layout;
	}

	/**
	 * @param id
	 * @param w
	 * @param h
	 */
	public void setTextViewParams(int id, int w, int h)
	{
		
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams ( w, h );
		TextView tv = (TextView)_linear_layout.findViewById(id);
		tv.setLayoutParams(params);
	}

	/**
	 * @param id
	 * @param left
	 * @param top
	 * @param right
	 * @param bottom
	 */
	public void setTextViewMargin(int id, int left, int top, int right, int bottom)
	{
		TextView tv = (TextView)_linear_layout.findViewById(id);
		LinearLayout.LayoutParams params  = (android.widget.LinearLayout.LayoutParams) tv.getLayoutParams();
		if(left!=0)
			params.leftMargin = left;

		if(top!=0)
		params.topMargin = top;

		if(right!=0)
		params.rightMargin = right;

		if(bottom!=0)
		params.bottomMargin = bottom;
		
	}

	/**
	 * @param gravity
	 */
	public void setTextGravity(int id, int gravity) {
		TextView tv = (TextView)_linear_layout.findViewById(id);
		tv.setGravity(gravity);
	}

	/**
	 * @param id
	 * @param w
	 * @param h
	 * @return
	 */
	public EditText addEditText(int id, int w,	int h) {

		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams ( w, h );
		EditText et = new EditText(_context);
		et.setId(id);
		_linear_layout.addView(et, params);
		return et;
	}

	/**
	 * @param id
	 * @param left
	 * @param top
	 * @param right
	 * @param bottom
	 */
	public void setEditTextMargin(int id, int left, int top, int right, int bottom) 
	{
		EditText tv = (EditText)_linear_layout.findViewById(id);
		LinearLayout.LayoutParams params  = (android.widget.LinearLayout.LayoutParams) tv.getLayoutParams();
		if(left!=0)
			params.leftMargin = left;

		if(top!=0)
		params.topMargin = top;

		if(right!=0)
		params.rightMargin = right;

		if(bottom!=0)
		params.bottomMargin = bottom;
		
	}
	
	public static LinearLayout.LayoutParams createParam(int w, int h)
	{
		return new LinearLayout.LayoutParams(w,h);
	}
	
	public static LinearLayout.LayoutParams createParam(int w, int h, float weight)
	{
		return new LinearLayout.LayoutParams(w,h, weight);
	}
	
	public static RelativeLayout.LayoutParams createParamRelativeLayout(int w, int h)
	{
		return new RelativeLayout.LayoutParams ( w, h );
	}

	/**
	 * @param avedaPopupBg01
	 */
	public void setBackground(int rid) {
		_linear_layout.setBackgroundResource(rid);
	}
	

}
