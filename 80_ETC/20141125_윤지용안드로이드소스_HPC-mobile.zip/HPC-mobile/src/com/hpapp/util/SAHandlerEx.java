package com.hpapp.util;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;


public class SAHandlerEx extends Handler {
	
	private Handler mHandler;
	private Bundle mSend;
	
	public SAHandlerEx(Handler handler)
	{
		mHandler = handler;
		mSend = new Bundle();
	}
	
	public SAHandlerEx(Message message)
	{
		
		mSend = message.getData();
		
	}
	
	
	public void putString(String key, String value)
	{
		mSend.putString(key, value);
	}
	
	public void putInt(String key, int value)
	{
		mSend.putInt(key, value);
	}

	public String getString(String key)
	{
		return mSend.getString(key);
	}
	
	public int getInt(String key)
	{
		return mSend.getInt(key);
	}
	
	public void sendMessage(int msgid){
		
		Message message = Message.obtain(mHandler, msgid);
	    message.setData(mSend);
	    mHandler.sendMessageDelayed(message, 500);
	}
	
	public void sendMessageNormal(int id)
	{
		
		mHandler.sendEmptyMessage(id);
		
	}

	public void remove() {
		// TODO Auto-generated method stub
		
		mSend.clear();
	}
	
}
