package com.hpapp.util;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Handler;
import android.view.Gravity;


public class SADialog {

	private static Handler mHandler;
	
	public static int CENTER = Gravity.CENTER;
	public static int LEFT = Gravity.LEFT;
	public static int RIGHT = Gravity.RIGHT;
	public static int NO_GRAVITY = Gravity.NO_GRAVITY;
	
	private static SADialogEx customizeDialog;
	private static SADialogEx customizeDialogProgress;
	
	public SADialog()
	{
	}
	
	//주의 프로그램 초기화시 반드시 호출
	public static void initialize()
	{
		//customizeDialogProcessing = false;
		if(customizeDialog!=null){
			customizeDialog.dismiss();
			customizeDialog.setProcessing(false);
		}

		if(customizeDialogProgress!=null){
			customizeDialogProgress.dismiss();
			customizeDialogProgress.setProcessing(false);
		}
	}
	
	public static void showDialogOK(Context context, String title, String message) {
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
	    builder.setTitle(title);
	    builder.setMessage(message);
	    builder.setPositiveButton("확인", null);
	    builder.show();
	}
	
	public static void showDialogOK(Context context, Handler handler, String title, String message) {
		mHandler = handler;
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
	    builder.setTitle(title);
	    builder.setMessage(message);
	    
	    builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				//Message message = Message.obtain(mHandler, custom_dlalog_ok);
				if(mHandler!=null)
					mHandler.sendEmptyMessage(custom_dlalog_ok);
			    
			}
		});
	    
	    builder.setOnCancelListener(new OnCancelListener(){
			@Override
			public void onCancel(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(mHandler!=null)
					mHandler.sendEmptyMessage(custom_dlalog_ok);
			}
	    });
	    
	    builder.show();
	}
	
	public static void removeDialog_Progress()
	{
		if(customizeDialogProgress!=null)
			customizeDialogProgress.dismiss();
	}
	
	public static void showDialogOKCancel(Context context, Handler handler, String title, String message) {
		
		mHandler = handler;
		AlertDialog.Builder builder = new AlertDialog.Builder(context);
	    builder.setTitle(title);
	    builder.setMessage(message);
	    
	    builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				//Message message = Message.obtain(mHandler, custom_dlalog_ok);
				if(mHandler!=null)
					mHandler.sendEmptyMessage(custom_dlalog_ok);
			    
			}
		});
	    
	    builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				if(mHandler!=null)
					mHandler.sendEmptyMessage(custom_dlalog_cancel);
			}
		});
	    
	    builder.setOnCancelListener(new OnCancelListener(){
			@Override
			public void onCancel(DialogInterface dialog) {
				// TODO Auto-generated method stub
				if(mHandler!=null)
					mHandler.sendEmptyMessage(custom_dlalog_cancel);
			}
	    });
	    
	    builder.show();
	}

	public final static int custom_dlalog_ok = 0;
	public final static int custom_dlalog_cancel = 1;
	public final static int custom_dlalog_dismiss = 2;
	
    public static final int net_connection_ok = 100;
    public static final int net_connection_nok = 101;
}
