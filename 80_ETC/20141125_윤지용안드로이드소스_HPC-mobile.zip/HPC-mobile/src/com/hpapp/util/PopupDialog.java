package com.hpapp.util;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;

import com.hpapp.R;


public class PopupDialog extends Dialog{

	private ImageButton authName, authId, btnClose;
	private View.OnClickListener mListener01;
	private View.OnClickListener mListener02;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		WindowManager.LayoutParams lpWindow= new WindowManager.LayoutParams();
		lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
		lpWindow.dimAmount = 0.6f;
		getWindow().setAttributes(lpWindow);
		
		setContentView(R.layout.popup_small);
//		
		authName = (ImageButton) findViewById(R.id.authName);
		authId = (ImageButton) findViewById(R.id.authId);
		btnClose = (ImageButton) findViewById(R.id.popup_btn_close);

		setClickListener(mListener01, mListener02);

		btnClose.setOnClickListener(closeListener);
	}

	public PopupDialog(Context context) {
		super(context, android.R.style.Theme_Translucent_NoTitleBar);
		// TODO Auto-generated constructor stub
	}
	
	public PopupDialog(Context context, View.OnClickListener listener01, View.OnClickListener listener02) {
		super(context, android.R.style.Theme_Translucent_NoTitleBar);
		this.mListener01 = listener01;
		this.mListener02 = listener02;
		// TODO Auto-generated constructor stub
	}
	
	private void setClickListener(View.OnClickListener listener01, View.OnClickListener listener02){
		if(listener01!=null)
			this.authName.setOnClickListener(listener01);
		if(listener02!=null)
			this.authId.setOnClickListener(listener02);
	}

	private View.OnClickListener closeListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			dismiss();
		}
	};
}
