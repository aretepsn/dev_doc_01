package com.hpapp.util;

import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Context;
import android.util.TypedValue;

public class DisplayUtil {

	public static Map<String, Object> getDisplayInfo(Activity activity){
		int width = activity.getWindowManager().getDefaultDisplay().getWidth();
		int height = activity.getWindowManager().getDefaultDisplay().getHeight();
		float scale = activity.getApplicationContext().getResources().getDisplayMetrics().density;

		Map<String, Object> displayInfo = new HashMap<String, Object>();
		displayInfo.put("width", width);
		displayInfo.put("height", height);
		displayInfo.put("scale", scale);
		
		return displayInfo;
	}
	
	/**
	 * dip(dp)를 px로 변환
	 * @param context
	 * @param dip
	 * @return
	 */
	public static int convertDipToPixel(Context context, int dip){
		int px=0;
		px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dip, context.getResources().getDisplayMetrics());

		int width = context.getResources().getDisplayMetrics().widthPixels;
		int height = context.getResources().getDisplayMetrics().heightPixels;
		
		if(width >= 720 && height >= 1280){
			float scale = context.getResources().getDisplayMetrics().density;
			px += (6.0f*scale+0.5f);
		}

//		float scale = context.getResources().getDisplayMetrics().density;
//		px = (int) (dip*scale + 0.5f);

		// The gesture threshold expressed in dpprivate 
//		final float GESTURE_THRESHOLD_DP = 16.0f;
//		int mGestureThreshold = (int) (GESTURE_THRESHOLD_DP * scale + 0.5f);

//		int dpi = context.getResources().getDisplayMetrics().densityDpi;
//		if(dpi>160){
//			px += mGestureThreshold;
//		}
//		int width = context.getResources().getDisplayMetrics().widthPixels;
//		int height = context.getResources().getDisplayMetrics().heightPixels;
//		System.out.println(width + "::" + height);

		return px;
	}

	public static int convertDipToPixelFix(Context context, int dip){
		int px=0;
		px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dip, context.getResources().getDisplayMetrics());
		return px;
	}

	/**
	 * px을 dip(dp)로 변환
	 * @param context
	 * @param px
	 * @return
	 */
	public static int convertPixelToDip(Context context, int px){
		int dip=0;
		float scale = context.getResources().getDisplayMetrics().density;
		dip = (int) (px/(160*scale));
		return dip;
	}

}
