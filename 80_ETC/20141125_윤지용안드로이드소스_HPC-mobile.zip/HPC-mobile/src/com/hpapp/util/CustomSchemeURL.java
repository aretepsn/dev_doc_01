package com.hpapp.util;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.net.Uri;

public abstract class CustomSchemeURL {
	public static final String MYPEOPLE_PACKAGE_NAME = "net.daum.android.air";
	public static final String MYPEOPLE_DOWNLOAD_PAGE = "http://durl.kr/ixug";
	
	private Context mContext;
	
	private CustomSchemeURL(Context context) {
		mContext = context;
	}

	/**
	 * 생성자에서 전달받은 내용에 따라 Intent객체를 생성하여 반환 
	 * @return Intent 객체
	 */
	public abstract Intent getIntent();
	
	/**
	 * myp sheme을 처리할 수 있는 어플리케이션이 존재하는지 검사
	 * @return 사용가능할 경우 true
	 */
	public boolean canOpenMypeopleURL() {
		PackageManager pm = mContext.getPackageManager();
		List<ResolveInfo> infos = pm.queryIntentActivities(getIntent(), PackageManager.MATCH_DEFAULT_ONLY);
		
		return infos != null && infos.size() > 0;
	}
	
	/**
	 * 마이피플 설치 여부 검사
	 * @return 설치되어 있을 경우 true
	 */
	public boolean existMypeopleApp() {
		PackageManager pm = mContext.getPackageManager();
		
		try {
			return (pm.getPackageInfo(MYPEOPLE_PACKAGE_NAME, PackageManager.GET_SIGNATURES) != null);
		} catch (NameNotFoundException e) {
			return false;
		}
	}
	
	/**
	 * 마이피플 다운로드 페이지열기
	 */
	public static void openMypeopleDownloadPage(Context context) {
		Intent intent = new Intent(Intent.ACTION_VIEW).setData(Uri.parse(MYPEOPLE_DOWNLOAD_PAGE));
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(intent);
	}
	
	/**
	 * Url링크  보내기
	 */
	public static class SendUrl extends CustomSchemeURL {
		//[sample] myp://sendMessage?url=[url]&message=[message]&appID=[appID]&appName=[appName]
		public static final String SCHEME = "myp";
		public static final String AUTHORITY = "sendMessage";
		public static final String PARAM_URL = "url"; 					//	url : 메시지에 포함되는 링크시킬 URL
		public static final String PARAM_MESSAGE = "message"; 			//	message : 메시지 내용
//		public static final String PARAM_APPID = "appID"; 				//	appID : 앱 ID
		public static final String PARAM_APPNAME = "appName"; 			//	appName : 메시지에 포함되는 앱 이름
		
		private final String mMessage;
		private final String mLinkUrl;
		//private final String mAppID;
		private final String mAppName;
		//private final String mEncode;
		
		/**
		 * 생성자
		 * @param context Context 객체
		 * @param message 메시지 내용
		 * @param linkUrl 메시지에 포함되는 링크시킬 URL
		 * @param appName 메시지에 포함되는 앱 이름
		 */
		public SendUrl(Context context, String message, String linkUrl, String appName) {
			super(context);
			mMessage = message;
			mLinkUrl = linkUrl;
			//mAppID = appID; //@param appID 앱 ID
			mAppName = appName;
			//mEncode = encode; //인코딩 type
		}
		
		@Override
		public Intent getIntent() {
			return new Intent(Intent.ACTION_SEND)
				.setData( 
					new Uri.Builder()
						.scheme(SCHEME)
						.authority(AUTHORITY)
						.appendQueryParameter(PARAM_URL, mLinkUrl)
						.appendQueryParameter(PARAM_MESSAGE, mMessage)
						//.appendQueryParameter(CUSTOM_SCHEME.PARAM_APPID, mAppID)
						.appendQueryParameter(PARAM_APPNAME, mAppName)
						.build()
						);
		}
	}
	
	/**
	 * 프로필 이미지 설정하기
	 */
	public static class SetProfileImage extends CustomSchemeURL {
		public static final String SCHEME = "mypto";
		//[sample] mypto://setProfileImage?fileUrl=[fileUrl]
		public static final String AUTHORITY = "setProfileImage";
		public static final String PARAM_FILEURI = "fileUrl";			//	fileUrl : 이미지 파일 전체 경로 및 Content Uri

		private final Uri mFileUrl;
		
		/**
		 * 생성자
		 * @param context Context 객체
		 * @param fileUrl 파일 전체 경로 및 Content Uri
		 */
		public SetProfileImage(Context context, Uri fileUrl) {
			super(context);
			mFileUrl = fileUrl;
		}
		
		@Override
		public Intent getIntent() {
			return new Intent(Intent.ACTION_SEND)
				.setData( 
					new Uri.Builder()
					.scheme(SCHEME)
					.authority(AUTHORITY)
					.appendQueryParameter(PARAM_FILEURI, mFileUrl.toString())
					.build()
					);
		}
	}
	
	/**
	 * 메시지 전송하기
	 */
	public static class SendMessage extends CustomSchemeURL {
		public static final String SCHEME = "mypto";
		//[sample] mypto://sendMessage?message=[message]&fileUrl=[fileUrl]
		public static final String AUTHORITY = "sendMessage";
		public static final String PARAM_MESSAGE = "message"; 			//	message : 메시지 내용
		public static final String PARAM_FILEURI = "fileUrl";			//	fileUrl : 이미지 파일 전체 경로 및 Content Uri
		//public static final String AUDIO_MIME_TYPE = "wav";
		
		private final String mMessage;
		private final Uri mFileUrl;
		
		/**
		 * 생성자
		 * @param context Context 객체
		 * @param message 메시지 내용
		 * @param fileUrl 파일 전체 경로 및 Content Uri
		 */
		public SendMessage(Context context, String message, Uri fileUrl) {
			super(context);
			mMessage = message;
			mFileUrl = fileUrl;
		}
		
		@Override
		public Intent getIntent() {
			Uri.Builder uriBuilder =
					new Uri.Builder()
						.scheme(SCHEME)
						.authority(AUTHORITY)
						.appendQueryParameter(PARAM_MESSAGE, mMessage);
			
			if(mFileUrl != null)
				uriBuilder.appendQueryParameter(PARAM_FILEURI, mFileUrl.toString());
						
			return new Intent(Intent.ACTION_SEND)
						.setData(uriBuilder.build()); 
		}
	}

	/**
	 * 위치 보내기
	 */
	public static class SendMap extends CustomSchemeURL {
		public static final String SCHEME = "mypto";
		//[sample] mypto://sendMap?caption=[caption]&latitude=[latitude]&longitude=[longitude]
		public static final String AUTHORITY = "sendMap";
		public static final String PARAM_CAPTION = "caption";			// caption : 공유 메시지 내용
		public static final String PARAM_LATITUDE = "latitude";			// lagitude : GPS 좌표
		public static final String PARAM_LONGITUDE = "longitude";		// longitude : GPS 좌표
		
		private final String mCaption;
		private final double mCoordX;
		private final double mCoordY;
		
		/**
		 * 생성자
		 * @param context Context 객체
		 * @param caption 메시지 내용
		 * @param x GPS 좌표(lagitude)
		 * @param y GPS 좌표(longitude)
		 */
		public SendMap(Context context, String caption, double x, double y) {
			super(context);
			mCaption = caption;
			mCoordX = x;
			mCoordY = y;
		}
		
		@Override
		public Intent getIntent() {
			return new Intent(Intent.ACTION_SEND)
				.setData( 
					new Uri.Builder()
						.scheme(SCHEME)
						.authority(AUTHORITY)
						.appendQueryParameter(PARAM_CAPTION, mCaption)
						.appendQueryParameter(PARAM_LATITUDE, String.valueOf(mCoordX))
						.appendQueryParameter(PARAM_LONGITUDE, String.valueOf(mCoordY))
						.build()
						);
		}
	}
}