package com.hpapp.util;


import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.TextView;

import com.hpapp.R;
import com.hpapp.res.CMR;
import com.hpapp.res.Const;


public class CommPopupDialog extends Dialog{

	private Context context;
	private ImageButton btnClose;
	private TextView tvTitle1, tvTitle2;
	private WebView webview;
	private String urlStr;
	private String title, subTitle;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		WindowManager.LayoutParams lpWindow= new WindowManager.LayoutParams();
		lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
		lpWindow.dimAmount = 0.6f;
		getWindow().setAttributes(lpWindow);
		
		setContentView(R.layout.popup_common);
//		
		btnClose = (ImageButton) findViewById(R.id.popup_btn_close);
		btnClose.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				dismiss();
			}
		});
		
		tvTitle1 = (TextView) findViewById(R.id.txt_title1);
		tvTitle2 = (TextView) findViewById(R.id.txt_title2);
		
		if(StringUtils.isEmpty(subTitle)){
			tvTitle2.setVisibility(View.GONE);
			tvTitle1.setText(title);
			tvTitle1.setTextColor(Color.parseColor("#8E8E9E"));
		}else{
			tvTitle1.setText(title);
			tvTitle2.setText(subTitle);
		}

		webview = (WebView) findViewById(R.id.webview_popup);
		
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		webview.setWebViewClient(new WebViewClient(){
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				if(Const.LOG_FLAG){
					Log.d(Const.LOG_TAG, "onPageStarted : " + url.toString());
				}
				showProgress(CMR.string.process_job);
			}
			
			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				if(Const.LOG_FLAG){
					Log.d(Const.LOG_TAG, "onPageFinished : " + url.toString());
				}
				closeProgress();
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				// TODO Auto-generated method stub
				view.stopLoading();
				view.loadUrl(url);
				return false;
			}
			@Override
			public void onReceivedError(WebView view, int errorCode,
					String description, String failingUrl) {
				// TODO Auto-generated method stub
				view.loadData("<html><body></body></html>", "text/html", "UTF-8");
			}
			
			private ProgressDialog mProgressDialog;
			public void showProgress(String contents)
			{
				if(mProgressDialog!=null)
					closeProgress();
				mProgressDialog = ProgressDialog.show(context, "", contents, true, true);
			}
			
			public void closeProgress()
			{
				if(mProgressDialog!=null && mProgressDialog.isShowing()){
					mProgressDialog.dismiss();
				}
			}

        });

		webview.setWebChromeClient(new WebChromeClient(){
			@Override
			public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
				// TODO Auto-generated method stub
				return super.onCreateWindow(view, isDialog, isUserGesture, resultMsg);
			}

			@Override
			public boolean onJsAlert(WebView view, String url, final String message, final JsResult result) {
				// TODO Auto-generated method stub
				Builder dialog = new AlertDialog.Builder(context);
				dialog.setTitle("알림");
				dialog.setMessage(message);
				dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.confirm();
					}
				});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();

				return true;
			}

			@Override
			public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
				// TODO Auto-generated method stub
				Builder dialog = new AlertDialog.Builder(context);
				dialog.setTitle("알림");
				dialog.setMessage(message);
				dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.confirm();
					}
				});
				dialog.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.cancel();
					}
				});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();

				return super.onJsConfirm(view, url, message, result);
			}
		});
		
		webview.loadUrl(urlStr);
	}

	public CommPopupDialog(Context context) {
		super(context, android.R.style.Theme_Translucent_NoTitleBar);
		// TODO Auto-generated constructor stub
		this.context = context;
	}

	public CommPopupDialog(Context context, String urlStr, String title, String subTitle) {
		super(context, android.R.style.Theme_Translucent_NoTitleBar);
		// TODO Auto-generated constructor stub
		this.context = context;
		this.urlStr = urlStr;
		this.title = title;
		this.subTitle = subTitle;
	}

}
