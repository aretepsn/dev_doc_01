package com.hpapp.util;

import com.hpapp.res.Const;

import android.util.Log;

public class Debug_Log {
	public static boolean TEST_VER = Const.LOG_FLAG;
	public static boolean ISDEV = Const.IS_DEV;
	public Debug_Log() {
		// TODO Auto-generated constructor stub
	}

	public static void Log_E(String PTAG, String Pmsg) {
		if (TEST_VER) {
			Log.e(PTAG, "[SM] " + Pmsg);
		}
	}

	public static void Log_E(Object pCon, String Pmsg) {
		if (TEST_VER) {
			Log.e(pCon.getClass().getName().trim(), "[SM] " + Pmsg);
		}
	}

	public static void Log_E(Object pCon, String Pmsg1, String Pmsg2) {
		if (TEST_VER) {
			Log.e(pCon.getClass().getName().trim(), "[SM] " + Pmsg1);
		}
	}
}
