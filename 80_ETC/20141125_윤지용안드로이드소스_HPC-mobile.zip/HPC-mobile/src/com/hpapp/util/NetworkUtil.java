package com.hpapp.util;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.telephony.TelephonyManager;

import com.hpapp.R;

public class NetworkUtil {
	private Context context;
	private Handler hdlr;
	
	public NetworkUtil(Context context){
		this.context = context;
	}
	
	public NetworkUtil(Context context, Handler hdlr){
		this.context = context;
		this.hdlr = hdlr;
	}

	// 네트워크상태체크
	public boolean checkNetwokState() {
		if(hdlr == null){
			throw new RuntimeException("required handler.");
		}
		ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo mobile = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		NetworkInfo wifi = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		NetworkInfo lte_4g = manager.getNetworkInfo(ConnectivityManager.TYPE_WIMAX);
		boolean blte_4g = false;
		
		if (lte_4g != null)
			blte_4g = lte_4g.isConnected();
		if ((mobile!=null && mobile.isConnected()) || (wifi!=null && wifi.isConnected()) || blte_4g){
			return true;
		}else {
			// 여기는 걍 네트워크 상태 체크와 상관없는 연결이 잘 안될때 경고문 띄움
			AlertDialog.Builder dlg = new AlertDialog.Builder(context);
			dlg.setTitle("네트워크 오류");
			dlg.setMessage("네트워크 상태를 확인해 주십시요.");
			dlg.setIcon(R.drawable.ic_launcher);
			dlg.setNegativeButton("확인", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int whichButton) {
					hdlr.sendEmptyMessage(99);
				}
			});
			dlg.setCancelable(false);
			dlg.show();
			return false;
		}
	}

	public static boolean chkNetwork(Context context) {
		// TODO Auto-generated method stub
		boolean useNetwork = false;
		ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		TelephonyManager teleMgr = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		
		NetworkInfo activeNetInfo = connMgr.getActiveNetworkInfo();

		if(activeNetInfo==null){
//			 Toast.makeText(this, "인터넷이 연결되지 않았습니다.", Toast.LENGTH_SHORT).show();
			useNetwork = false;
		}else{
			 int netType = activeNetInfo.getType();
//			 int netSubtype = activeNetInfo.getSubtype();
			 
			 if (netType == ConnectivityManager.TYPE_WIFI) {
				 WifiManager wm = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
				 useNetwork = wm.startScan();
//				 Toast.makeText(this, "WIFI로 연결 됐습니다.", Toast.LENGTH_SHORT).show();
			 } else if (netType == ConnectivityManager.TYPE_MOBILE && !teleMgr.isNetworkRoaming()){
//			 } else if ((netType == ConnectivityManager.TYPE_MOBILE)
//					 && ((netSubtype == TelephonyManager.NETWORK_TYPE_UMTS)
//							 || (netSubtype == TelephonyManager.NETWORK_TYPE_1xRTT)
//							 || (netSubtype == TelephonyManager.NETWORK_TYPE_EDGE)
//							 || (netSubtype == TelephonyManager.NETWORK_TYPE_EVDO_0)
//							 || (netSubtype == TelephonyManager.NETWORK_TYPE_EVDO_A)
//							 || (netSubtype == TelephonyManager.NETWORK_TYPE_HSDPA)
//							 || (netSubtype == TelephonyManager.NETWORK_TYPE_HSPA)
//							 || (netSubtype == TelephonyManager.NETWORK_TYPE_HSUPA))
//					&& !teleMgr.isNetworkRoaming()) {
//				 Toast.makeText(this, activeNetInfo.getSubtypeName() + " 망으로 연결 됐습니다.", Toast.LENGTH_SHORT).show();
				 useNetwork = true;
			 }
		}
		
		return useNetwork;
	}

	public static int getNetType(Context context){
		int netType = 0;
		
		ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		
		NetworkInfo activeNetInfo = connMgr.getActiveNetworkInfo();

		if(activeNetInfo!=null){
			 netType = activeNetInfo.getType();
		}
		
		return netType;
	}

}
