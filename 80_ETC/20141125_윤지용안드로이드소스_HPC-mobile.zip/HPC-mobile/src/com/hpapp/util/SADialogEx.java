package com.hpapp.util;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.RelativeLayout;

/** Class Must extends with Dialog */
/** Implement onClickListener to dismiss dialog when OK Button is pressed */



public class SADialogEx extends Dialog implements OnClickListener {

	
	
	@Override
	public void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
	}

	@Override
	public Bundle onSaveInstanceState() {
		// TODO Auto-generated method stub
		return super.onSaveInstanceState();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		customizeDialogProcessing = false;
	}

	private static boolean customizeDialogProcessing = false;
	public View mView;
	
	public SADialogEx(Context context, View view, int w, int h) {
		super(context);
		/** 'Window.FEATURE_NO_TITLE' - Used to hide the title */
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		getWindow().setLayout(w, h);
		getWindow().setGravity(Gravity.CENTER);
		
		/** Design the dialog in main.xml file */
		RelativeLayout.LayoutParams param=SADynamicLayout.createParamRelativeLayout(w, h);
		param.addRule(RelativeLayout.CENTER_IN_PARENT);
		
		setContentView(view, param);
		
		customizeDialogProcessing = true;
		mView = view;
	}
	
	public SADialogEx(Context context, View view, int w, int h, int topMargin) {
		super(context);
		/** 'Window.FEATURE_NO_TITLE' - Used to hide the title */
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
		getWindow().setLayout(w, h);
		getWindow().setGravity(Gravity.CENTER_HORIZONTAL);
		
		/** Design the dialog in main.xml file */
		RelativeLayout.LayoutParams param=SADynamicLayout.createParamRelativeLayout(w, h);
		param.addRule(RelativeLayout.CENTER_HORIZONTAL);
		param.topMargin = topMargin;
		setContentView(view, param);
		
		customizeDialogProcessing = true;
		mView = view;
	}
	

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

	}
	
	public boolean IsProcessing()
	{
		if(customizeDialogProcessing==false)
			return false;
		
		/********************************************
		 * 홀드상태에서는 다이얼로그가 메세지를 수신하지 못함
		 * 따라서 view상태를 보고 다이얼로그를 보여준다.
		 */
//		Window  wd = getWindow();
		boolean visibility = mView.isShown();
		
		Log.d("[SADIALOG_EX]","visibile = "+visibility);
		return visibility;
	}
	
	public void setProcessing(boolean status){
		customizeDialogProcessing = status;
	}


}
