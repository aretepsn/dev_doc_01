/*
 * @(#)StringUtils.java
 * Copyright (c) NowOnPlay Inc., All rights reserved.
 * 2010. 3. 8. - First implementation.
 * contact : neoburi@nowonplay.com
 */
package com.hpapp.util;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>{@link String}과 관련한 유틸리티성 메소드를 보유한 클래스이다.</p>
 * <p>모든 Method는 Static way로 접근해야 한다.</p>
 * @author NowOnPlay Inc., neoburi@nowonplay.com, 2010 
 * @version 1.0 Since  2010. 3. 8.
 */
public final class StringUtils {
	/**
	 * 넘겨 받은 문자(열)이 null이거나 공백문자("")인가를 검증한다.
	 * @param s
	 * @return true : null이거나, 공백문자("")이다.
	 */
	public static boolean isEmpty( String s ){
		return s == null || "".equals(s);
	}
	/**
	 * 넘겨 받은 문자(열)이 null이거나 공백문자("") 또는 whitespace로만 구성되었는가를 검증한다.
	 * @param s
	 * @return true : null이거나, 공백문자("") 또는 whitespace로만 구성되었다. 
	 */
	public static boolean isEmptyOrWhiteSpace( String s ){
		return s == null || "".equals(s) || isWhiteSpace(s);
	}
	/**
	 * 두 문자(열)이 같은 문자(열)인가를 반환한다. 실제 값을 비교한다.
	 * source가 null일 경우 target도 null이간로 판단한다.
	 * @param source
	 * @param target
	 * @return true : 같다, source와 target이 모두 null일경우 true를 반환한다.
	 */
	public static boolean isEquals( String source, String target){
		if( source == null )
			return target == null;
		return source.equals(target);
	}
	/**
	 * 두 문자(열)이 같은 문자(열)인가를 반환한다. 실제 값을 비교한다.
	 * source가 null일 경우 target도 null인가로 판단한다.
	 * @param source
	 * @param target
	 * @return true : 같다, source와 target이 모두 null일경우 true를 반환한다.
	 */
	public static boolean isEqualsIgnoreCase( String source, String target){
		if( source == null )
			return target == null;
		return source.equalsIgnoreCase(target);
	}
	/**
	 * 문자열이 스페이스문자(" ")만으로 이루어 졌는가를 검사한다. Escape문자는 검사하지 않느다.
	 * @param s
	 * @return true : 스페이스문자로만 이루어 졌다. null이나 공백문자("")일 경우 false를 반환한다.
	 */
	public static boolean isWhiteSpace(String s){
		if(isEmpty(s))
			return false;
		char c;
		for( int i = 0, n = s.length(); i < n;i++ ){
			c = s.charAt(i);
			if( c != ' '){
				return false; 
			}
		}
		return true;
	}
	/**
	* 문자(열)주에서 특정 문자(열)을 주어진 문자(열)로 치환 한 후 반환한다.
	* @param mainString 문자열을 치환할 원 소스
	* @param oldString 치환 대상이 되는 문자(열)
	* @param newString 치환 할 문자(열)
	* @return mainStrina에서 oldString을 newString으로 바꾼 문자열
	*/
	public synchronized static String replace(
		String mainString,
		String oldString,
		String newString) {
		if (mainString == null)
			return null;
		if (oldString == null || oldString.length() == 0)
			return mainString;
		if (newString == null)
			newString = "";
		int i = mainString.lastIndexOf(oldString);
		if (i < 0)
			return mainString;
		StringBuffer mainSb = new StringBuffer(mainString);
		while (i >= 0) {
			mainSb.replace(i, (i + oldString.length()), newString);
			i = mainString.lastIndexOf(oldString, i - 1);
		}
		return mainSb.toString();
	}	
	
	/**
	*문자열에서 첫 번 째 특정 문자(열)을 원하는 문자(열)로 치환해서 반환 한다.
	* 처음 나타나는 한 번만 치환 한다.
	*@param String : 바꿀 대상 문자(열)
	*@param String : 바꾸고자 하는 문자(열)
	*@param String : 바꿀 문자(열)
	*@return String
	*/
	public static String replaceFirst(String s, String source, String target) {
		return (s != null && s.indexOf(source) != -1)
			? s.replaceFirst(source, target)
			: s;
	}
	
	/**
	*문자열을 특정 위치에서 잘라서 반환한다.
	*@param String : 문자(열)
	*@param int :문자(열)을 자를 길이. 이 길이는 Byte단위이다.(한글 * 2 )
	*@param suffix : 끝에 붙일 문자열
	*@return String
	*/
	public synchronized static String cut(String str, int len, String suffix) {
		if (str == null || "".equals(str))
			return "none";
		int slen = 0, blen = 0;
		int depth = 0;
		char c;
		try {
			if (str.getBytes("MS949").length > len - depth) {
				while (blen + 1 < len - depth) {
					c = str.charAt(slen);
					blen++;
					slen++;
					if (c > 127)
						blen++; //2-byte character..
				}
				str = str.substring(0, slen) + suffix;
			}
		} catch (java.io.UnsupportedEncodingException e) {
			return str;
		}
		return str;
	}
	
	/**
	 * source 문자열을 limit길이 만큼 자르고 postfix추가
	 * 사용법 cutString("하나", 1, " ...") -> 하 ... 반환한다.
	 * @param source
	 * @param limit
	 * @param postfix
	 * @return String
	 */
	public static String cutString(String source, int limit, String postfix) {
		if(source == null || source.trim().length() == 0){
			source = "";
		}else{
			//byte[] tmp = source.getBytes();
			int length = source.length();
			int count = 0;
			int index = 0;
	
			if (length < (limit / 2))
				return source;
	
			while (index < length && count < limit) {
				if (source.charAt(index++) < 256) {
					count++;
				} else {
					if (count < limit - 3)
						count += 2;
					else
						break;
				}
			}
			if (index < length) {
				source = source.substring(0, index).concat(postfix);
			}
		}
		return source;
	}
	
	/**
	 * 특정 문자열에서 지정한 문자(열)을 제거한 후 반환한다.
	 * @param source 제거할 문자(열)을 포함하는 원천 문자(열)
	 * @param s 제거할 문자(열)
	 * @return 지정한 문자(열)이 제거된 문자(열)
	 */
	public static String remove(String source, String s){
		return replace(source, s, "");
	}
	/**
	 * 숫자형 문자를 받아 숫자(int type)으로 반환한다.
	 * @param s
	 * @return
	 */
	public synchronized static int toDigit( String s ){
		if( isEmpty(s))
			return 0;
		if( isDigit(s)){
			return Integer.parseInt(s);
		}
		return 0;
	}
	/**
	 * 넘겨받은 문자(열)이 숫자로만 이루어 진 것인가를 검증한다.
	 * @param str 
	 * @return boolean
	 * @see java.lang.Character#isDigit(char)
	 */
	public synchronized static boolean isDigit(String str) {
		boolean digit = false;
		if (!isEmpty(str)) {
			for (int i = 0; i < str.length(); i++) {
				digit = Character.isDigit(str.charAt(i));
				if (!digit) {
					break;
				}
			}
		}
		return digit;
	}
	/**
	 * 문자(열)을 받아 주어진 횟수만큼 반복해서 반환한다.
	 * @param source 반복할 문자(열)
	 * @param howMany 반복할 횟수
	 * @return howMany만큼 반복 된 문자(열)
	 */
	public synchronized static String repeat(String source, int howMany){
		String returnString = "";
		for( int i = 0; i < howMany; i++ ){
			returnString += source;
		}
		return returnString;
	}
	/**
	 * 문자(열)에 제외하고자 하는 문자(열)이 존재하는가를 검증한다. 제외하고자 하는 문자(열)은
	 * 반드시 ","로 구분 되어야 한다.
	 * @param source
	 * @param compare
	 * @return true - source에 compare가 존재한다. false-그렇지 않다.
	 * @since jdk 1.4
	 */
	public static boolean contains( String source, String compare){
		boolean exclude = false;
		if( isEmpty(source ) ){
			return exclude;
		}
		String[] elm = compare.split(",");
		for( int i = 0; i < elm.length; i++ ){
			if( source.indexOf(elm[i]) != -1 ){
				return true;
			}
		}
		return exclude;
	}
	/**
	 * 문자(열)에 제외하고자 하는 문자(열)이 존재하는가를 검증한다. 제외하고자 하는 문자(열)은
	 * 반드시 ","로 구분 되어야 한다. 대소문자를 구분하지 않는다.
	 * @param source
	 * @param compare
	 * @return true - source에 compare가 존재한다. false-그렇지 않다.
	 * @since jdk1.4
	 */
	public static boolean containsIgnoreCase( 
			String source, String compare){
		boolean exclude = false;
		if( isEmpty(source ) ){
			return exclude;
		}
		String[] elm = compare.split(",");
		for( int i = 0; i < elm.length; i++ ){
			if( source.toLowerCase().indexOf(elm[i].toLowerCase()) != -1 ){
				return true;
			}
		}
		return exclude;
	}
	/**
	 * 문자열을 start부터 end까지 발췌하여 반환한다.
	 * @param str 발췌할 원본문자열
	 * @param start 시작점
	 * @param end 종료점. -1이면 start이후의 모든 문자(열)을 대상으로 한다.
	 * @return start부터 end까지 문자열
	 */
	public static String substr(String str, int start, int end){
		if( end == -1 ){
			return str.substring(start);
		}
		return str.substring(start, end);
	}

	/**
	 * &lt;script 태그
	 */
	private static final Pattern SCRIPT_TAG = 
		Pattern.compile("<script|</script|%3CSCRIPT", Pattern.CASE_INSENSITIVE);
	/**
	 * script inline tag
	 */
	private static final Pattern SCRIPT_INLINE_TAG = 
		Pattern.compile("javascript", Pattern.CASE_INSENSITIVE);
	/**
	 * &amp;tag
	 */
	private static final Pattern AMP_TAG = 
		Pattern.compile("&", Pattern.CASE_INSENSITIVE);
	
	/**
	 * object tag
	 */
	private static final Pattern OBJECT_TAG = 
		Pattern.compile("<object|< object", Pattern.CASE_INSENSITIVE);
	/**
	 * event와 관련한 tag
	 */
	private static final Pattern EVENT_RELATION_TAG = 
		Pattern.compile(
				"onabort|"+
				"onactivate|"+
				"onafterprint|"+
				"onafterupdate|"+
				"onbeforeactivate|"+
				"onbeforecopy|"+
				"onbeforecut|"+
				"onbeforedeactivate|"+
				"onbeforeeditfocus|"+
				"onbeforepaste|"+
				"onbeforeprint|"+
				"onbeforeunload|"+
				"onbeforeupdate|"+
				"onbegin|"+
				"onblur|"+
				"onbounce|"+
				"oncellchange|"+
				"onchange|"+
				"onclick|"+
				"oncontentready|"+
				"oncontentsave|"+
				"oncontextmenu|"+
				"oncontrolselect|"+
				"oncopy|"+
				"oncut|"+
				"ondataavailable|"+
				"ondatasetchanged|"+
				"ondatasetcomplete|"+
				"ondblclick|"+
				"ondeactivate|"+
				"ondetach|"+
				"ondocumentready|"+
				"ondrag|"+
				"ondragdrop|"+
				"ondragend|"+
				"ondragenter|"+
				"ondragleave|"+
				"ondragover|"+
				"ondragstart|"+
				"ondrop|"+
				"onend|"+
				"onerror|"+
				"onerrorupdate|"+
				"onfilterchange|"+
				"onfinish|"+
				"onfocus|"+
				"onfocusin|"+
				"onfocusout|"+
				"onhelp|"+
				"onhide|"+
				"onkeydown|"+
				"onkeypress|"+
				"onkeyup|"+
				"onlayoutcomplete|"+
				"onload|"+
				"onlosecapture|"+
				"onmediacomplete|"+
				"onmediaerror|"+
				"onmedialoadfailed|"+
				"onmousedown|"+
				"onmouseenter|"+
				"onmouseleave|"+
				"onmousemove|"+
				"onmouseout|"+
				"onmouseover|"+
				"onmouseup|"+
				"onmousewheel|"+
				"onmove|"+
				"onmoveend|"+
				"onmovestart|"+
				"onopenstatechange|"+
				"onoutofsync|"+
				"onpaste|"+
				"onpause|"+
				"onplaystatechange|"+
				"onpropertychange|"+
				"onreadystatechange|"+
				"onrepeat|"+
				"onreset|"+
				"onresize|"+
				"onresizeend|"+
				"onresizestart|"+
				"onresume|"+
				"onreverse|"+
				"onrowclick|"+
				"onrowenter|"+
				"onrowexit|"+
				"onrowout|"+
				"onrowover|"+
				"onrowsdelete|"+
				"onrowsinserted|"+
				"onsave|"+
				"onscroll|"+
				"onseek|"+
				"onselect|"+
				"onchange|"+
				"onselectstart|"+
				"onshow|"+
				"onstart|"+
				"onstop|"+
				"onsubmit|"+
				"onsyncrestored|"+
				"ontimeerror|"+
				"ontrackchange|"+
				"onunload|"+
				"onurlflip", 
				Pattern.CASE_INSENSITIVE);
	/**
	 * Javascript와 관련한 것을 무효화 시킨다.
	 * @param text 
	 * @return
	 */
	public static String striptScript(String text){
		String s = text;
		Matcher m = SCRIPT_TAG.matcher(s);
		if( m.find()){
			s = m.replaceAll("&lt;script");
		}
		m = SCRIPT_INLINE_TAG.matcher(s);
		if( m.find()){
			s = m.replaceAll("java_script");
		}
		m = AMP_TAG.matcher(s);
		if( m.find()){
			//s = m.replaceAll("&amp;");
		}
		m = OBJECT_TAG.matcher(s);
		if( m.find()){
			s = m.replaceAll("&amp;object");
		}
		m = EVENT_RELATION_TAG.matcher(s);
		if( m.find()){
			s = m.replaceAll("_onevent");
		}
		return s;
	}
	/**
	 * SQL Injection이 가능한 문자를 제거후 반환한다.
	 * 제거대상 문자는 (;-:='"%\#)이다.
	 * @param str
	 * @return
	 */
	public static String stripInjectString(String str){
		if(isEmpty(str))
			return str;
		return str.replaceAll("[;|\\-|\\:|\\=|\\'|\\\"|%|\\\\|#]", "");
	}

	/**
	*int를 넘겨 받아 지정된 길이 만큼 숫자 앞에 0을 채운 문자열을 반환 한다.
	*@param len
	*@param value
	*@return String
	*/
	public synchronized static String zeroFill(int len, int value) {
		String str = Integer.toString(value);
		int loop = len - str.length();
		String rtStr = "";
		for (int i = 0; i < loop; i++) {
			rtStr += "0";
		}
		return rtStr + str;
	}
	/**
	*문자형 숫자를 넘겨 받아 지정된 길이 만큼 숫자 앞에 0을 채운 문자열을 반환 한다.
	*@param len
	*@param value
	*@return String value가 숫자형 문자가 아니면 "00"을 반환한다.
	*/
	public synchronized static String zeroFill(int len, String value) {
		if (isEmpty(value) || !isDigit(value)) {
			return "00";
		}
		String str = value.trim();
		int loop = len - str.length();
		String rtStr = "";
		for (int i = 0; i < loop; i++) {
			rtStr += "0";
		}
		return rtStr + str;
	}
	/**
	 * [(-)(+)0-9]숫자 또는 [(-)(+)0-9.0-9]로 이루어진 문자열 패턴. 이하 소수 100자리 까지이다.
	 */
	public static Pattern NUMERIC_PATTERN = Pattern.compile( "^(-?(\\+?)[0-9])$|^((-?(\\+?)[0-9]+.[0-9]{0,100}))$" );
    /**
    *[(-)(+)0-9]숫자 또는 [(-)(+)0-9.0-9]로 이루어진 문자열인가를 검증 한다.
    *
	*@param s 검증 할 문자(열)
	*@return true : 숫자형 문자(열), false : 숫자 이외의 문자가 포함되어 있음
	*/
	public static boolean isNumeric( String s ){
	    return NUMERIC_PATTERN.matcher( s ).find();
	}
	private static final String HTML_REGEX = "(?:<!--.*?(?:--.*?--\\s*)*.*?-->)|(?:<(?:[^>'\"]*|\".*?\"|'.*?')+>)";
//	private static final String HTML_REGEX = "<(/)?([a-zA-Z]*)(\\s[a-zA-Z]*=[^>]*)?(\\s)*(/)?>";
	@SuppressWarnings("unused")
	private static final Pattern HTML_PATTERN = Pattern.compile(HTML_REGEX, Pattern.DOTALL);
	/**
	 * Strip HTML code
	 * @param text
	 * @return
	 */
	public static String stripHTML(String text){
		if(text == null || isEmptyOrWhiteSpace(text)){
			return "";
		}
		String txt  = text.replaceAll(HTML_REGEX, "");
		String[] tts = txt.split(" ");
		String ss = "";
		for( String s : tts ){
			s = s != null ? s.replaceAll("\\s", "") : "";
			if(!isEmptyOrWhiteSpace(s)){
				ss += s.trim() + " ";
			}
		}
		return ss;
	}
	
	/**
	 * List<String>을 받아 ","로 구분 하여 String 반환 한다.
	 * @param source javascript가 포함된 문자열
	 * @return javascript와 관련한 문자열이 무력화된 것.
	 */
	public static String stringListFormString(List<String> source){
		if( source == null || source.size() <= 0 ){
			return "";
		}
		String s = "";
		int index = 0;
		for( int i = 0; i < source.size(); i++ ){
			String str = source.get(i);
			if( isEmpty(str) ){
				continue;
			}			
			
			if( index > 0 ){
				s += ",";
				
			}			
			s += str;
			index++;
		}
		return s;
	}
	
	/**
	 * 기본 생성자이다.
	 * @return
	 */
	private StringUtils(){}
}
