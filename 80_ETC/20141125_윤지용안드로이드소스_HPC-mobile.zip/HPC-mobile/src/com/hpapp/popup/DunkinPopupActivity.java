package com.hpapp.popup;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;

import org.apache.http.util.EncodingUtils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.provider.Browser;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.hpapp.R;
import com.hpapp.activity.HPCActivity;
import com.hpapp.activity.HPCWebActivity;
import com.hpapp.activity.LoginActivity;
import com.hpapp.address.AddressActivity;
import com.hpapp.res.Const;
import com.hpapp.util.Debug_Log;
import com.hpapp.util.StringUtils;

public class DunkinPopupActivity extends Activity{

	private WebView webview;
    private static final int DIALOG_PROGRESS_WEBVIEW = 0;
    private static final int DIALOG_PROGRESS_MESSAGE = 1;
    private static final int DIALOG_ISP = 2;
	protected static String callback_contact;
    private FileDownloadTask downloadTask;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		Debug_Log.Log_E(this, "onCreate()");
//		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND, WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.argb(180, 125, 125, 125)));
		setContentView(R.layout.popup);
		
		Intent intent = getIntent();
		
		String url = intent.getStringExtra("url");
		String param = intent.getStringExtra("param");
		String type = intent.getStringExtra("type");
		String approval = "";
		Debug_Log.Log_E(this,"PopupActivity url : " + url);
		
		
		Debug_Log.Log_E(this,"PopupActivity param : " + param);
		Debug_Log.Log_E(this,"PopupActivity type : " + type);
		
		if(Intent.ACTION_VIEW.equals(intent.getAction())){
			
			Uri uri = intent.getData();
			String decordURI = "";
			try {
				decordURI = URLDecoder.decode(uri.toString(), "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			Debug_Log.Log_E(this,"intent.getAction() decordURI : " + decordURI);
			uri = Uri.parse(decordURI);
			url = uri.getQueryParameter("URL");
			approval = uri.getQueryParameter("approval_key");
			Debug_Log.Log_E(this,"intent.getAction() url : " + url);
			param = null;
			type = "PAYMENT";
		}
		
		TextView title = (TextView) findViewById(R.id.txt_pop_title);
		
		ImageButton btnClose = (ImageButton) findViewById(R.id.btn_close);
		btnClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		if("PAYMENT".equals(type)){
			title.setText("결제하기");
		}else if("SIGNUP".equals(type)){
			title.setText("회원가입");
		}else{
			RelativeLayout header = (RelativeLayout) findViewById(R.id.header);
			header.setVisibility(View.GONE);
		}
		
		webview = (WebView) findViewById(R.id.popup);
		webview.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setSupportMultipleWindows(true);
		webview.addJavascriptInterface(new JavaScriptExtention(), "android");
		webview.getSettings().setUseWideViewPort(true);
		webview.setInitialScale(1);

		webview.setWebViewClient(new PaymentWebViewClient());
		webview.setDownloadListener(new DownloadListener() {
		    @Override
		    public void onDownloadStart(String url, String userAgent,
		    		String contentDisposition, String mimeType, long contentLength) {
			     //URL에 apk파일이 링크되었을 경우
			     if( url.endsWith(".apk"))
				 {
			    	//재실행에 대한 처리
			    	if( downloadTask == null )
			    	{
			    		downloadTask = new FileDownloadTask(url,contentLength);
			    	}
			    	else
			    	{
			    		downloadTask.cancel(true);
			    		downloadTask = null;
			    		downloadTask = new FileDownloadTask(url,contentLength);
			    	}
			    	downloadTask.execute();
				 }
		    }
		});

		webview.setWebChromeClient(new WebChromeClient(){
			@Override
			public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
				// TODO Auto-generated method stub
				return super.onCreateWindow(view, isDialog, isUserGesture, resultMsg);
			}

			@Override
			public boolean onJsAlert(WebView view, String url, final String message, final JsResult result) {
				// TODO Auto-generated method stub
				Builder dialog = new AlertDialog.Builder(DunkinPopupActivity.this);
				dialog.setTitle("알림");
				dialog.setMessage(message);
				dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.confirm();
					}
				});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();
				return true;
			}

			@Override
			public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
				// TODO Auto-generated method stub
				Builder dialog = new AlertDialog.Builder(DunkinPopupActivity.this);
				dialog.setTitle("알림");
				dialog.setMessage(message);
				dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.confirm();
					}
				});
				dialog.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.cancel();
					}
				});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();

				return true;
			}
		});
		
		if (param == null || param == "") {
				webview.loadUrl(url);
				Debug_Log.Log_E(this, "loadUrl url : " + url );
		} else {
			webview.postUrl(url, EncodingUtils.getBytes(param, "utf-8"));
			Debug_Log.Log_E(this, "postUrl url + param : " + url + param);
		}
	}
	
	@Override
	protected void onRestart() {
		Debug_Log.Log_E(this, "onRestart()");
		super.onRestart();
	}
	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		Debug_Log.Log_E(this, "onNewIntent()");
		Debug_Log.Log_E(this, "intent.getAction() : " + intent.getAction());
		String url = "";
		if (Intent.ACTION_VIEW.equals(intent.getAction())) {
			Uri uri = intent.getData();
			String decordURI = "";
			try {
				decordURI = URLDecoder.decode(uri.toString(), "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			Debug_Log.Log_E(this, "intent.getAction() decordURI : " + decordURI);
			uri = Uri.parse(decordURI);
			url = uri.getQueryParameter("URL");
			String approval = uri.getQueryParameter("approval_key");
			Debug_Log.Log_E(this, "intent.getAction() url : " + url);
			if (approval != "") {
				String sep = "?";
				if (url.indexOf("?") > -1)
					sep = "&";
				String strApprovalKey = approval.substring( 0, approval.length() - 4  );
				Debug_Log.Log_E(this, "approval : " + approval);
				webview.loadUrl( Const.HOST_URL_DANAL_PAGE+"&approval_key=" + strApprovalKey );
				Debug_Log.Log_E(this, "webview.getUrl() : " + webview.getUrl());
			}
		}
	}
	
	@Override
	protected void onResume() {
		Debug_Log.Log_E(this, "onResume()");
		super.onResume();
		Intent intent = getIntent();
		Debug_Log.Log_E(this, "intent.getAction() : " + intent.getAction());
	}
	
	// 웹뷰에서 스크립트로 디바이스 접근 
	final class JavaScriptExtention{
		JavaScriptExtention(){}
		
		/**
		 * window.android.setCardNo(param);
		 * 카드번호 저장
		 * @param param
		 */
		@JavascriptInterface
		public void setCardNo(String mbCardNo, boolean isReset){
			SharedPreferences pref = getSharedPreferences("SPC-mobile", Activity.MODE_PRIVATE);
			SharedPreferences.Editor editor = pref.edit();
		
			editor.putString(Const.SP_CARDNO, mbCardNo);
//			editor.putString(Const.SP_RECOMMEND, recommend);
			editor.commit();
			
			new BarcodeDown().execute(mbCardNo);

			if(isReset){
				Builder dialog = new AlertDialog.Builder(DunkinPopupActivity.this);
				dialog.setTitle("알림");
				dialog.setMessage("모바일카드가 적용 되었습니다.");
				dialog.setPositiveButton("확인", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						boolean isKill = true;
						
						if(isKill){
							Intent intent = new Intent(DunkinPopupActivity.this, HPCActivity.class);
							intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
							finish();
							startActivity(intent);
						}else{
							finish();
						}
					}
				});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();
			}
		}
		
		/**
		 * window.android.setAuthInfo(name, ci);
		 * 이름/CI 저장
		 * @param param
		 */
		@JavascriptInterface
		public void setAuthInfo(String name, String ci, String recommend, String recomTitle, String recomContent, String hpcno){
			SharedPreferences pref = getSharedPreferences("SPC-mobile", Activity.MODE_PRIVATE);
			SharedPreferences.Editor editor = pref.edit();

//			System.out.println("name = " + name);
//			System.out.println("ci = " + ci);
//			System.out.println("recommend = " + recommend);
//			System.out.println("recomTitle = " + recomTitle);
//			System.out.println("recomContent = " + recomContent);
//			System.out.println("hpcno = " + hpcno);
			editor.putString("name", name); 
			editor.putString("CI", ci);
			editor.putString("id", "");
			editor.putString("pwd", "");
			editor.putBoolean("autoLogin", false);
			editor.putString(Const.SP_RECOMMEND, recommend);
			editor.putString(Const.SP_RECOMMEND_TITLE, recomTitle);
			editor.putString(Const.SP_RECOMMEND_CONTENT, recomContent);
			editor.putString(Const.SP_HPCNO, hpcno);
			editor.commit();
		}

		/**
		 * 연락처 목록 호출
		 * @param callback
		 */
		@JavascriptInterface
		public void callAddrBook(String callback){
			callback_contact = callback;
			// 주소록 목록 띄우기
//			Intent i = new Intent(Intent.ACTION_PICK);
//			i.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE);
			Intent i = new Intent(DunkinPopupActivity.this, AddressActivity.class);
			startActivityForResult(i, Const.REQ_PICK_CONTACT);
		}
		
		/**
		 * 연락처 목록 호출
		 * @param dunkincallback
		 */
		@JavascriptInterface
		public void callAddrBook(String callback, String mCount){
			callback_contact = callback;
			// 주소록 목록 띄우기
//			Intent i = new Intent(Intent.ACTION_PICK);
//			i.setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE);
			int Count = 5;
			Count = Integer.parseInt(mCount);
			Intent i = new Intent(DunkinPopupActivity.this, AddressActivity.class);
			i.putExtra("count", Count);
			startActivityForResult(i, Const.REQ_PICK_CONTACT);
		}

		@JavascriptInterface
		public void goMain(){
			Debug_Log.Log_E(this,"goMain()");
			setResult(RESULT_OK);
			finish();
		}

		/**
		 * 창 종료
		 */
		@JavascriptInterface
		public void closeActivity(){
			Debug_Log.Log_E(this,"closeActivity()");
			finish();
		}
		
		/**
		 * 페이지 이동
		 * @param url
		 */
		@JavascriptInterface
		public void closeActivity(String url){
			Debug_Log.Log_E(this,"closeActivity() : " + url);
			Intent intent = new Intent(DunkinPopupActivity.this, HPCWebActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
			intent.putExtra("url", url);
			intent.putExtra("param", "");
			startActivity(intent);
			overridePendingTransition(0, 0);
			finish();
//			Intent intent = new Intent();
//			intent.putExtra("url", url);
//			
//			setResult(RESULT_OK, intent);
		}
		
		/**
		 * 링크 밖으로 빼서 이동
		 * @param url
		 */
		@JavascriptInterface
		public void goWebOut(String url) {
			Debug_Log.Log_E(this,"goWebOut() : " + url);
			Uri uri = Uri.parse(url);
			Intent intent = new Intent(Intent.ACTION_VIEW, uri);
			startActivity(intent);			
		}
		
		/**
		 * 로그인화면으로 이동
		 */
		@JavascriptInterface
		public void loginActivity() {
			Debug_Log.Log_E(this,"loginActivity()");
			Intent intent = new Intent(DunkinPopupActivity.this, LoginActivity.class);
			startActivity(intent);
		}
	}

	// 바코드 다운로드
	private class BarcodeDown extends AsyncTask<String, Boolean, Boolean>{
		
		String cardNo;
		File file;

		@Override
		protected Boolean doInBackground(String... param) {
			// TODO Auto-generated method stub
			this.cardNo = param[0];
			boolean check = false;
			String pathRoot = "";
			String pathBarcode = "";

			if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
				pathRoot = Environment.getExternalStorageDirectory().getAbsolutePath() + "/spc";
			else
				pathRoot = Environment.getDataDirectory().getAbsolutePath() + "/spc";
			pathBarcode = pathRoot + "/.nomedia"; 
			
			if(!StringUtils.isEmpty(cardNo)){
				String fileName = "spc_"+cardNo+".png";

				DeleteDir(pathRoot);

				File dir = new File(pathBarcode);
				if(!dir.exists())
					dir.mkdirs();
				
				this.file = new File(pathBarcode+"/"+fileName);
				
				check = downloadBarcode(file, cardNo);
			}
			return check;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			if(result){
				Toast.makeText(getApplicationContext(), "바코드가 다운로드 되었습니다.", Toast.LENGTH_SHORT).show();
			}
		}

	    // 폴더삭제(하위폴더 포함)
	    void DeleteDir(String path) 
	    { 
	        File file = new File(path);
	        if(file.exists()){
	            File[] childFileList = file.listFiles();
	            for(File childFile : childFileList)
	            {
	                if(childFile.isDirectory()) {
	                    DeleteDir(childFile.getAbsolutePath());     //하위 디렉토리 루프 
	                }
	                else {
	                    childFile.delete();    //하위 파일삭제
	                }
	            }      
	           file.delete();    //root 삭제 
	        }
	    }

	    // 바코드 다운로드
		private boolean downloadBarcode(File file, String mbCardNo){
			int read;
			try{
				URL url = new URL("http://110.45.199.242:8099/barcode.php?str="+mbCardNo);
//				URL url = new URL("http://115.144.168.14:8088/barcode/barcode.php?str="+mbCardNo);
				HttpURLConnection conn = (HttpURLConnection)url.openConnection();
				int len = conn.getContentLength();
				byte[] bt = new byte[len];
				InputStream is = conn.getInputStream();
				FileOutputStream fos = new FileOutputStream(file);
				
				while(true){
					read = is.read(bt);
					if(read<=0)break;
					fos.write(bt, 0, read);
				}
				is.close();
				fos.close();
				conn.disconnect();
				
			}catch(IOException e){
				Log.e(Const.LOG_TAG, e.getMessage());
				return false;
			}
			return true;
		}
	}
	
	// App 체크 메소드 // 존재:true, 존재하지않음:false
	public static boolean isPackageInstalled(Context ctx, String pkgName) {
		try {
			ctx.getPackageManager().getPackageInfo(pkgName, PackageManager.GET_ACTIVITIES);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public void showAlert(String message, String positiveButton, DialogInterface.OnClickListener positiveListener, String negativeButton, DialogInterface.OnClickListener negativeListener) {
		AlertDialog.Builder alert = new AlertDialog.Builder(this);
		alert.setMessage(message);
		alert.setPositiveButton(positiveButton, positiveListener);
		alert.setNegativeButton(negativeButton, negativeListener);
		alert.show();
	}
	
	private class PaymentWebViewClient extends WebViewClient {
	
		@Override
	    public boolean shouldOverrideUrlLoading(final WebView view, String url) {
	    	try {
	    		url = URLDecoder.decode(url, "UTF-8");
				Debug_Log.Log_E(this, "shouldOverride.url : " + url);
			} catch (UnsupportedEncodingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			Log.d("================url::", url);
			if ((url.startsWith("http://") || url.startsWith("https://")) && url.endsWith(".apk")) {
//				downloadFile(url);
				downloadFile(url);
				return super.shouldOverrideUrlLoading(view, url);
			} else if ((url.startsWith("http://") || url.startsWith("https://")) && (url.contains("market.android.com") || url.contains("m.ahnlab.com/kr/site/download"))) {
				Uri uri = Uri.parse(url);
				Intent intent = new Intent(Intent.ACTION_VIEW, uri);
				try {
					startActivity(intent);
					return true;
				} catch (ActivityNotFoundException e) {
					return false;
				}
			} else if (url.startsWith("http://") || url.startsWith("https://")) {
				view.loadUrl(url);
				return true;
			} else if (url != null
					&& (url.contains("vguard") || url.contains("droidxantivirus") || url.contains("smhyundaiansimclick://") || url.contains("mvaccine")
							|| url.contains("smshinhanansimclick://") || url.contains("smshinhancardusim://") || url.contains("smartwall://") || url.contains("appfree://")
							|| url.contains("v3mobile") || url.endsWith(".apk") || url.contains("market://") || url.contains("ansimclick")
							|| url.contains("market://details?id=com.shcard.smartpay") || url.contains("shinhan-sr-ansimclick://")|| url.contains("ispmobile")||url.contains("smartxpay-transfer")||url.contains("paypin")||url.contains("lguthepay")||url.contains("cloudpay"))) {
				Intent intent = null;
				// 인텐트 정합성 체크 : 2014 .01추가
				try {
					intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
					Debug_Log.Log_E(this, "인텐트 정합성 체크");
					Debug_Log.Log_E(this, "ntent.getScheme() " +intent.getScheme());
					Debug_Log.Log_E(this, "intent.getDataString() : " + intent.getDataString());
					Log.e("intent getScheme     +++===>", intent.getScheme());
					Log.e("intent getDataString +++===>", intent.getDataString());
				} catch (URISyntaxException ex) {
					Log.e("Browser", "Bad URI " + url + ":" + ex.getMessage());
					return false;
				}
				try {
					boolean retval = true;
					//chrome 버젼 방식 : 2014.01 추가						
					if (url.startsWith("intent")) { // chrome 버젼 방식
						// 앱설치 체크를 합니다.
						if (getPackageManager().resolveActivity(intent, 0) == null) {
							String packagename = intent.getPackage();
							if (packagename != null) {
								Uri uri = Uri.parse("market://search?q=pname:" + packagename);
								intent = new Intent(Intent.ACTION_VIEW, uri);
								startActivity(intent);
								retval = true;
							}
						} else {
							intent.addCategory(Intent.CATEGORY_BROWSABLE);
							intent.setComponent(null);
							try {
								if (startActivityIfNeeded(intent, -1)) {
									retval = true;
								}
							} catch (ActivityNotFoundException ex) {
								retval = false;
							}
						}
					} else { // 구 방식
						Uri uri = Uri.parse(url);
						intent = new Intent(Intent.ACTION_VIEW, uri);
						startActivity(intent);
						retval = true;
					}
					return retval;
				} catch (ActivityNotFoundException e) {
					Log.e("error ===>", e.getMessage());
					e.printStackTrace();
					return false;
				}
			} else if (url.startsWith("smartxpay-transfer://")) {
				boolean isatallFlag = isPackageInstalled(getApplicationContext(), "kr.co.uplus.ecredit");
				if (isatallFlag) {
					boolean override = false;
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
					intent.addCategory(Intent.CATEGORY_BROWSABLE);
					intent.putExtra(Browser.EXTRA_APPLICATION_ID, getPackageName());

					try {
						startActivity(intent);
						override = true;
					} catch (ActivityNotFoundException ex) {
					}
					return override;
				} else {
					showAlert("확인버튼을 누르시면 구글플레이로 이동합니다.", "확인", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(("market://details?id=kr.co.uplus.ecredit")));
							intent.addCategory(Intent.CATEGORY_BROWSABLE);
							intent.putExtra(Browser.EXTRA_APPLICATION_ID, getPackageName());
							startActivity(intent);
							overridePendingTransition(0, 0);
						}
					}, "취소", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							dialog.cancel();
						}
					});
					return true;
				}
			} else if (url.startsWith("ispmobile://")) {
				boolean isatallFlag = isPackageInstalled(getApplicationContext(), "kvp.jjy.MispAndroid320");
				if (isatallFlag) {
					boolean override = false;
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
					intent.addCategory(Intent.CATEGORY_BROWSABLE);
					intent.putExtra(Browser.EXTRA_APPLICATION_ID, getPackageName());

					try {
						startActivity(intent);
						override = true;
//						if( url.startsWith("ispmobile://"))
//		    			{
//		    				finish();
//		    			}
					} catch (ActivityNotFoundException ex) {
					}
					return override;
				} else {
					showAlert("확인버튼을 누르시면 구글플레이로 이동합니다.", "확인", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							view.loadUrl("http://mobile.vpay.co.kr/jsp/MISP/andown.jsp");
						}
					}, "취소", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							dialog.cancel();
						}
					});
					return true;
				}
			} else if (url.startsWith("paypin://")) {
				boolean isatallFlag = isPackageInstalled(getApplicationContext(), "com.skp.android.paypin");
				if (isatallFlag) {
					boolean override = false;
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
					intent.addCategory(Intent.CATEGORY_BROWSABLE);
					intent.putExtra(Browser.EXTRA_APPLICATION_ID, getPackageName());

					try {
						startActivity(intent);
						override = true;
					} catch (ActivityNotFoundException ex) {
					}
					return override;
				} else {
					Intent intent = new Intent(Intent.ACTION_VIEW,
							Uri.parse(("market://details?id=com.skp.android.paypin&feature=search_result#?t=W251bGwsMSwxLDEsImNvbS5za3AuYW5kcm9pZC5wYXlwaW4iXQ..")));
					intent.addCategory(Intent.CATEGORY_BROWSABLE);
					intent.putExtra(Browser.EXTRA_APPLICATION_ID, getPackageName());
					startActivity(intent);
					overridePendingTransition(0, 0);
					return true;
				}
			} else if (url.startsWith("lguthepay://")) {
				boolean isatallFlag = isPackageInstalled(getApplicationContext(), "com.lguplus.paynow");
				if (isatallFlag) {
					boolean override = false;
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
					intent.addCategory(Intent.CATEGORY_BROWSABLE);
					intent.putExtra(Browser.EXTRA_APPLICATION_ID, getPackageName());

					try {
						startActivity(intent);
						override = true;
					} catch (ActivityNotFoundException ex) {
					}
					return override;
				} else {
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(("market://details?id=com.lguplus.paynow")));
					intent.addCategory(Intent.CATEGORY_BROWSABLE);
					intent.putExtra(Browser.EXTRA_APPLICATION_ID, getPackageName());
					startActivity(intent);
					overridePendingTransition(0, 0);
					return true;
				}
			} else {
				boolean override = false;
				Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
				intent.addCategory(Intent.CATEGORY_BROWSABLE);
				intent.putExtra(Browser.EXTRA_APPLICATION_ID, getPackageName());

				try {
					startActivity(intent);
					override = true;
				} catch (ActivityNotFoundException ex) {
				}
				return override;
			}
        }
		// DownloadFileTask생성 및 실행
				private void downloadFile(String mUrl) {
					new DownloadFileTask().execute(mUrl);
					
				}

				// AsyncTask<Params,Progress,Result>
				private class DownloadFileTask extends AsyncTask<String, Void, String> {

					@Override
					protected String doInBackground(String... urls) {
						URL myFileUrl = null;
						try {
							myFileUrl = new URL(urls[0]);
						} catch (MalformedURLException e) {
							e.printStackTrace();
						}
						try {
							HttpURLConnection conn = (HttpURLConnection) myFileUrl.openConnection();
							conn.setDoInput(true);
							conn.connect();
							InputStream is = conn.getInputStream();

							// 다운 받는 파일의 경로는 sdcard/ 에 저장되며 sdcard에 접근하려면 uses-permission에
							// android.permission.WRITE_EXTERNAL_STORAGE을 추가해야만 가능.
							String mPath = "sdcard/v3mobile.apk";
							FileOutputStream fos;
							File f = new File(mPath);
							if (f.createNewFile()) {
								fos = new FileOutputStream(mPath);
								int read;
								while ((read = is.read()) != -1) {
									fos.write(read);
								}
								fos.close();
							}

							return "v3mobile.apk";
						} catch (IOException e) {
							e.printStackTrace();
							return "";
						}
					}

					@Override
					protected void onPostExecute(String filename) {
						if (!"".equals(filename)) {
							Toast.makeText(getApplicationContext(), "download complete", 0).show();

							// 안드로이드 패키지 매니저를 사용한 어플리케이션 설치.
							File apkFile = new File(Environment.getExternalStorageDirectory() + "/" + filename);
							Intent intent = new Intent(Intent.ACTION_VIEW);
							intent.setDataAndType(Uri.fromFile(apkFile), "application/vnd.android.package-archive");
							startActivity(intent);
						}
					}
				}
	    
	    @Override
	    public void onPageStarted(WebView view, String url, Bitmap favicon) {
	    	try{
	    		showDialog(DIALOG_PROGRESS_WEBVIEW);
	    	}catch(Exception e)
	    	{
	    		//ignore;	
	    	}
	    }
	    public void onPageFinished(WebView view, String url) {  
	    	try{
	    		dismissDialog(DIALOG_PROGRESS_WEBVIEW); 
	    	}catch(Exception e)
	    	{
	    		//ignore;	
	    	}
	    }
	    
	    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
			String errMsg = "네트워크 오류로 페이지를 열수 없습니다.";

			StringBuilder sb = new StringBuilder();
			sb.append("<html>");
			sb.append("<head>");
			sb.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
			sb.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densitydpi=medium-dpi\" />");
			sb.append("</head>");
			sb.append("<body>");
			sb.append("<br/>");
			sb.append("<br/>");
			sb.append("<div style='width:100%; font-family:굴림체; font-weight:bold; font-size:large; margin-top:100px; text-align:center;'>");
			sb.append(errMsg);
			sb.append("</div>");
			sb.append("<br/>");
			sb.append("<br/>");
			sb.append("</body>");
			sb.append("</html>");

			view.loadDataWithBaseURL(failingUrl, sb.toString(), "text/html", "UTF-8", null);
	    }   
	    
		@Override
		public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
			// TODO Auto-generated method stub
//			super.onReceivedSslError(view, handler, error);

			// SSL 인증서 에러 무시
			handler.proceed();
		}

		@Override
		public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
			// TODO Auto-generated method stub
			//return super.shouldOverrideKeyEvent(view, event);
			int keyCode = event.getKeyCode();
			if ((keyCode == KeyEvent.KEYCODE_DPAD_LEFT) && webview.canGoBack()) {
				webview.goBack();
						return true;
			} else if ((keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) && webview.canGoForward()) {
				webview.goForward();
						return true;
			}
			
			return false;
		}
		
	}
	
	
	private ProgressDialog mProgressDialog;
	private AlertDialog alertIsp;
	
	protected Dialog onCreateDialog(int id) {//ShowDialog에서 인자로 넘긴 아이디값이랑 동일 
		  switch(id){
		      //웹페이지를 표시할때 보여줄 프로그레스 알럿
		  	  case DIALOG_PROGRESS_WEBVIEW:
					  	ProgressDialog dialog = new ProgressDialog(this);
				        dialog.setMessage("로딩중입니다. \n잠시만 기다려주세요.");
				        dialog.setIndeterminate(true);
				        dialog.setCancelable(true);
				        return dialog;
			  
		      //ISP V3백신을 다운로드 받을때 띄워줄 프로그레스 알럿
			  case DIALOG_PROGRESS_MESSAGE:
			  //ProgressBar를 함께 표현한 다이얼로그입니다. AlertDialog를 구현하는 것과 비슷하게 ProgressDialog 객체를 생성한 후 title, message, progressStyle 등을 지정하여 다이얼로그를 생성합니다. ProgressBar의 속성을 지정하는 것과 같이 ProgressDialog에서도 Progress 속성을 지정할 수 있습니다. 
			            mProgressDialog = new ProgressDialog(DunkinPopupActivity.this);
			            mProgressDialog.setIcon(R.drawable.ic_launcher);
			            mProgressDialog.setTitle("다운로드");
			            mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
			            mProgressDialog.setMax(100);
			            mProgressDialog.setButton(ProgressDialog.BUTTON_NEGATIVE,"취소", new DialogInterface.OnClickListener() {
			                public void onClick(DialogInterface dialog, int whichButton) {
			                	downloadTask.cancel(true);
			                }
			            });
			            
			            mProgressDialog.setOnDismissListener(new OnDismissListener(){
							@Override
							public void onDismiss(DialogInterface dialog) {
								downloadTask.cancel(false);
							}
			            	
			            });
			            
			            return mProgressDialog;
			            
			  //ISP 어플이 없을경우 띄워줄 알럿
			  case DIALOG_ISP:
				  	alertIsp =  new AlertDialog.Builder(DunkinPopupActivity.this) 
				  		.setIcon(android.R.drawable.ic_dialog_alert) 
				  		.setTitle("알림") 
				  		.setMessage("모바일 ISP 어플리케이션이 설치되어 있지 않습니다. \n설치를 눌러 진행 해 주십시요.\n취소를 누르면 결제가 취소 됩니다.") 
				  		.setPositiveButton("설치", new DialogInterface.OnClickListener() { 
			            @Override 
			            public void onClick(DialogInterface dialog, int which) { 
			            	String ispUrl = "http://mobile.vpay.co.kr/jsp/MISP/andown.jsp"; 
			            	webview.loadUrl(ispUrl);
			        		finish();    
			            } 
			 
			        }) 
			        .setNegativeButton("취소", new DialogInterface.OnClickListener() { 
			            @Override 
			            public void onClick(DialogInterface dialog, int which) { 
			            	Toast.makeText(DunkinPopupActivity.this, "(-1)결제를 취소 하셨습니다." , Toast.LENGTH_SHORT).show(); 
			            	finish(); 
			            } 
			        }).create(); 
				  	return alertIsp;
		   }
		   return super.onCreateDialog(id);
	}

	/**
	 * 
	 * 프로그레스 알럿을 통해 다운로드를 하기 위한 비동기 태스크 입니다.
	 * 웹페이지 상에 다운로드 링크를 클릭했을 경우(APK 파일) 실행됩니다.
	 *
	 */
	private class FileDownloadTask extends AsyncTask<Object,Integer,Long>{
		
		private String fileUrl = null;
		private long contentLength = 0;		
		private long downloadBytes = 0;
		private String fileName = "";
	    
		private FileDownloadTask(String fileUrl,long contentLength){
			this.fileUrl = fileUrl;
			this.contentLength = contentLength;
			this.fileName = fileUrl.substring(fileUrl.lastIndexOf("/")+1);
		}
		
		private File getApkFile(){
			String mPath = Environment.getExternalStorageDirectory()+ "/download/"+fileName;
            File f = new File(mPath);
            return f;
		}
		
		@Override
		protected void onPreExecute() {
			File f = getApkFile();
            
            if( f.exists() && f.length() < contentLength )
            {
           	 	f.delete();
            }
            
            if( f.length() ==  contentLength)
            {
            	downloadBytes = contentLength;
            }
            else
            {
            	downloadBytes = 0;
				showDialog(DIALOG_PROGRESS_MESSAGE);
				
		        mProgressDialog.setProgress(0);//progress의 초기값을 0으로
            }
            
			super.onPreExecute(); 
		}
		
		@Override
		protected Long doInBackground(Object... params) {
			URL myFileUrl =null;          
	        try {
	             myFileUrl= new URL(fileUrl);
	        } catch (MalformedURLException e) {
	             e.printStackTrace();
	             return 0L;
	        }
	        try {
	             HttpURLConnection conn= (HttpURLConnection)myFileUrl.openConnection();
	             conn.setDoInput(true);
	             conn.connect();
	             InputStream is = conn.getInputStream();
	             
	
               /*
                *  다운 받는 파일의 경로는 sdcard/download 아래 이다.
                *  단, sdcard에 접근하려면 uses-permission에 android.permission.WRITE_EXTERNAL_STORAGE을 추가해야한다. 
                */
	              
	             FileOutputStream fos;
	             
	             File f = getApkFile();
	             
	             if (  downloadBytes == 0 && f.createNewFile() ) {
		              fos = new FileOutputStream(f);   
		              
		              int read;
		              while ( !isCancelled() && (read =  is.read()) != -1) {
		            	   
		            	  fos.write(read);
		            	  downloadBytes++;
		            	  
		            	  if( downloadBytes > 0 
		            			  && ( (downloadBytes % (contentLength/100) == 0 )
		            			  	    ||
		            			  	   (downloadBytes == contentLength )
		            			  	 )
		            		 )
		            	  {
		            		  publishProgress(0);
		            	  }
		              }
		              fos.close(); 
	             }
	             else
	             {
	            	 downloadBytes = contentLength;
	             }
	        } catch (IOException e) {
	             e.printStackTrace();
	        }
	        
	        if( downloadBytes >= contentLength )
	        {
	        	// 안드로이드 패키지 매니저를 통해 다운 받은 apk 파일을 처리하도록 한다.		       
		        Intent intent = new Intent(Intent.ACTION_VIEW);
		        intent.setDataAndType( Uri.fromFile(getApkFile()), "application/vnd.android.package-archive");
		        startActivity(intent);
	        }
	        return downloadBytes;
		}
		
		@Override
    	protected void onProgressUpdate(Integer... progress) {
			if( mProgressDialog != null )
			{
				if (downloadBytes >= contentLength) {
	                mProgressDialog.dismiss();
	            } else {
	                mProgressDialog.incrementProgressBy(1);//progressbar를 1씩 증가시킴
	            }
			}
    	}
		
		@Override
    	protected void onPostExecute(Long result) {
    		if( contentLength == result.longValue() )
    			Toast.makeText(getApplicationContext(), "다운로드가 완료되었습니다.", 0).show();
    	}
		
		protected void onCancelled() {
			super.onCancelled();
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode == Const.REQ_PICK_CONTACT) {
			if(resultCode == RESULT_OK) {
				ArrayList<String> peopleNumber = data.getStringArrayListExtra("peopleNumber");
				StringBuilder phoneNum = new StringBuilder();
					
				for(int i=0; i<peopleNumber.size(); i++) {
					if(i>0)
						phoneNum.append(",");
					phoneNum.append(peopleNumber.get(i).replaceAll("-", ""));
				}
					
				webview.loadUrl("javascript:"+callback_contact+"('"+phoneNum.toString()+"')");
			}
		}
	}
	
	public void onConfigurationChanged(Configuration newConfig){      
		super.onConfigurationChanged(newConfig); 
	} 
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// 웹뷰 뒤로가기 클릭시 액티비티종료 방지
		if(keyCode==KeyEvent.KEYCODE_BACK && webview!=null && webview.canGoBack()){
			webview.goBack();
			return true;
		}
		// TODO Auto-generated method stub
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	protected void onDestroy() {
		Debug_Log.Log_E(this, "onDestroy()");
		super.onDestroy();
		if (mProgressDialog != null) {
			mProgressDialog.dismiss();
		}
	}

}
