package com.hpapp.popup;

import org.apache.http.util.EncodingUtils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;

import com.hpapp.R;
import com.hpapp.res.Const;

public class PopupSns extends Activity {

	private WebView webview;
	private ProgressDialog mProgressDialog;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.argb(180, 0, 0, 0)));
		setContentView(R.layout.popup_sns);
	
		Intent intent = getIntent();
		String url = intent.getStringExtra("url");
		String param = intent.getStringExtra("param");
		
		ImageButton btnClose = (ImageButton) findViewById(R.id.popup_btn_close);
		btnClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		webview = (WebView) findViewById(R.id.webview_sns);
		webview.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setSupportMultipleWindows(true);
		webview.getSettings().setDomStorageEnabled(true);
//		webview.getSettings().setBuiltInZoomControls(true);
		webview.addJavascriptInterface(new JavaScriptExtention(), "android");
		webview.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "onPageStarted : " + url.toString());
				}
				showProgress("Loding...");
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "onPageFinished : " + url.toString());
				}
				closeProgress();
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				// TODO Auto-generated method stub
				view.stopLoading();
				if (url.indexOf(Const.HOST_URL_SPC) > -1
						|| url.indexOf("facebook.com") > -1
						|| url.indexOf("twitter.com") > -1) {
					view.loadUrl(url);
				} else {
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
					startActivity(intent);
					return true;
				}
				return false;
			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				// TODO Auto-generated method stub
				String errMsg = "네트워크 오류로 페이지를 열수 없습니다.";

				StringBuilder sb = new StringBuilder();
				sb.append("<html>");
				sb.append("<head>");
				sb.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
				sb.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densitydpi=medium-dpi\" />");
				sb.append("</head>");
				sb.append("<body>");
				sb.append("<br/>");
				sb.append("<br/>");
				sb.append("<div style='width:100%; font-family:굴림체; font-weight:bold; font-size:large; margin-top:100px; text-align:center;'>");
				sb.append(errMsg);
				sb.append("</div>");
				sb.append("<br/>");
				sb.append("<br/>");
				sb.append("</body>");
				sb.append("</html>");

				view.loadDataWithBaseURL(failingUrl, sb.toString(), "text/html", "UTF-8", null);
			}

			public void showProgress(String contents) {
				if (mProgressDialog != null)
					closeProgress();
				mProgressDialog = ProgressDialog.show(PopupSns.this, "", contents, true, true);
				mProgressDialog.setOwnerActivity(PopupSns.this);
			}

			public void closeProgress() {
				if (mProgressDialog != null && mProgressDialog.isShowing()) {
					mProgressDialog.dismiss();
				}
			}

		});

		webview.setWebChromeClient(new WebChromeClient(){
			@Override
			public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
				// TODO Auto-generated method stub
				return super.onCreateWindow(view, isDialog, isUserGesture, resultMsg);
			}

			@Override
			public boolean onJsAlert(WebView view, String url, final String message, final JsResult result) {
				// TODO Auto-generated method stub
				Builder dialog = new AlertDialog.Builder(PopupSns.this);
				dialog.setTitle("알림");
				dialog.setMessage(message);
				dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.confirm();
					}
				});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();
				return true;
			}

			@Override
			public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
				// TODO Auto-generated method stub
				Builder dialog = new AlertDialog.Builder(PopupSns.this);
				dialog.setTitle("알림");
				dialog.setMessage(message);
				dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.confirm();
					}
				});
				dialog.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.cancel();
					}
				});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();

				return true;
			}
		});

		if(param==null || param=="")
			webview.loadUrl(url);
		else
			webview.postUrl(url, EncodingUtils.getBytes(param, "utf-8"));
	}
	
	
	// 웹뷰에서 스크립트로 디바이스 접근 
	final class JavaScriptExtention{
		JavaScriptExtention(){}

		@JavascriptInterface
		public void close(){
			finish();
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// 웹뷰 뒤로가기 클릭시 액티비티종료 방지
		if(keyCode==KeyEvent.KEYCODE_BACK && webview!=null && webview.canGoBack()){
			webview.goBack();
			return true;
		}
		// TODO Auto-generated method stub
		return super.onKeyDown(keyCode, event);
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		if (mProgressDialog != null && mProgressDialog.isShowing()) {
			mProgressDialog.dismiss();
		}
	}
}
