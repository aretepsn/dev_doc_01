package com.hpapp.popup;

import java.io.BufferedInputStream;
import java.net.URL;
import java.net.URLConnection;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.hpapp.R;
import com.hpapp.adapter.MenuAdapter;
import com.hpapp.res.Const;
import com.hpapp.util.SharedPref;

public class EventPopupActivity extends Activity{

	private SharedPref pref;
	private ImageView eventBody;
	private String pathUrl, eventSeq, gubun;
	
	private OnClickListener clickListener=new OnClickListener(){
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			
			CheckBox neverView = (CheckBox) findViewById(R.id.popup_event_chk);
			if(neverView.isChecked()){
				// 하루동안 보지 않기
				pref.putSharedPreference(Const.SP_BANNER_KEY, eventSeq);
				pref.putSharedPreference(Const.SP_BANNER_EXPIRE, System.currentTimeMillis());
			}

			switch(v.getId())
			{
			case R.id.popup_event_btn_close:
				// 종료
				finish();
				break;
			case R.id.popup_event_btn_view:
				// 자세히
				int menuId = 0;
				
				if("MYMENU".equals(gubun)){
					menuId=Const.MENU_ID_POINT;
				}else if("EVENT".equals(gubun)){
					menuId=Const.MENU_ID_EVENT;
				}else if("GIFT".equals(gubun)){
					menuId=Const.MENU_ID_GIFT;
				}else if("CLUB".equals(gubun)){
					menuId=Const.MENU_ID_CLUB;
				}else if("COUPON".equals(gubun)){
					menuId=Const.MENU_ID_COUPON;
				}else if("SETTING".equals(gubun)){
					menuId=Const.MENU_ID_SETTING;
				}
				
				MenuAdapter.performClick(menuId, pathUrl);
				finish();
				break;
			}
		}
	};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
//		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND, WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.argb(180, 0, 0, 0)));
		setContentView(R.layout.popup_event);
		
        pref = new SharedPref(EventPopupActivity.this, Const.SP_KEY);

		Intent intent = getIntent();
		String imgUrl = intent.getStringExtra("imgUrl");
		gubun = intent.getStringExtra("gubun");
		pathUrl = intent.getStringExtra("pathUrl");
		eventSeq = intent.getStringExtra("eventSeq");
		
		ImageView imgTitle = (ImageView) findViewById(R.id.popup_event_title);
		
		if("N".equals(gubun)){
			imgTitle.setImageResource(R.drawable.main_pop_notice);
		}
		
		ImageButton btnClose = (ImageButton) findViewById(R.id.popup_event_btn_close);
		btnClose.setOnClickListener(clickListener);
		ImageButton btnDetail = (ImageButton) findViewById(R.id.popup_event_btn_view);
		btnDetail.setOnClickListener(clickListener);
		
		eventBody = (ImageView) findViewById(R.id.popup_event_img);
		
		new AsyncDownImg(eventBody).execute(imgUrl);
	}

	public class AsyncDownImg extends AsyncTask<String,Void,Bitmap>{
		private ImageView view;
		
		AsyncDownImg(ImageView view){
			this.view = view;
		}

		@Override
		protected Bitmap doInBackground(String... params) {
			// TODO Auto-generated method stub
			Bitmap bitmap = null;
			try {
				String uri = params[0];

				URL url = new URL(uri);
				URLConnection conn = url.openConnection();
				conn.connect();
				BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
				bitmap = BitmapFactory.decodeStream(bis);
				bis.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return bitmap;
		}

		@Override
		protected void onPostExecute(Bitmap bitmap) {
			// TODO Auto-generated method stub
			super.onPostExecute(bitmap);
			if(bitmap!=null){
//				Drawable draw = new BitmapDrawable(getResources(), bitmap);
//				view.setBackgroundDrawable(draw);

				view.setImageBitmap(bitmap);
			}
		}
	}

}
