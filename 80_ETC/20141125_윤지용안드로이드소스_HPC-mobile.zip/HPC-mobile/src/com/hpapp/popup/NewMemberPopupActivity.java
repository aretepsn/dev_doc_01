package com.hpapp.popup;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.hpapp.R;
import com.hpapp.adapter.HappyPointSync;
import com.hpapp.bean.UserBean;
import com.hpapp.res.Const;
import com.hpapp.util.SharedPref;
import com.hpapp.util.StringUtils;

public class NewMemberPopupActivity extends Activity{

	private SharedPref pref;
	private EditText recomNumber;
	private String hpcNo, userId, cardNo, userName, ci, hpc;
	
	private OnClickListener clickListener=new OnClickListener(){
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub

			switch(v.getId())
			{
			case R.id.popup_recom_btn_close:
				// 종료
				pref.putSharedPreference(Const.SP_RECOMMEND, "N");
				finish();
				break;
			case R.id.popup_btn_ok :
				
				try {
					
					//추천인 확인
					String recomCode = recomNumber.getText().toString();
					String[] params = new String[7];
					
					if(recomCode.length() == 0) {
						AlertDialog.Builder builder = new AlertDialog.Builder(NewMemberPopupActivity.this);
				        builder.setMessage("추천인 ID를 입력해 주세요.");
				        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
				            @Override
				            public void onClick(DialogInterface dialog, int which) {
				            	recomNumber.setFocusable(true);
				            }
				        });
		 
				        builder.show();
					}
					
					if(recomCode.length() > 0) {
						if(recomCode.length() != 6) {
							AlertDialog.Builder builder = new AlertDialog.Builder(NewMemberPopupActivity.this);
					        builder.setMessage("추천인 ID 확인 후 재 입력해 주세요.");
					        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
					            @Override
					            public void onClick(DialogInterface dialog, int which) {
					            	recomNumber.setFocusable(true);
					            }
					        });
			 
					        builder.show();
					        
						} else {
							
							if(!StringUtils.isEmpty(ci)) {
								params[0] = "hpcNo=" + hpc;
								params[1] = "userId=" + userId;
								params[2] = "cardNo=" + cardNo;
								params[3] = "recommendId=" + recomCode;
								params[4] = "deviceType=A";
								params[5] = "userNm=" + URLEncoder.encode(userName,"utf-8");
								params[6] = "userCi=" + URLEncoder.encode(ci,"utf-8");
							} else if(!StringUtils.isEmpty(hpcNo)){
								params[0] = "hpcNo=" + hpcNo;
								params[1] = "userId=" + userId;
								params[2] = "cardNo=" + cardNo;
								params[3] = "recommendId=" + recomCode;
								params[4] = "deviceType=A";
								params[5] = "userNm=";
								params[6] = "userCi=";
							} else {
								Log.d("==recommend", "hpcNo = " + hpcNo);
								Log.d("==recommend", "null!!!!!");
							}
							new AsyncRecommend().execute(params);
							
							pref.putSharedPreference(Const.SP_RECOMMEND, "N");
						}
					}
					
				} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				break;
		}
	}};
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.argb(180, 0, 0, 0)));
		setContentView(R.layout.popup_recommend);
		
		pref = new SharedPref(NewMemberPopupActivity.this, Const.SP_KEY);

		UserBean user = HappyPointSync.user;
		
		userName = pref.getSharedPreference(Const.SP_NAME);
		ci = pref.getSharedPreference(Const.SP_CI);
		hpcNo = pref.getSharedPreference(Const.SP_HPCNO);
		cardNo = pref.getSharedPreference(Const.SP_CARDNO);
		userId = pref.getSharedPreference(Const.SP_ID);
		
		if(user!=null){
			userName = user.getUserName();
		}
        
		ImageButton btnClose = (ImageButton) findViewById(R.id.popup_recom_btn_close);
		btnClose.setOnClickListener(clickListener);
		ImageButton btnConfirm = (ImageButton) findViewById(R.id.popup_btn_ok);
		btnConfirm.setOnClickListener(clickListener);
		
		recomNumber = (EditText) findViewById(R.id.popup_edit_recomnumber);
		TextView recomTilte = (TextView) findViewById(R.id.popup_recom_title);
		TextView recomContent = (TextView) findViewById(R.id.popup_content);
		
		String recommendTitle = pref.getSharedPreference(Const.SP_RECOMMEND_TITLE);
		String recommendContent = pref.getSharedPreference(Const.SP_RECOMMEND_CONTENT);
		if(!StringUtils.isEmpty(recommendTitle)){
			recomTilte.setText(recommendTitle);
		}
		if(!StringUtils.isEmpty(recommendContent)){
			recomContent.setText(recommendContent);
		}
		
		recomNumber.setFilters(new InputFilter[] {filterAlphaNum});
		recomNumber.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				// TODO Auto-generated method stub
				if(recomNumber.getText().toString().length() == 6) {
					hideKeyboard(recomNumber);
				}
			}
		});
			
	}
	
	public InputFilter filterAlphaNum = new InputFilter() {
		
		  public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
		   Pattern ps = Pattern.compile("^[a-zA-Z0-9]+$");
		   if (!ps.matcher(source).matches()) {
			   return "";
		   }
		   	return null;
		  }
	};

	private void hideKeyboard(EditText editText)
	{
	    InputMethodManager imm= (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
	    imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
	}
	
	private class AsyncRecommend extends AsyncTask<String, Void, String>{

		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			
			StringBuffer resp = new StringBuffer();
			
			try{
				URI uri = new URI(Const.LINK_RECOMMEND);
				URL url = uri.toURL();
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				
				con.setDoOutput(true);
				con.setDoInput(true);
				con.setUseCaches(false);
				con.setConnectTimeout(5000);
				
				StringBuffer sb = new StringBuffer();
				if(params!=null && params.length>0){
					for(int i=0;i<params.length;i++){
						if(i>0)
							sb.append("&");
						sb.append(params[i]);
					}
				}
				con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
//				con.setRequestProperty("Content-length", String.valueOf(sb.toString().length()));
				con.setRequestMethod("POST");
				System.out.println(sb.toString());
				OutputStreamWriter output = new OutputStreamWriter(con.getOutputStream());
				output.write(sb.toString());
				output.flush();
				
				int resCode = 0;
				resCode = con.getResponseCode();
				
				if(resCode < 400){
					String line = "";
					
					BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
					while((line=br.readLine())!=null){
						resp.append(line);
					}
					br.close();
				}else{
					Log.d(Const.LOG_TAG, "데이터를 가져오는데 실패 하였습니다. 오류코드 : "+resCode);
					return "0";
				}
				
//				return resp.toString().trim();
		}catch(Exception e){
			e.printStackTrace();
			return "0";
		}
			return resp.toString().trim();
		}
	
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
//			super.onPostExecute(result);
			
//			System.out.println(result);
			if(!StringUtils.isEmpty(result)){
				try {
					InputSource is = new InputSource(new StringReader(result));
					
					DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
					DocumentBuilder db = dbf.newDocumentBuilder();
					Document doc = db.parse(is);
					
					// root노드 구하기
					Element root = doc.getDocumentElement();
					String clerkYn = getNodeValue(root, "//recommend/clerkYn");
					String clerkMsg = getNodeValue(root, "//recommend/clerkMsg");
					String hpcYn = getNodeValue(root, "//recommend/hpcYn");
					String hpcMsg = getNodeValue(root, "//recommend/hpcMsg");
					String recommendInsert = getNodeValue(root, "//recommend/recommendInsert");
					String recommendInsertMsg = getNodeValue(root, "//recommend/recommendInsertMsg");
					
					if("N".equals(clerkYn)) {
						AlertDialog.Builder builder = new AlertDialog.Builder(NewMemberPopupActivity.this);
				        builder.setMessage(clerkMsg);
				        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
				            @Override
				            public void onClick(DialogInterface dialog, int which) {
				            	recomNumber.setFocusable(true);
				            }
				        });
		 
				        builder.show();
					} else if("N".equals(hpcYn)) {
						AlertDialog.Builder builder = new AlertDialog.Builder(NewMemberPopupActivity.this);
				        builder.setMessage(hpcMsg);
				        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
				            @Override
				            public void onClick(DialogInterface dialog, int which) {
				            	recomNumber.setFocusable(true);
				            }
				        });
		 
				        builder.show();
					} else if("Y".equals(recommendInsert)) {
						AlertDialog.Builder builder = new AlertDialog.Builder(NewMemberPopupActivity.this);
				        builder.setMessage(recommendInsertMsg);
				        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
				            @Override
				            public void onClick(DialogInterface dialog, int which) {
				            	finish();
				            }
				        });
		 
				        builder.show();
				        
					}
						
					
			
				}	catch (ParserConfigurationException e) {
						// TODO Auto-generated catch block
						if(Const.LOG_FLAG){
							Log.d(Const.LOG_TAG, "======= AsyncRecommend ParserConfigurationException ======");
						}
						e.printStackTrace();
					} catch (SAXException e) {
						// TODO Auto-generated catch block
						if(Const.LOG_FLAG){
							Log.d(Const.LOG_TAG, "======= AsyncRecommend SAXException =======");
						}
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						if(Const.LOG_FLAG){
							Log.d(Const.LOG_TAG, "======= AsyncRecommend IOException =======");
						}
						e.printStackTrace();
					} catch (NullPointerException e) {
						if(Const.LOG_FLAG){
							Log.d(Const.LOG_TAG, "======= AsyncRecommend NullPointerException =======");
						}
						e.printStackTrace();
					}
			}
		}
	}
	
	private String getNodeValue(Element rootElem, String xpath){
		String returnVal = "";
		
		try {
			NodeList list = XPathAPI.selectNodeList(rootElem.getFirstChild(), xpath);
			
			if(list!=null){
				returnVal = list.item(0).getTextContent();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return "";
		}
		
		return returnVal;
	}
}