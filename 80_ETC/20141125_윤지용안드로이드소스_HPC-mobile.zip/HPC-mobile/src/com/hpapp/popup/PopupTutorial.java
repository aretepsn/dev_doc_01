package com.hpapp.popup;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageButton;

import com.hpapp.R;
import com.hpapp.activity.HPCActivity;
import com.hpapp.res.Const;
import com.hpapp.util.SharedPref;

@SuppressLint("SetJavaScriptEnabled")
public class PopupTutorial extends Activity{

	private WebView webview;
	private ProgressDialog mProgressDialog;
//	private LinearLayout layoutBottom;
	private CheckBox chkShow;
	private boolean callMain, neverShow;
	private ImageButton btnClose;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
//		getWindow().setFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND, WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
//		getWindow().setBackgroundDrawable(new ColorDrawable(Color.argb(180, 0, 0, 0)));
		setContentView(R.layout.popup_tutorial);
		
//		layoutBottom = (LinearLayout) findViewById(R.id.layout_bottom);
		chkShow = (CheckBox) findViewById(R.id.check_show);
		btnClose = (ImageButton) findViewById(R.id.btn_close);
		
		callMain = getIntent().getBooleanExtra("callMain", false);
		
		if(!callMain){
			chkShow.setVisibility(View.GONE);
		}else{
			chkShow.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					// TODO Auto-generated method stub
					neverShow=isChecked;
				}
			});
		}
		btnClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				closeTutoral();
			}
		});
		
		webview = (WebView) findViewById(R.id.popup_tutorial);
		webview.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_OVERLAY);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setSupportMultipleWindows(true);
//		webview.getSettings().setBuiltInZoomControls(true);
		webview.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "onPageStarted : " + url.toString());
				}
				showProgress("로딩중...");
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "onPageFinished : " + url.toString());
				}
				closeProgress();
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				// TODO Auto-generated method stub
				view.stopLoading();
				if (url.indexOf(Const.HOST_URL_SPC) > -1
						|| url.indexOf("facebook.com") > -1
						|| url.indexOf("twitter.com") > -1) {
					view.loadUrl(url);
				} else {
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
					startActivity(intent);
					return true;
				}
				return false;
			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				// TODO Auto-generated method stub
				String errMsg = "네트워크 오류로 페이지를 열수 없습니다.";

				StringBuilder sb = new StringBuilder();
				sb.append("<html>");
				sb.append("<head>");
				sb.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
				sb.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densitydpi=medium-dpi\" />");
				sb.append("</head>");
				sb.append("<body>");
				sb.append("<br/>");
				sb.append("<br/>");
				sb.append("<div style='width:100%; font-family:굴림체; font-weight:bold; font-size:large; margin-top:100px; text-align:center;'>");
				sb.append(errMsg);
				sb.append("</div>");
				sb.append("<br/>");
				sb.append("<br/>");
				sb.append("</body>");
				sb.append("</html>");

				view.loadDataWithBaseURL(failingUrl, sb.toString(), "text/html", "UTF-8", null);
			}

			public void showProgress(String contents) {
				if (mProgressDialog != null)
					closeProgress();
				mProgressDialog = ProgressDialog.show(PopupTutorial.this, "", contents, true, true);
				mProgressDialog.setOwnerActivity(PopupTutorial.this);
			}

			public void closeProgress() {
				if (mProgressDialog != null && mProgressDialog.isShowing()) {
					mProgressDialog.dismiss();
				}
			}

		});
		webview.setWebChromeClient(new WebChromeClient(){
			@Override
			public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
				// TODO Auto-generated method stub
				return super.onCreateWindow(view, isDialog, isUserGesture, resultMsg);
			}

			@Override
			public boolean onJsAlert(WebView view, String url, final String message, final JsResult result) {
				// TODO Auto-generated method stub
				Builder dialog = new AlertDialog.Builder(PopupTutorial.this);
				dialog.setTitle("알림");
				dialog.setMessage(message);
				dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.confirm();
					}
				});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();
				return true;
			}

			@Override
			public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
				// TODO Auto-generated method stub
				Builder dialog = new AlertDialog.Builder(PopupTutorial.this);
				dialog.setTitle("알림");
				dialog.setMessage(message);
				dialog.setPositiveButton("예", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.confirm();
					}
				});
				dialog.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						result.cancel();
					}
				});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();

				return true;
			}
		});
		
		webview.loadUrl(Const.LINK_TUTORIAL);
	}
	
    /**
     * 알림창 생성
     * @param message
     */
	private void closeTutoral(){
		if(neverShow){
			SharedPref pref = new SharedPref(PopupTutorial.this, Const.SP_KEY);
			pref.putSharedPreference(Const.SP_NEVER_SHOW_TUTORIAL, true);
			
			AlertDialog.Builder alert = new AlertDialog.Builder(this);
			alert.setPositiveButton("확인", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					goMain();
				}
			});
			alert.setMessage("앱가이드는 하단메뉴의 안내>서비스안내 에서 다시보실 수 있습니다.");
			alert.show();
		}else{
			goMain();
		}

	}

	private void goMain(){
		if(callMain){
			Intent intent = new Intent(PopupTutorial.this, HPCActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.putExtra("kakaolink", getIntent().getStringExtra("kakaolink"));
			intent.putExtra("params", getIntent().getStringExtra("params"));
			intent.putExtra("seq", getIntent().getStringExtra("seq"));
			startActivity(intent);
			overridePendingTransition(R.anim.alpha_show, R.anim.alpha_hide);
		}
		finish();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// 웹뷰 뒤로가기 클릭시 액티비티종료 방지
		if(keyCode==KeyEvent.KEYCODE_BACK){
			if(callMain)
				goMain();
			else
				finish();
		}
		// TODO Auto-generated method stub
		return super.onKeyDown(keyCode, event);
	}


}
