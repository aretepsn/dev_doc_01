package com.hpapp.activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.TextView;

import com.hpapp.R;
import com.hpapp.res.Const;
import com.hpapp.util.SharedPref;

public class NoticeActivity extends Activity{

	private TextView txtTitle, txtContent;
	private SharedPref pref;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_error);
        
        pref = new SharedPref(NoticeActivity.this, Const.SP_KEY);
        
        txtTitle = (TextView) findViewById(R.id.txt_error_title);
        txtContent = (TextView) findViewById(R.id.txt_error_content);
        
        String serviceTitle = getIntent().getStringExtra(Const.SP_SERVICE_TITLE);
        String serviceContent = getIntent().getStringExtra(Const.SP_SERVICE_CONTENT);
        
        
        txtTitle.setText(serviceTitle);
        txtContent.setText(serviceContent);
        
    }
   
    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if(KeyEvent.KEYCODE_BACK==keyCode){
			pref.putSharedPreference(Const.SP_MAINPOPUP, "N");
			android.os.Process.killProcess(android.os.Process.myPid());
		}
		return false;
	}
	
}
