package com.hpapp.activity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.daou.smartpush.ConstValue.ConstValue;
import com.hpapp.R;
import com.hpapp.adapter.HappyPointSync;
import com.hpapp.adapter.MenuAdapter;
import com.hpapp.bean.UserBean;
import com.hpapp.map.NMapViewer;
import com.hpapp.popup.DunkinPopupActivity;
import com.hpapp.popup.PopupActivity;
import com.hpapp.popup.PopupSns;
import com.hpapp.popup.PopupTutorial;
import com.hpapp.res.CMR;
import com.hpapp.res.Const;
import com.hpapp.util.CustomSchemeURL;
import com.hpapp.util.Debug_Log;
import com.hpapp.util.SEEDUtil;
import com.hpapp.util.SharedPref;
import com.hpapp.util.StringUtils;
import com.kakao.AppActionBuilder;
import com.kakao.AppActionInfoBuilder;
import com.kakao.KakaoLink;
import com.kakao.KakaoParameterException;
import com.kakao.KakaoTalkLinkMessageBuilder;

public class HPCWebActivity extends Activity {

	private View menu;

	private ImageView btnBack;
	private WebView wv;
	private TextView titleHeader;
	private ImageView btnMap;
	private ImageView prepaid;
	
	private ProgressDialog mProgressDialog;
	boolean webviewflag = false;
	
	protected static String callback_contact;
	private static Context con;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_web);
		con = HPCWebActivity.this;
		webviewflag = false;
//		Log.i("current", "webAct =" + Const.CURRENT_TAB);
		Debug_Log.Log_E(this, "HPCWebActivity.onCreate()");
		menu = LayoutInflater.from(this).inflate(R.layout.footer_menu, null);
		LinearLayout menuRoot = (LinearLayout) findViewById(R.id.menu_foot);
		menuRoot.addView(menu);
		MenuAdapter.setBottomMenu(this, menu);
		
		titleHeader = (TextView) findViewById(R.id.txt_title_top);

		btnBack = (ImageView) findViewById(R.id.top_btn_prev);
		btnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// 웹뷰 뒤로가기 클릭시 액티비티종료 방지
				if (wv != null && wv.canGoBack()) {
					wv.goBack();
				} else {
					onBackPressed();
				}
			}
		});
		btnMap = (ImageView) findViewById(R.id.top_btn_store);
		prepaid = (ImageView) findViewById(R.id.top_btn_prepaid);
		
		prepaid.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				UserBean user = HappyPointSync.user;
				SharedPref pref = new SharedPref(HPCWebActivity.this, Const.SP_KEY);
				String dunkinUrl = Const.HOST_URL_DUNKIN;
				if (user != null) {
					Const.CURRENT_TAB = R.id.top_btn_prepaid;;
					Debug_Log.Log_E(this, "HPCWebActivty.prepaid.OnClickListener() HOST_URL_DUNKIN");
					String	mberNo = user.getUserNo();
					String phoneNum = user.getPhoneNumber();
					String cardNo = pref.getSharedPreference(Const.SP_CARDNO);
					
					String param = "mbNo="+mberNo+"&cardnum="+cardNo+"&buyerMdn="+phoneNum;
					if(wv != null){
						if (StringUtils.isEmpty(param)){
							wv.loadUrl(dunkinUrl);
						}else{
							String sep = "?";
							if(dunkinUrl.indexOf("?")>-1){
								sep = "&";
							}
							Debug_Log.Log_E(this, "onCreate().urlStr+sep+param : " + dunkinUrl+sep+param);
							wv.loadUrl(dunkinUrl+sep+param);
						}
					}
				} else if (HappyPointSync.user == null) {
					Debug_Log.Log_E(this, "HPCWebActivty.prepaid.OnClickListener() -> Login");
					Intent intent = new Intent(HPCWebActivity.this, LoginActivity.class);
					startActivity(intent);
				}
				MenuAdapter.menuSelected();
			}
		});
		
		btnMap.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HPCWebActivity.this, NMapViewer.class);
				startActivity(intent);
			}
		});

		String urlStr = getIntent().getStringExtra("url");
		String param = getIntent().getStringExtra("param");
//		param = isdunkin(urlStr, param);
		wv = (WebView) findViewById(R.id.webview);
		wv.getSettings().setJavaScriptEnabled(true);
		wv.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
//		wv.getSettings().setUseWideViewPort(true);
//		wv.setInitialScale(1);
		
		wv.addJavascriptInterface(new JavaScriptExtention(), "android");
		wv.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "onPageStarted : " + url.toString());
				}
				if (!(url.indexOf(Const.HOST_URL_SPC) > -1)) {
					if (Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB && webviewflag) {
						Log.d(Const.LOG_TAG, "onPageStarted : GINGERBREAD");
						shouldOverrideUrlLoading(view, url);
						webviewflag = false;
					}
				}
				showProgress(CMR.string.process_job);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				if (Const.LOG_FLAG) {
					Log.d(Const.LOG_TAG, "onPageFinished : " + url.toString());
				}
				closeProgress();
				webviewflag = true;
			}

			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String loaddingurl) {
				// TODO Auto-generated method stub
				view.stopLoading();
				String url = loaddingurl;
				String HOST_URL = "";
				Debug_Log.Log_E(this, "shouldOverrideUrlLoading() : " + url);
				if (url.indexOf(Const.HOST_URL_SPC + "/front_v2/mymenu/") > -1 || url.indexOf(Const.HOST_HTTP_URL_SPC + "/front_v2/mymenu/") > -1) {
					if (is_url_param(url)) {
						url += "&";
					} else {
						url += "?";
					}
					HOST_URL = "MYMENU";
					url += addParam(HOST_URL);
					wv.clearHistory();
					wv.clearCache(true);
					wv.clearView();
					Debug_Log.Log_E(this, "shouldOverrideUrlLoading()./front_v2/mymenu/: " + url);
				} else if (url.indexOf(Const.HOST_URL_SPC + "/front_v2/event/") > -1 || url.indexOf(Const.HOST_HTTP_URL_SPC + "/front_v2/event/") > -1) {
					if (is_url_param(url)) {
						url += "&";
					} else {
						url += "?";
					}
					HOST_URL = "EVENT";
					url += addParam(HOST_URL);
					Debug_Log.Log_E(this, "shouldOverrideUrlLoading()./front_v2/event/: " + url);
				} else if (url.indexOf(Const.HOST_URL_DUNKIN) > -1) {
					if (is_url_param(url)) {
						url += "&";
					} else {
						url += "?";
					}
					HOST_URL = "DUNKIN";
					url += addParam(HOST_URL);
					Debug_Log.Log_E(this, "shouldOverrideUrlLoading().Const.HOST_URL_DUNKIN event: " + url);
				}

				Debug_Log.Log_E(this, "shouldOverrideUrlLoading().AFTER_url : " + url);
//				if (url.indexOf(Const.HOST_URL_SPC) > -1
//						|| url.indexOf(Const.HOST_URL_HAPPYCON) >-1
//						|| url.indexOf("happypointcard.com") > -1) {
				if(url.indexOf("isOut=Y")>-1){
					/*String userId = "";
					String userPwd = "";
					
					UserBean user = HappyPointSync.user;
					if(user!=null){
						userId = user.getUserId();
						userPwd = user.getUserPwd();
					}
					try {
						if(url.indexOf("?")>-1)
								url += "&W_ID="+userId+"&W_PASSWD="+URLEncoder.encode(SEEDUtil.encrypt(userPwd),"utf-8");
						else
								url += "?W_ID="+userId+"&W_PASSWD="+URLEncoder.encode(SEEDUtil.encrypt(userPwd),"utf-8");
					} catch (UnsupportedEncodingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}*/
					
					if (is_url_param(loaddingurl)) {
						Debug_Log.Log_E(this, "loaddingurl : " + loaddingurl);
						String[] splitparam = null;
						splitparam = loaddingurl.split("\\?");
						if (splitparam.length > 1) {
							loaddingurl = splitparam[0];
							loaddingurl += "?" + paramfilter(splitparam[1]);
						}
					}
					Debug_Log.Log_E(this, "loaddingurl : " + loaddingurl);
					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(loaddingurl));
					startActivity(intent);
					return true;
				} else {
					view.loadUrl(url);
				}
//				} else {
//					Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
//					startActivity(intent);
//					return true;
//				}
				return false;
			}

			/**
			 * Date : 2014.10.17 작성자 : smile
			 * <dl>
			 * <b>외부 링크의 url 파라메터 값중에 개인정보 관련 파라메터를 필터링함.</b>
			 * </dl>
			 * 
			 * @param mUrlParam
			 * @return "W_ID", "W_PASSWD", "W_NAME", "mdn", "hpcNo", "verA", "cardnum" 값을 제외한 파라메터 값을 반환
			 */
			private String paramfilter(String mUrlParam) {
				if (mUrlParam == null || mUrlParam.length() == 0) {
					return "";
				}
				Debug_Log.Log_E(this, "mUrlParam : " + mUrlParam);
				StringBuffer sb = new StringBuffer();
				try{
				String[] paramtemp = mUrlParam.split("\\&");
				String[] key_value = null;
				Pattern filterPattern = Pattern.compile("W_ID|W_PASSWD|W_NAME|mdn|hpcNo|verA|cardnum", Pattern.CASE_INSENSITIVE);
				Matcher paramMacher = null;
				String[] filterArray = { "W_ID", "W_PASSWD", "W_NAME", "mdn", "hpcNo", "verA", "cardnum" };
				int paramLEN = paramtemp.length + 1;
				String[] filtered_param = new String[paramLEN];
				int pointer  = 0;
				for (int i = 0; i < paramtemp.length; i++) {
					paramMacher = filterPattern.matcher(paramtemp[i]);
					if (paramMacher.find()) {
						key_value = paramtemp[i].split("\\=");
						for (int index = 0; index < filterArray.length; index++) {
							if (key_value[0].equalsIgnoreCase(filterArray[index])) {
								paramtemp[i] = "";
								break;
							}
						}
					} else {
						filtered_param[pointer] = paramtemp[i];
						++pointer;
					}
				}
				for(int k=0; k<pointer - 1; k++){
					if(0 == k){
						sb.append(filtered_param[0]);
					}else{
						sb.append("&"+filtered_param[k]);
					}
				}
				}catch(Exception e){
					Debug_Log.Log_E(this,"paramfilter.Exception : " + e.getMessage());
					return mUrlParam;
				}
				return sb.toString();
			}

			@Override
			public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
				// TODO Auto-generated method stub
				String errMsg = "네트워크 오류로 페이지를 열수 없습니다.";
//				switch(errorCode)
//				{
//				case -1:
//					errMsg = "Generic error";
//					break;
//				case -2:
//					errMsg = "Server or proxy hostname lookup failed";
//					break;
//				case -3:
//					errMsg = "Unsupported authentication scheme (not basic or digest)";
//					break;
//				case -4:
//					errMsg = "User authentication failed on server";
//					break;
//				case -5:
//					errMsg = "User authentication failed on proxy";
//					break;
//				case -6:
//					errMsg = "Failed to connect to the server";
//					break;
//				case -7:
//					errMsg = "Failed to read or write to the server";
//					break;
//				case -8:
//					errMsg = "Connection timed out";
//					break;
//				case -9:
//					errMsg = "Too many redirects";
//					break;
//				case -10:
//					errMsg = "Unsupported URI scheme";
//					break;
//				case -11:
//					errMsg = "Failed to perform SSL handshake";
//					break;
//				case -12:
//					errMsg = "Malformed URL";
//					break;
//				case -13:
//					errMsg = "Generic file error";
//					break;
//				case -14:
//					errMsg = "File not found";
//					break;
//				case -15:
//					errMsg = "Too many requests during this load";
//					break;
//				default:
//					errMsg = "페이지를 열수 없습니다.";
//				}

				StringBuilder sb = new StringBuilder();
				sb.append("<html>");
				sb.append("<head>");
				sb.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
				sb.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no, target-densitydpi=medium-dpi\" />");
				sb.append("</head>");
				sb.append("<body>");
				sb.append("<br/>");
				sb.append("<br/>");
				sb.append("<div style='width:100%; font-family:굴림체; font-weight:bold; font-size:large; margin-top:100px; text-align:center;'>");
				sb.append(errMsg);
				sb.append("</div>");
				sb.append("<br/>");
				sb.append("<br/>");
				sb.append("</body>");
				sb.append("</html>");

				view.loadDataWithBaseURL(failingUrl, sb.toString(), "text/html", "UTF-8", null);
			}

			@Override
			public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
				// TODO Auto-generated method stub
//				super.onReceivedSslError(view, handler, error);

				// SSL 인증서 에러 무시
				handler.proceed();
			}
			
			public void showProgress(String contents) {
				if (mProgressDialog != null)
					closeProgress();
				Debug_Log.Log_E(HPCWebActivity.this, "showProgress()");
				try {
					mProgressDialog = ProgressDialog.show(con, "", contents, true, true);
					mProgressDialog.setOwnerActivity(HPCWebActivity.this);

				} catch (Exception e) {
					Debug_Log.Log_E(HPCWebActivity.this, "showProgress()Exception : " + e.getMessage());
				}
			}

			public void closeProgress() {
				try {
					if (mProgressDialog != null && mProgressDialog.isShowing()) {
						mProgressDialog.dismiss();
						Debug_Log.Log_E(HPCWebActivity.this, "closeProgress");
					}
				} catch (Exception e) {
					Debug_Log.Log_E(HPCWebActivity.this, "closeProgress()Exception : " + e.getMessage());
				}
			}

		});

		wv.setWebChromeClient(new WebChromeClient() {
			@Override
			public boolean onCreateWindow(WebView view, boolean isDialog,
					boolean isUserGesture, Message resultMsg) {
				// TODO Auto-generated method stub
				return super.onCreateWindow(view, isDialog, isUserGesture,
						resultMsg);
			}

			@Override
			public boolean onJsAlert(WebView view, String url,
					final String message, final JsResult result) {
				// TODO Auto-generated method stub
				Builder dialog = new AlertDialog.Builder(HPCWebActivity.this);
				dialog.setTitle("알림");
				dialog.setMessage(message);
				dialog.setPositiveButton("예",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								// TODO Auto-generated method stub
								result.confirm();
							}
						});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();
				if (wv != null && wv.canGoBack()) {
					wv.goBack();
				}
				return true;
			}

			@Override
			public boolean onJsConfirm(WebView view, String url,
					String message, final JsResult result) {
				// TODO Auto-generated method stub
				Builder dialog = new AlertDialog.Builder(HPCWebActivity.this);
				dialog.setTitle("알림");
				dialog.setMessage(message);
				dialog.setPositiveButton("예",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								// TODO Auto-generated method stub
								result.confirm();
							}
						});
				dialog.setNegativeButton("아니오",
						new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog,
									int which) {
								// TODO Auto-generated method stub
								result.cancel();
							}
						});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();
				if (wv != null && wv.canGoBack()) {
					wv.goBack();
				}
				return true;
			}
		});
		Debug_Log.Log_E(this, "onCreate().url : " + urlStr);
		Debug_Log.Log_E(this, "onCreate().param : " + param);
		
		if (StringUtils.isEmpty(param))
			wv.loadUrl(urlStr);
		else{
			String sep = "?";
			if(urlStr.indexOf("?")>-1)
				sep = "&";
			Debug_Log.Log_E(this, "onCreate().urlStr+sep+param : " + urlStr+sep+param);
			wv.loadUrl(urlStr+sep+param);
		}
//			wv.postUrl(urlStr, EncodingUtils.getBytes(param, "utf-8"));

	}
	
/*	private String isdunkin(String isUrl, String oriParam){
		if(isUrl.indexOf(Const.HOST_URL_DUNKIN) > -1){
			String param = oriParam;
			String seq = "";
			if (oriParam == null || oriParam == "") {
				seq += "&";
			} else {
				seq += "?";
			}
			String HOST_URL = "DUNKIN";
			param += seq + addParam(HOST_URL);
			return param;
		}
		return oriParam;
	}*/

	/**
	 * Date : 2014.10.06 작성자 : smile
	 * <dl>
	 * <b>url에 파라메타가 있는지 확인.</b>
	 * </dl>
	 * 
	 * @param pUrl
	 * @return 파라메터가 있으면 True, 아니면 false
	 */
	private boolean is_url_param(String pUrl) {
		boolean isparam = false;
		String[] splitparam = null;
		if (pUrl.indexOf("?") > -1) {
			splitparam = pUrl.split("\\?");
			if (splitparam.length > 1) {
				isparam = true;
			}
		} else {
			isparam = false;
		}
		return isparam;
	}

	/**
	 * Date : 2014.10.06 작성자 : smile
	 * <dl>
	 * <b>url에 파라메터를 추가한다</b>
	 * </dl>
	 * 
	 * @param getLINKParam
	 * @return <dl>
	 *         Menu Page : W_ID, W_PASSWD, W_NAME, mdn, hpcNo, verA, cardnum
	 *         </dl>
	 *         Event Page : W_ID, cardnum, verA, mberNo
	 */
	private String addParam(String getLINKParam) {
		String paramValues = "";
		String mberNo = "", userId = "", userPwd = "", userName = "", phoneNum = "", cardNo = "", verA = "";
		UserBean user = HappyPointSync.user;
		SharedPref pref = new SharedPref(HPCWebActivity.this, Const.SP_KEY);
		if (user != null) {
			mberNo = user.getUserNo();
			userId = user.getUserId();
			userPwd = user.getUserPwd();
			userName = user.getUserName();
			phoneNum = user.getPhoneNumber();
			cardNo = pref.getSharedPreference(Const.SP_CARDNO);
		}
		if ("MYMENU".equalsIgnoreCase(getLINKParam)) {
			try {
				paramValues = "W_ID=" + userId + "&W_PASSWD=" + URLEncoder.encode(SEEDUtil.encrypt(userPwd), "utf-8") + "&W_NAME=" + userName + "&mdn=" + phoneNum + "&hpcNo=" + mberNo + "&verA="
						+ getVersionCode() + "&cardnum=" + cardNo;
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		} else if ("EVENT".equalsIgnoreCase(getLINKParam)) {
			paramValues = "W_ID=" + userId + "&cardnum=" + cardNo + "&verA=" + getVersionCode() + "&hpcNo=" + mberNo;
		}else if ("DUNKIN".equalsIgnoreCase(getLINKParam)) {
			paramValues = "mbNo="+mberNo+"&cardnum="+cardNo+"&buyerMdn="+phoneNum;
		}

		return paramValues;
	}

	/**
	 * Date : 2014.10.06 작성자 : smile
	 * <dl>
	 * <b>현재 설치된 App의 버전을 확인한다.</b>
	 * </dl>
	 * 
	 * @return App의 현재 버전
	 */
	private String getVersionCode() {
		String version = "";
		try {
			PackageManager packageManager = HPCWebActivity.this.getPackageManager();
			PackageInfo info = packageManager.getPackageInfo(HPCWebActivity.this.getPackageName(), PackageManager.GET_META_DATA);
			version = info.versionName;
			int code = info.versionCode;

			Log.d("versionInfo", "version = " + version + ", code = " + code);
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}

		return version;
	}

	/**
	 * Date : 2014.10.06 작성자 : smile
	 * <dl>
	 * <b>Http GET 방식의 파라메타를 전송할 AyncTask 실행</b>
	 * </dl>
	 * 
	 * @param pUrl
	 */
	@SuppressLint("NewApi")
	private void run_Post(String pUrl) {
		String sep = "?";
		if (pUrl.indexOf("?") > -1) {
			sep = "&";
		}
		pUrl = pUrl + sep;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
			new Http_Get().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, pUrl);
		} else {
			new Http_Get().execute(pUrl);
		}
	}

	/**
	 * Date : 2014.10.06 작성자 : smile
	 * <dl>
	 * <b>Http GET 전송을 위한 AyncTask 클래스 정의</b>
	 * </dl>
	 */
	class Http_Get extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			String returnUrl = "";
			if (params.length > 0) {
				String mParam = params[0];
				Http_Param_Get(mParam);
			}
			return returnUrl;
		}
	}

	/**
	 * Date : 2014.10.06 작성자 : smile
	 * <dl>
	 * <b>HTTP GET 메세지 전송</b>
	 * </dl>
	 * 
	 * @param pUrl
	 * @return returnUrl
	 */
	private String Http_Param_Get(String pUrl) {
		String returnUrl = "";
		try {
			boolean IS_GET = true;
			String http_Get_param = "";
			Debug_Log.Log_E(this, "Http_Param_Get().pUrl: " + pUrl);

			if (pUrl.indexOf(Const.HOST_URL_SPC + "/front_v2/mymenu/") > -1) {
				if (is_url_param(pUrl)) {
					pUrl += "&";
				} else {
					pUrl += "?";
				}
				pUrl += addParam(Const.HOST_URL_SPC + "/front_v2/mymenu/");
			} else if (pUrl.indexOf(Const.HOST_URL_SPC + "/front_v2/event/") > -1) {
				if (is_url_param(pUrl)) {
					pUrl += "&";
				} else {
					pUrl += "?";
				}
				pUrl += addParam(Const.HOST_URL_SPC + "/front_v2/event/");
			}
			URL mUrl = new URL(pUrl);

			Debug_Log.Log_E(this, "Http_Param_Get().pUrl: " + pUrl);
			Debug_Log.Log_E(this, "Http_Param_Get().Eventparam: " + http_Get_param);
			HttpURLConnection con = (HttpURLConnection) mUrl.openConnection();

			if (IS_GET) {
				con.setDoOutput(false);
				con.setRequestMethod("GET");
				URLConnection uct = mUrl.openConnection();
				uct.connect();
			} else {
				con.setDoInput(true);
				con.setUseCaches(false);
				con.setConnectTimeout(10000);
				con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				con.setRequestProperty("Content-length", String.valueOf(http_Get_param.length()));
				con.setDoOutput(true);
				con.setRequestMethod("POST");
				OutputStreamWriter output = new OutputStreamWriter(con.getOutputStream());
				output.write(http_Get_param);
				output.flush();
				output.close();
			}
			Debug_Log.Log_E(this, "Http_Param_Get().IS_GET  : " + IS_GET);
			Debug_Log.Log_E(this, "Http_Param_Get().getRequestMethod()  : " + con.getRequestMethod());

			int resCode = con.getResponseCode();
			StringBuffer resultStr = new StringBuffer();
			Debug_Log.Log_E(this, "Http_Param_Get().resCode  : " + resCode);
			if (resCode == HttpURLConnection.HTTP_OK) {

				// 요청에 성공했으면 getInputStream 메서드로 입력 스트림을 얻어 서버로부터 전송된 결과를 읽습니다.
				InputStreamReader isr = new InputStreamReader(con.getInputStream(), "UTF-8");

				// 스트림을 직접읽으면 느리고 비효율 적이므로 버퍼를 지원하는 BufferedReader 객체를 사용합니다.
				BufferedReader br = new BufferedReader(isr);
				for (;;) {
					String line = br.readLine();
					if (line == null) {
						break;
					}
					resultStr.append(line + "\n");
				}
				br.close();
			}
			Debug_Log.Log_E(this, "Http_Param_Get().resultStr  : " + resultStr);

			returnUrl = con.getURL().toString();
			Debug_Log.Log_E(this, "Http_Param_Get().returnUrl  : " + returnUrl);
			con.disconnect();
		} catch (IOException e) {
			Debug_Log.Log_E(this, "IOException  : " + e.getMessage());
			e.printStackTrace();
		}
		return returnUrl;
	}
	
	// 웹뷰에서 스크립트로 디바이스 접근
	final class JavaScriptExtention {
		JavaScriptExtention() {
		}

		/**
		 * 결제 팝업 호출
		 * 
		 * @param param
		 */
		@JavascriptInterface
		public void payment(String param) {
			Intent intent = new Intent(HPCWebActivity.this, PopupActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
			intent.putExtra("url", Const.LINK_PAYMENT);
			intent.putExtra("param", param);
			intent.putExtra("type", "PAYMENT");
			startActivity(intent);
		}

		/**
		 * 결제 팝업 호출 (쿠프마케팅)
		 * @param url
		 * @param param
		 */
		@JavascriptInterface
		public void payment(String url, String param) {
			Debug_Log.Log_E(this, "payment.param : " + param);
			param = param.replace("?", "");
			String decode_result = "";
			try {
			decode_result = URLDecoder.decode(param, "UTF-8");
			Debug_Log.Log_E(this, "payment.decode_result : " + decode_result);
			param = decode_result;
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			Intent intent = new Intent(HPCWebActivity.this, PopupActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
			intent.putExtra("url", url);
			intent.putExtra("param", param);
			intent.putExtra("type", "PAYMENT");
			startActivity(intent);
		}
		
		/**
		 * 던킨 결제 팝업 호출 (쿠프마케팅)
		 * @param url
		 * @param param
		 */
		@JavascriptInterface
		public void dunkinpayment(String url, String param) {
			Debug_Log.Log_E(this, "payment.param : " + param);
			param = param.replace("?", "");
			String decode_result = "";
			try {
			decode_result = URLDecoder.decode(param, "UTF-8");
			Debug_Log.Log_E(this, "payment.decode_result : " + decode_result);
			param = decode_result;
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			Intent intent = new Intent(HPCWebActivity.this, DunkinPopupActivity.class);
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK  | Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_SINGLE_TOP);
			intent.putExtra("url", url);
			intent.putExtra("param", param);
			intent.putExtra("type", "PAYMENT");
			startActivity(intent);
		}

		/**
		 * SNS 팝업 호출 
		 * @param url
		 * @param link
		 */
		@JavascriptInterface
		public void popupSns(String url, String link){
			if(url.indexOf("kakaolink://")>-1){
				String msg = url.substring(url.indexOf("kakaolink://")+12);
				kakaoLink(msg, null, link, "이동하기", "WEB");
			}else if(url.indexOf("mypeople://")>-1){
				String msg = url.substring(url.indexOf("mypeople://")+11);
				mypeopleLink(msg, link);
			}else{
				Intent intent = new Intent(HPCWebActivity.this, PopupSns.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);
				intent.putExtra("url", url);
				startActivity(intent);
			}
		}

		/**
		 * tutorial 호출
		 */
		@JavascriptInterface
		public void callTutorial(){
			Intent intent = new Intent(HPCWebActivity.this, PopupTutorial.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			intent.putExtra("callMain", false);
			startActivity(intent);
		}

		/**
		 * 메뉴 페이지 이동
		 * @param menuType
		 * @param url
		 */
		@JavascriptInterface
		public void forwardTo(final String menuType, final String url){
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					// TODO Auto-generated method stub
					int menuId=0;
					
					if("MYMENU".equals(menuType)){
						menuId=Const.MENU_ID_POINT;
					}else if("EVENT".equals(menuType)){
						menuId=Const.MENU_ID_EVENT;
					}else if("GIFT".equals(menuType)){
						menuId=Const.MENU_ID_GIFT;
					}else if("CLUB".equals(menuType)){
						menuId=Const.MENU_ID_CLUB;
					}else if("COUPON".equals(menuType)){
						menuId=Const.MENU_ID_COUPON;
					}else if("SETTING".equals(menuType)){
						menuId=Const.MENU_ID_SETTING;
					} else if ("DUNKIN".equals(menuType)) {
						menuId = Const.MENU_ID_DUNKIN;
					}
					
					MenuAdapter.performClick(menuId, url);
				}
			});
		}
		
		/**
		 * 특정브랜드 맵 이동
		 * @param brand
		 * ex) searchMap("파리바게뜨");
		 */
		@JavascriptInterface
		public void searchMap(String brand) {
			Intent intent = new Intent(HPCWebActivity.this, NMapViewer.class);
			intent.putExtra("brand", brand);
			startActivity(intent);
		}

		private String linkParse(String link) {
			Debug_Log.Log_E(this, "linkParse : " + link);
			String menutype = "EVENT";
			String[] array = link.split("\\?");
			if (array.length > 1) {
				menutype = array[1];
				array = null;
				array = menutype.split("\\&");
				if (array.length > 0) {
					String[] paramsplit;
					for (int i = 0; i < array.length; i++) {
						paramsplit = array[i].split("\\=");
						if (paramsplit[0].indexOf("where") > -1) {
							menutype = paramsplit[1];
							break;
						} else {
							menutype = "EVENT";
						}
					}
				}
			}
			return menutype;
		}
		
		// 카카오링크 (메세지, 이미지, 링크, 버튼텍스트, 링크타입(WEB:모바일웹, APP:앱))
		@JavascriptInterface
		public void kakaoLink(String message, String imgSrc, String link, String linkText, String linkType){
			int width=300,height=300;
			String menutype = "";
			
			menutype = linkParse(link);
			Debug_Log.Log_E(this, "kakaoLink() message : " + message);
			Debug_Log.Log_E(this, "kakaoLink() imgSrc : " + imgSrc);
			Debug_Log.Log_E(this, "kakaoLink() link : " + link);
			Debug_Log.Log_E(this, "kakaoLink() linkText : " + linkText);
			Debug_Log.Log_E(this, "kakaoLink() linkType : " + linkType);
			try {
				final KakaoLink kakaoLink = KakaoLink.getKakaoLink(HPCWebActivity.this);
				final KakaoTalkLinkMessageBuilder kakaoTalkLinkMessageBuilder = kakaoLink.createKakaoTalkLinkMessageBuilder();
				
				kakaoTalkLinkMessageBuilder.addText(message);								// 1000자 미만
				if(!StringUtils.isEmpty(imgSrc))
					kakaoTalkLinkMessageBuilder.addImage(imgSrc, width, height);				// 70x70 이상, 500kb 미만
				
				if(StringUtils.isEmpty(linkText)){
					if("APP".equals(linkType))
						linkText = "앱 실행하기";
					else if("WEB".equals(linkType))
						linkText = "웹으로 이동하기";
					else
						linkText = "이동하기";
				}
				
				if("APP".equals(linkType)){
					if(!StringUtils.isEmpty(link)){
						AppActionBuilder app = new AppActionBuilder();
						app.addActionInfo(AppActionInfoBuilder.createAndroidActionInfoBuilder().setExecuteParam("hpeventurl="+link+ "&where=" + menutype).setMarketParam("referrer=kakaotalklink").build());
						app.addActionInfo(AppActionInfoBuilder.createiOSActionInfoBuilder().setExecuteParam("hpeventurl="+link+ "&where=" + menutype).build());
						
						kakaoTalkLinkMessageBuilder.addAppButton(linkText, app.build());
					}else{
						kakaoTalkLinkMessageBuilder.addAppButton(linkText);
					}
				}else if("WEB".equals(linkType)){
					kakaoTalkLinkMessageBuilder.addWebButton(linkText, link);
				}
				
				final String linkContents = kakaoTalkLinkMessageBuilder.build();
				kakaoLink.sendMessage(linkContents, HPCWebActivity.this);

			} catch (KakaoParameterException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		@JavascriptInterface
		public void mypeopleLink(String msg, String linkUrl){
//			String linkUrl = "http://115.144.168.14/front_v2/event/marketHpc.asp";
			String appName = "해피포인트카드";
			
			CustomSchemeURL.SendUrl csurl = new CustomSchemeURL.SendUrl(HPCWebActivity.this, msg, linkUrl, appName);
			
			if(csurl.canOpenMypeopleURL()){
				startActivity(csurl.getIntent());
			}else{
				CustomSchemeURL.openMypeopleDownloadPage(HPCWebActivity.this);
			}
		}
	}
	
	@Override
	protected void onNewIntent(Intent intent) {
		// TODO Auto-generated method stub
		super.onNewIntent(intent);
		Debug_Log.Log_E(this, "HPCWebActivity.onNewIntent()");
		SharedPref pref = new SharedPref(HPCWebActivity.this, Const.SP_KEY);
		String resumUrl = intent.getStringExtra("url");
		String resumpram = intent.getStringExtra("param");
		boolean isAuth = pref.getBooleanSharedPreference(Const.SP_AUTH);
		Debug_Log.Log_E(this, "MenuAdapter.OnClickListener().isAuth : " + isAuth);
		if (HappyPointSync.user == null) {
			Debug_Log.Log_E(this, "HPCWebActivty.onNewIntent().default ");
			intent = new Intent(HPCWebActivity.this, LoginActivity.class);
			startActivity(intent);
		}
		if (resumUrl != null && resumpram != null) {
			Debug_Log.Log_E(this, "HPCWebActivity.onResume().resumUrl : " + resumUrl);
			Debug_Log.Log_E(this, "HPCWebActivity.onResume().resumParam : " + resumpram);
			if (wv != null) {
				Debug_Log.Log_E(this, "wv != null");
				if (StringUtils.isEmpty(resumpram))
					wv.loadUrl(resumUrl);
				else {
					String sep = "?";
					if (resumUrl.indexOf("?") > -1)
						sep = "&";
					wv.loadUrl(resumUrl + sep + resumpram);
				}
			}
		}
	}
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Debug_Log.Log_E(this, "HPCWebActivity.onResume()");
		MenuAdapter.setBottomMenu(this, menu);
		MenuAdapter.setHeaderTextview(titleHeader);
		MenuAdapter.menuSelected();
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		overridePendingTransition(0, 0);
		Debug_Log.Log_E(this, "HPCWebActivity.onPause()");
		Log.d("============== ", "HPCWebActivity.onPause()");
		if (mProgressDialog != null && mProgressDialog.isShowing()) {
			mProgressDialog.dismiss();
		}
		if(wv!=null) {
			wv.clearCache(true);
		} 
		
		super.onPause();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		Debug_Log.Log_E(this, "HPCWebActivity.onDestroy()");
		
		super.onStop();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		// 웹뷰 뒤로가기 클릭시 액티비티종료 방지
		if (keyCode == KeyEvent.KEYCODE_BACK && wv != null && wv.canGoBack()) {
			wv.goBack();
			return true;
		} 
		HPCActivity.isMain = true;
		return super.onKeyDown(keyCode, event);
	}

}
