package com.hpapp.activity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.content.IntentCompat;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.hpapp.R;
import com.hpapp.adapter.HappyPointSync;
import com.hpapp.bean.UserBean;
import com.hpapp.popup.PopupActivity;
import com.hpapp.res.Const;
import com.hpapp.util.Debug_Log;
import com.hpapp.util.NetworkUtil;
import com.hpapp.util.SEEDUtil;
import com.hpapp.util.SharedPref;
import com.hpapp.util.StringUtils;

public class LoginActivity extends Activity {

	private SharedPref pref;
	private EditText editId, editPwd;
	private CheckBox chkAuto;
	private ImageButton btnLogin, btnSignup, btnFIndid;
	private ImageView btnClose;
	private int menuId;
	
	private HappyPointSync loginAcc = new HappyPointSync(this);
	private ProgressDialog progressDialog;

	private Context getDialogContext(){
		Context context;
		
		if(getParent() != null)
			context = getParent();
		else
			context = this;
		
		return context;
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		getWindow().setBackgroundDrawable(new ColorDrawable(Color.argb(180, 125, 125, 125)));
		setContentView(R.layout.activity_login);

		Intent intent = getIntent();
		menuId = intent.getIntExtra("menuId", 0);
//		pageId = intent.getIntExtra("pageCode", 0);

		editId = (EditText) findViewById(R.id.login_editId);
		editPwd = (EditText) findViewById(R.id.login_editPwd);
		chkAuto = (CheckBox) findViewById(R.id.login_chkAuto);
		btnLogin = (ImageButton) findViewById(R.id.login_btnLogin);
		btnSignup = (ImageButton) findViewById(R.id.btn_signup);
		btnFIndid = (ImageButton) findViewById(R.id.btn_find_id);
		btnClose = (ImageView) findViewById(R.id.login_btnClose);

		pref = new SharedPref(this, Const.SP_KEY);
		editId.setText(pref.getSharedPreference(Const.SP_ID));
		String pwd = pref.getSharedPreference(Const.SP_PWD);
		chkAuto.setChecked(pref.getBooleanSharedPreference(Const.SP_AUTOLOGIN, chkAuto.isChecked()));
		String encType = pref.getSharedPreference(Const.SP_ENCTYPE);

		if(chkAuto.isChecked()){
			try{
				if(!StringUtils.isEmpty(encType) && "AES".equals(encType))
					editPwd.setText(SEEDUtil.decryptAES(pwd));
				else
					editPwd.setText(SEEDUtil.decrypt(pwd));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				editPwd.setText("");
			}
		}else{
			editPwd.setText("");
			pref.putSharedPreference(Const.SP_PWD, "");
			pref.putSharedPreference(Const.SP_ENCTYPE, "");
		}
		
		// 로그인
		btnLogin.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String userId = editId.getText().toString().trim();
				String userPwd = editPwd.getText().toString().trim();
				userId = userId.replaceAll(" ", "");
				if(StringUtils.isEmpty(userId) || StringUtils.isEmpty(userPwd)){
					Builder dialog = new AlertDialog.Builder(getDialogContext());
					dialog.setTitle("알림");
					dialog.setMessage("로그인 아이디와 패스워드를 확인해 주십시오.");
					dialog.setNegativeButton("확인", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							dialog.dismiss();
						}
					});
					dialog.setCancelable(false);
					dialog.show();
				}else{
					new LoginAsync().execute();
//					AsyncService sink = new AsyncService();
//					sink.execute();
				}
			}
		});
		
		// 아이디 패스워드 찾기
		btnFIndid.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setData(Uri.parse(Const.LINK_FIND_IDPW));
				startActivity(intent);
			}
		});
		
		// 회원가입
		btnSignup.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(LoginActivity.this, PopupActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				intent.putExtra("url", Const.LINK_SIGNUP);
				intent.putExtra("param", "");
				intent.putExtra("type", "SIGNUP");
				startActivity(intent);
			}
		});
		
		// 닫기
		btnClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				onBackPressed();
			}
		});
	}
	
	private class LoginAsync extends AsyncTask<Void, Void, Map<String,String>>{

		SharedPref pref = new SharedPref(LoginActivity.this, Const.SP_KEY);

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(LoginActivity.this, "", "로그인 중 입니다...", true, true);
		}
		
		@Override
		protected Map<String,String> doInBackground(Void... params) {
			// TODO Auto-generated method stub
			Map<String,String> rspMap = null;
			String result = "";
			String id = editId.getText().toString().trim();
			String pwd = editPwd.getText().toString().trim();
			id = id.replaceAll(" ", "");
			pwd = pwd.replaceAll(" ", "");
			
			rspMap = loginAcc.actionLogin(Const.TYPE_ACC_ID, id, pwd, "L");
			if(rspMap!=null){
				result = rspMap.get("rspCode");
			}
			boolean chkResult = StringUtils.isEmpty(result)?false:("00".equals(result) || "13".equals(result))?true:false;

			if(chkResult){
				pref.putSharedPreference(Const.SP_ID, id);
				
				try {
					pref.putSharedPreference(Const.SP_PWD, SEEDUtil.encryptAES(pwd));
					pref.putSharedPreference(Const.SP_ENCTYPE, "AES");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					pref.putSharedPreference(Const.SP_PWD, SEEDUtil.encrypt(pwd));
					pref.putSharedPreference(Const.SP_ENCTYPE, "BASE64");
					e.printStackTrace();
				}
				
				InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(editPwd.getWindowToken(), 0); // 키보드 내리기
			}
			return rspMap;
		}

		@Override
		protected void onPostExecute(Map<String,String> rspMap) {
			// TODO Auto-generated method stub
			super.onPostExecute(rspMap);
			progressDialog.dismiss();
			String resultCode = "";
			String incardYn = "";
			
			if(rspMap!=null){
				resultCode = rspMap.get("rspCode");
				incardYn = rspMap.get("incardYn");
			}

			if("00".equals(resultCode) || "13".equals(resultCode)){
				String cardNo = pref.getSharedPreference(Const.SP_CARDNO);
				UserBean user = HappyPointSync.user;

				if(!StringUtils.isEmpty(cardNo)){
					boolean isOwn = false;
					if(user!=null && cardNo.equals(user.getMobileCardNo())){
						isOwn = true;
					}
					
					if(!isOwn){
						// 로그인 사용자의 카드번호가 저장된 번호와 틀릴경우 카드번호 삭제
						cardNo = user.getMobileCardNo();
						pref.putSharedPreference(Const.SP_CARDNO, cardNo);
						new AsyncSetBarcode().execute(cardNo);
					}else{
						pref.putSharedPreference(Const.SP_AUTOLOGIN, chkAuto.isChecked());
						setResult(RESULT_OK, (new Intent()).putExtra("menuId", menuId));
						finish();
					}
				}else{
					cardNo = user.getMobileCardNo();
					pref.putSharedPreference(Const.SP_CARDNO, cardNo);
					new AsyncSetBarcode().execute(cardNo);
				}
				
				if("Y".equals(incardYn)){
					String[] params = new String[1];
					params[0] = "cardNo=" + cardNo;
					
					new AsyncCouponReq().execute(params);
				}
			}else{
				try {
					Thread.sleep(300);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				Builder dialog = new AlertDialog.Builder(getDialogContext());
				dialog.setTitle("알림");

				if(!NetworkUtil.chkNetwork(LoginActivity.this) || "-99".equals(resultCode))
					dialog.setMessage("네트워크 장애로 로그인할 수 없습니다.");
				else if("500".equals(resultCode))
					dialog.setMessage("로그인 할 수 없습니다. \n잠시 후 다시 시도해 주시기 바랍니다.");
				else if("12".equals(resultCode))
					dialog.setMessage("가입된 회원이 아닙니다.");
				else if("14".equals(resultCode))
					dialog.setMessage("로그인 아이디와 패스워드를 확인해 주십시오.");
				else if("15".equals(resultCode))
					dialog.setMessage("로그인 아이디와 패스워드를 확인해 주십시오.");
				else
					dialog.setMessage("로그인 할 수 없습니다.");
				
				if("14".equals(resultCode) || "15".equals(resultCode))
					editPwd.setText("");
				
				dialog.setNegativeButton("확인", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						dialog.dismiss();
					}
				});
				dialog.setCancelable(false);
				dialog.create();
				dialog.show();
			}
		}
	}

	// 바코드이미지 셋팅
	private class AsyncSetBarcode extends AsyncTask<String, Void, Void>{

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(String... param) {
			// TODO Auto-generated method stub
			String cardNo = param[0];
			String pathRoot = "";
			String pathBarcode = "";

			if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
				pathRoot = Environment.getExternalStorageDirectory().getAbsolutePath() + "/spc";
			else
				pathRoot = Environment.getDataDirectory().getAbsolutePath() + "/spc";
			pathBarcode = pathRoot + "/.nomedia"; 

			if(!StringUtils.isEmpty(cardNo)){
				String fileName = "spc_"+cardNo+".png";
				
				File file = new File(pathBarcode+"/"+fileName);

				if(!file.exists()){
					File dir = new File(pathBarcode);
					if(!dir.exists())
						dir.mkdirs();

					downloadBarcode(file, cardNo);
				}
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			Intent intent = new Intent(LoginActivity.this, HPCActivity.class);
			if(Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB)
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | IntentCompat.FLAG_ACTIVITY_CLEAR_TASK);
			else
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
			intent.putExtra("recommendYn", pref.getSharedPreference(Const.SP_RECOMMEND));
			finish();
			startActivity(intent);
		}

		/**
		 * 바코드 다운로드
		 * @param file
		 * @param mbCardNo
		 * @return
		 */
		private boolean downloadBarcode(File file, String mbCardNo){
			int read;
			try{
				URL url = new URL("http://110.45.199.242:8099/barcode.php?str="+mbCardNo);
//				URL url = new URL("http://115.144.168.14:8088/barcode/barcode.php?str="+mbCardNo);
				HttpURLConnection conn = (HttpURLConnection)url.openConnection();
				int len = conn.getContentLength();
				byte[] bt = new byte[len];
				InputStream is = conn.getInputStream();
				FileOutputStream fos = new FileOutputStream(file);
				
				while(true){
					read = is.read(bt);
					if(read<=0)break;
					fos.write(bt, 0, read);
				}
				is.close();
				fos.close();
				conn.disconnect();
				
			}catch(IOException e){
				Log.e(Const.LOG_TAG, e.getMessage());
				return false;
			}
			return true;
		}
	}

	/**
	 * 인카드 쿠폰 발급 요청
	 * @author NOP
	 *
	 */
	private class AsyncCouponReq extends AsyncTask<String, Void, Void>{

		@Override
		protected Void doInBackground(String... params) {
			// TODO Auto-generated method stub
			
			try{
				URI uri = new URI(Const.LINK_RECOMMEND_CARD);
				URL url = uri.toURL();
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				
				con.setDoOutput(true);
				con.setDoInput(true);
				con.setUseCaches(false);
				con.setConnectTimeout(5000);

				StringBuffer sb = new StringBuffer();
				if(params!=null && params.length>0){
					for(int i=0;i<params.length;i++){
						if(i>0)
							sb.append("&");
						sb.append(params[i]);
					}
				}
				
				con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				con.setRequestProperty("Content-length", String.valueOf(sb.toString().length()));
				con.setRequestMethod("POST");
				
				OutputStreamWriter output = new OutputStreamWriter(con.getOutputStream());
				output.write(sb.toString());
				output.flush(); 
				
				int resCode = 0;
				resCode = con.getResponseCode();
				
		}catch(Exception e){
			e.printStackTrace();
		}
			return null;
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Debug_Log.Log_E(this , "LoginActivity.onResume()");
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		if (progressDialog != null) {
			progressDialog.dismiss();
		}
		Debug_Log.Log_E(this , "LoginActivity.onPause()");
		finish();
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Debug_Log.Log_E(this , "LoginActivity.onDestroy()");
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		Const.ACTION_TYPE = null;
		Const.ACTION_URL = null;
		return super.onKeyDown(keyCode, event);
	}
	
}
