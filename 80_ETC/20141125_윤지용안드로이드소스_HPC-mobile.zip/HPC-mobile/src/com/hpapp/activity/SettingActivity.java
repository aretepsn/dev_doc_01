package com.hpapp.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.IntentCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.daou.smartpush.servermodel.PushErrorCode;
import com.daou.smartpush.servermodel.callback.IPushServerInterface;
import com.daou.smartpush.smartpushmng.SmartPushManager;
import com.hpapp.R;
import com.hpapp.adapter.MenuAdapter;
import com.hpapp.map.NMapViewer;
import com.hpapp.res.Const;
import com.hpapp.util.SharedPref;
import com.hpapp.util.StringUtils;

public class SettingActivity extends Activity{

	private View menu;
	private ImageView btnBack;
	private SharedPref pref;
	private TextView currentVer, latestVer;
	private ToggleButton btnAutologin, btnPush;
	private ImageButton btnUpdate, btnLogout;
	private TextView titleHeader;
	private ImageView btnMap;
	private static final int SET_IS_PUSH_ENABLE = 100;		// push 수신설정 상태를 check box에 display 합니다.
	private SmartPushManager mSmartPushManager;
	private String checkStr;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        
        pref = new SharedPref(SettingActivity.this, Const.SP_KEY);

        menu = LayoutInflater.from(this).inflate(R.layout.footer_menu, null );
		LinearLayout menuRoot = (LinearLayout) findViewById(R.id.menu_foot);
		menuRoot.addView(menu);
		MenuAdapter.setBottomMenu(this, menu) ;
		
		titleHeader = (TextView) findViewById(R.id.txt_title_top);

		btnBack = (ImageView) findViewById(R.id.top_btn_prev);
		btnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				onBackPressed();
			}
		});
		btnMap = (ImageView) findViewById(R.id.top_btn_store);
		
		btnMap.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(SettingActivity.this, NMapViewer.class);
				startActivity(intent);
			}
		});

		currentVer = (TextView) findViewById(R.id.txt_currentVer);
		latestVer = (TextView) findViewById(R.id.txt_latestVer);
		btnAutologin = (ToggleButton) findViewById(R.id.btn_autologin);
		btnPush = (ToggleButton) findViewById(R.id.btn_push);
		btnUpdate = (ImageButton) findViewById(R.id.btn_update);
		btnLogout = (ImageButton) findViewById(R.id.btn_logout);
		
		boolean autoLogin = pref.getBooleanSharedPreference(Const.SP_AUTOLOGIN);
		boolean gcmActive = pref.getBooleanSharedPreference(Const.SP_GCM);

		if(autoLogin)
			btnAutologin.setChecked(true);
		else
			btnAutologin.setChecked(false);
		
//		if(gcmActive)
//			btnPush.setChecked(true);
//		else
//			btnPush.setChecked(false);
		mSmartPushManager = SmartPushManager.getInstance();
		initGCM();

		btnAutologin.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				if(isChecked)
					buttonView.setChecked(true);
				else
					buttonView.setChecked(false);

				pref.putSharedPreference(Const.SP_AUTOLOGIN, isChecked);
			}
		});
		
		btnPush.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
//				if(isChecked)
//					buttonView.setChecked(true);
//				else
//					buttonView.setChecked(false);
//				
//				pref.putSharedPreference(Const.SP_GCM, isChecked);
//				initGCM(isChecked);

				btnPush.setChecked(isChecked);
				checkStr = "y";
                if(!isChecked){
                	checkStr = "n";
                }
//                System.out.println("checkStr = " + checkStr);
				mSmartPushManager.setPushEnable(iPushSetPushEnableInterface, checkStr, SettingActivity.this);
			}
		});
		
		btnUpdate.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Uri uri = Uri.parse(Const.LINK_MARKET);
				Intent intent = new Intent(Intent.ACTION_VIEW, uri);
				startActivity(intent);
			}
		});

		double cVer = Double.parseDouble(getVersionCode());
		double lVer = 0;
		String strLatestVer = "-";
		if(!StringUtils.isEmpty(Const.LATEST_VERSION)){
			strLatestVer = Const.LATEST_VERSION;
			lVer = Double.parseDouble(strLatestVer);
		}
		
		currentVer.setText("현재버전 "+getVersionCode());
		latestVer.setText("최신버전 "+strLatestVer);

		if(cVer < lVer)
			btnUpdate.setVisibility(View.VISIBLE);
		else
			btnUpdate.setVisibility(View.GONE);

		btnLogout.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				pref.putSharedPreference(Const.SP_AUTH, false);
				pref.putSharedPreference(Const.SP_AUTOLOGIN, false);
				
				 // Setting에서 로그아웃시 main으로 돌아가 팝업이 다시 뜨기때문에 popupYN을 N으로 해둠.
//				pref.putSharedPreference(Const.SP_MAINPOPUP, "N");
				
				Intent intent = new Intent(SettingActivity.this, HPCActivity.class);
				if(Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB)
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | IntentCompat.FLAG_ACTIVITY_CLEAR_TASK);
				else
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
				finish();
				startActivity(intent);
			}
		});
		
    }
    
	// 현재 어플 버전코드 가져오기
	public String getVersionCode(){
		String version = "";
		try 
		{
		    PackageManager packageManager = getPackageManager();
		    PackageInfo info =  packageManager.getPackageInfo(getPackageName(), PackageManager.GET_META_DATA);
		    version = info.versionName;
		    int code = info.versionCode;
		    
		    Log.d("versionInfo", "version = " + version + ", code = " + code);
		 } 
		catch(NameNotFoundException e) 
		{
			e.printStackTrace();
		 }

		return version;
	}
	
	// 마켓 최신버젼코드 가져오기
//	private class LatestVersionAsync extends AsyncTask<Void, Void, String>{
//
//		@Override
//		protected void onPreExecute() {
//			// TODO Auto-generated method stub
//			super.onPreExecute();
//		}
//		
//		@Override
//		protected String doInBackground(Void... arg0) {
//			// TODO Auto-generated method stub
//			StringBuffer resp = new StringBuffer();
//
//			try{
//				URL url = new URL(Const.LINK_LATESTVER);
//				HttpURLConnection con = (HttpURLConnection) url.openConnection();
//				
//				con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
//				con.setDoOutput(true);
//				con.setDoInput(true);
//				con.setUseCaches(false);
//				con.setConnectTimeout(5000);
//				con.setRequestMethod("GET");
//				
//				PrintWriter pwr = new PrintWriter(new OutputStreamWriter(con.getOutputStream(), "utf-8"));
//				pwr.write("gubun=A");
//				pwr.flush();
//				
//				int resCode = 0;
//				resCode = con.getResponseCode();
//				
//				if(resCode < 400){
//					String line = "";
//					
//					BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
//					while((line=br.readLine())!=null){
//						resp.append(line);
//					}
//					br.close();
//				}else{
//					Log.d(Const.LOG_TAG, "데이터를 가져오는데 실패 하였습니다. 오류코드 : "+resCode);
//					return "-";
//				}
//				pwr.close();
//				
//			}catch(Exception e){
//				e.printStackTrace();
//				return "-";
//			}
//			
//			return resp.toString().trim();
//		}
//
//		@Override
//		protected void onPostExecute(String result) {
//			// TODO Auto-generated method stub
//			super.onPostExecute(result);
//			if(!StringUtils.isEmpty(result) && !"-".equals(result)){
//				double ver01 = Double.parseDouble(getVersionCode());
//				double ver02 = Double.parseDouble(result);
//
//				latestVer.setText("최신버전 " + result);
//
//				if(ver01 >= ver02){
//					btnUpdate.setVisibility(View.GONE);
//				}else{
//					btnUpdate.setVisibility(View.VISIBLE);
//				}
//			}
//		}
//	}
	
//    private void initGCM(boolean isActive){
//    	String senderID = Const.GCM_SENDER_ID;
//        
//        if(isActive){
//            Intent registrationIntent = new Intent("com.google.android.c2dm.intent.REGISTER");
//            registrationIntent.putExtra("app", PendingIntent.getBroadcast(this, 0, new Intent(), 0));
//            registrationIntent.putExtra("sender", senderID);
//            startService(registrationIntent);
//        }else{
//        	Intent unregIntent = new Intent("com.google.android.c2dm.intent.UNREGISTER");
//        	unregIntent.putExtra("app", PendingIntent.getBroadcast(this, 0, new Intent(), 0));
//        	startService(unregIntent);
//        }
	
	private void initGCM(){
    	mSmartPushManager.getPushEnable(iPushGetPushEnableInterface, this);
    }
   	
    private IPushServerInterface iPushGetPushEnableInterface = new IPushServerInterface() {
		
		@Override
		public void sendResult(String result, Object obj) {
			if(result.equals(PushErrorCode.RESULT_CODE_200)){
				mUIHandler.sendMessage(Message.obtain(mUIHandler, SET_IS_PUSH_ENABLE, obj));
				Log.i("INFO", "get Push Setting success !");
			} else {
				Log.i("INFO", "get Push Setting fail !");
			}
		}
		
		@Override
		public String getResponseResult() {
			return null;
		}
		
		@Override
		public Object getResponseObject() {
			return null;
		}
	};
	
	private IPushServerInterface iPushSetPushEnableInterface = new IPushServerInterface() {
		
		@Override
		public void sendResult(String result, Object obj) {
			if(result.equals(PushErrorCode.RESULT_CODE_200)){
				Log.i("INFO", "set Push Setting success !");
				mUIHandler.sendMessage(Message.obtain(mUIHandler, SET_IS_PUSH_ENABLE, obj));
			} else {
				Log.i("INFO", "set Push Setting fail !");
			}
		}
		
		@Override
		public String getResponseResult() {
			return null;
		}
		
		@Override
		public Object getResponseObject() {
			return null;
		}
	};
	
	private Handler mUIHandler = new Handler() {
		public void handleMessage(Message message) {
			switch (message.what) {
			case SET_IS_PUSH_ENABLE:
				if(message.obj != null){
					String enable = (String)message.obj;
					if(enable.equals("y")){
						btnPush.setChecked(true);
					} else {
						btnPush.setChecked(false);
					}
				}
				break;
				
			default:
				break;
			}
		}
	};
	
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Const.CURRENT_TAB=R.id.menu_setting;
		MenuAdapter.setBottomMenu(this, menu);
		MenuAdapter.setHeaderTextview(titleHeader);
		MenuAdapter.menuSelected();
	}
	
	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		overridePendingTransition(0, 0);
		super.onPause();
	}
}
