package com.hpapp.activity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.daou.smartpush.ConstValue.ConstValue;
import com.daou.smartpush.servermodel.PushErrorCode;
import com.daou.smartpush.servermodel.callback.IPushServerInterface;
import com.daou.smartpush.smartpushmng.SmartPushManager;
import com.hpapp.R;
import com.hpapp.adapter.HappyPointSync;
import com.hpapp.adapter.MenuAdapter;
import com.hpapp.bean.UserBean;
import com.hpapp.map.NMapViewer;
import com.hpapp.popup.EventPopupActivity;
import com.hpapp.popup.NewMemberPopupActivity;
import com.hpapp.popup.PopupActivity;
import com.hpapp.res.Const;
import com.hpapp.util.CommPopupDialog;
import com.hpapp.util.Debug_Log;
import com.hpapp.util.NetworkUtil;
import com.hpapp.util.Rotate3dAnimation;
import com.hpapp.util.SEEDUtil;
import com.hpapp.util.SharedPref;
import com.hpapp.util.StringUtils;

@SuppressLint("NewApi")
public class HPCActivity extends Activity {

	protected static boolean isMain = true;
	private View menu;
	private ImageButton btnStamp;
	private ImageView btnMap;
	private ImageView prepaid;
	private TextView notice;
	private LinearLayout inBox;
	private ViewGroup cardBox;
	private SharedPref pref;
	private boolean isFinish;
	boolean pushMapping;
	private int m_nPreTouchPosX;
	private boolean isFront = true;
	private final int REV_DURATION = 100;
	private ImageView frontView, imgBarcode;
	private TextView txtBarcode;
	private LinearLayout backView;
	private float centerX;
	private float centerY;
	private int displayWidth;

	private ProgressDialog progressDialog;
	private Handler mHdlr = new Handler(Looper.myLooper()){
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			super.handleMessage(msg);
			switch(msg.what)
			{
			case 0:
				final Dialog dialog = new Dialog(HPCActivity.this);
				dialog.setOwnerActivity(HPCActivity.this);
				dialog.setTitle(" Barcode");
				dialog.setContentView(R.layout.dialog_barcode);
				dialog.setCancelable(true);
				dialog.setCanceledOnTouchOutside(false);
				
				ImageView dialogImg = (ImageView) dialog.findViewById(R.id.img_barcode_big); 
				TextView dialogTxt = (TextView) dialog.findViewById(R.id.txt_barcode_big); 
				dialogImg.setImageDrawable(imgBarcode.getDrawable());
				dialogImg.setScaleType(ScaleType.FIT_CENTER);
				dialogTxt.setText(txtBarcode.getText().toString());
				dialogImg.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						dialog.dismiss();
					}
				});
				dialog.show();
				break;
			case 99:
				finish();
				break;
			}
		}
	};
	
	private String pushParam, versionParam, pushSeq, kakaolink, menutype;
	private Intent bannerIntent, newmemberIntent;

	private String kakaoParse(String link) {
		Debug_Log.Log_E(this, "kakaoParse : " + link);
		String[] array = link.split("\\?");
		if (array.length > 1) {
			menutype = array[1];
			array = null;
			array = menutype.split("\\&");
			if (array.length > 0) {
				String[] paramsplit;
				for (int i = 0; i < array.length; i++) {
					paramsplit = array[i].split("\\=");
					if (paramsplit[0].indexOf("where") > -1) {
						menutype = paramsplit[1];
						break;
					}
				}
			}
		}
		return menutype;
	}

	private int setmenu(String pMenuTpye) {
		int MENUTYPE = Const.MENU_ID_EVENT;
		if ("MAIN".equalsIgnoreCase(pMenuTpye)) {
			MENUTYPE = Const.MENU_ID_CARD;
		} else if ("MYMENU".equalsIgnoreCase(pMenuTpye)) {
			MENUTYPE = Const.MENU_ID_POINT;
		} else if ("EVENT".equalsIgnoreCase(pMenuTpye)) {
			MENUTYPE = Const.MENU_ID_EVENT;
		} else if ("GIFT".equalsIgnoreCase(pMenuTpye)) {
			MENUTYPE = Const.MENU_ID_GIFT;
		} else if ("CLUB".equalsIgnoreCase(pMenuTpye)) {
			MENUTYPE = Const.MENU_ID_CLUB;
		} else if ("COUPON".equalsIgnoreCase(pMenuTpye)) {
			MENUTYPE = Const.MENU_ID_COUPON;
		} else if ("INFO".equalsIgnoreCase(pMenuTpye)) {
			MENUTYPE = Const.MENU_ID_INFO;
		} else if ("SETTING".equalsIgnoreCase(pMenuTpye)) {
			MENUTYPE = Const.MENU_ID_SETTING;
		} else if ("DUNKIN".equalsIgnoreCase(pMenuTpye)) {
			MENUTYPE = Const.MENU_ID_DUNKIN;
		}

		return MENUTYPE;
	}
	
	// 이벤트, 버전알림 푸시 팝업
	private void mainPopup() {
		// TODO Auto-generated method stub
		Debug_Log.Log_E(this, "mainPopup()");
		int MENU_TYPE = 0;
		if (!StringUtils.isEmpty(kakaolink)) {
			if (menutype == null) {
				menutype = kakaoParse(kakaolink);
				MENU_TYPE = setmenu(menutype);
			} else {
				MENU_TYPE = setmenu(menutype);
			}
			MenuAdapter.performClick(MENU_TYPE, kakaolink);
			menutype = null;
			kakaolink = null;
		} else if(!StringUtils.isEmpty(pushParam) && pushParam.startsWith("EVENT")){
        	new AlertDialog.Builder(this)
        	.setPositiveButton("자세히", new DialogInterface.OnClickListener() {
        		@Override
        		public void onClick(DialogInterface dialog, int which) {
        			// TODO Auto-generated method stub
        			SmartPushManager mSmartPushManager; mSmartPushManager = SmartPushManager.getInstance();
        			mSmartPushManager.readPushMessage(mIsendReadserverInterface, getIntent().getStringExtra(ConstValue.IntentKey.MSG_TAG),HPCActivity.this);
        			Log.i("info","msgTag=" + getIntent().getStringExtra(ConstValue.IntentKey.MSG_TAG));
        			
        			if(StringUtils.isEmpty(pushSeq)) {
        				MenuAdapter.performClick(Const.MENU_ID_EVENT, Const.LINK_EVENT_LIST);
        			} else {
        				MenuAdapter.performClick(Const.MENU_ID_EVENT, Const.LINK_EVENT_VIEW+"?eventSeq="+pushSeq);
        			}
        		}
        	})
        	.setNegativeButton("닫기", new DialogInterface.OnClickListener() {
        		@Override
        		public void onClick(DialogInterface dialog, int which) {
        			// TODO Auto-generated method stub
        			dialog.dismiss();
        			mainPopup();
        		}
        	})
        	.setTitle("이벤트")
        	.setMessage(pushParam.substring(8))
        	.show();
        	pushParam = null;
        } else if(!StringUtils.isEmpty(pushParam) && pushParam.startsWith("MENULINK")){
        	if("EVENT".equals(pushParam.substring(11))) {
        		SmartPushManager mSmartPushManager; mSmartPushManager = SmartPushManager.getInstance();
    			mSmartPushManager.readPushMessage(mIsendReadserverInterface, getIntent().getStringExtra(ConstValue.IntentKey.MSG_TAG),HPCActivity.this);
    			
    			Log.i("info","msgTag=" + getIntent().getStringExtra(ConstValue.IntentKey.MSG_TAG));
    			
        		if(StringUtils.isEmpty(pushSeq))
        			MenuAdapter.performClick(Const.MENU_ID_EVENT, Const.LINK_EVENT_VIEW);
        		else
        			MenuAdapter.performClick(Const.MENU_ID_EVENT, Const.LINK_EVENT_VIEW+"?eventSeq="+pushSeq);
        	}
        }else{
        	if(!StringUtils.isEmpty(versionParam)){
            	new AlertDialog.Builder(this)
            	.setNegativeButton("업데이트", new DialogInterface.OnClickListener() {
            		@Override
            		public void onClick(DialogInterface dialog, int which) {
            			// TODO Auto-generated method stub
            			Intent market = new Intent(Intent.ACTION_VIEW);
            			market.setData(Uri.parse(Const.LINK_MARKET));
            			startActivity(market);
            			dialog.dismiss();
            		}
            	})
            	.setPositiveButton("나중에", new DialogInterface.OnClickListener() {
            		@Override
            		public void onClick(DialogInterface dialog, int which) {
            			// TODO Auto-generated method stub
            			pref.putSharedPreference(Const.SP_IS_ALERT_VERSION, true);
            			dialog.dismiss();
            			mainPopup();
            		}
            	})
            	.setTitle("알림")
            	.setMessage(versionParam)
            	.show();
            	versionParam = null;
        	}else{
        		if(bannerIntent!=null){
        			startActivity(bannerIntent);
                	pref.putSharedPreference(Const.SP_MAINPOPUP, "N");
        		}
        	}
        }

	}

	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hpc);
        pref = new SharedPref(HPCActivity.this, Const.SP_KEY);
        Debug_Log.Log_E(this, "HPCActivity.onCreate()");
        Const.CURRENT_TAB=R.id.menu_card;
        
		menu = LayoutInflater.from(this).inflate(R.layout.footer_menu, null );
		LinearLayout menuRoot = (LinearLayout) findViewById(R.id.menu_foot);
		menuRoot.addView(menu);
		MenuAdapter.setBottomMenu(this, menu) ;

		displayWidth = getResources().getDisplayMetrics().widthPixels;
		
		kakaolink = getIntent().getStringExtra("kakaolink");
		menutype = getIntent().getStringExtra("where");
		pushParam = getIntent().getStringExtra("params");
		pushSeq = getIntent().getStringExtra("seq");
		
		btnStamp = (ImageButton) findViewById(R.id.top_btn_stamp);
		btnMap = (ImageView) findViewById(R.id.top_btn_store);
		prepaid = (ImageView) findViewById(R.id.top_btn_prepaid);
		
		btnStamp.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View view) {
				// TODO Auto-generated method stub
				boolean isAuth = pref.getBooleanSharedPreference(Const.SP_AUTH);
				
				if(isAuth){
					String id = pref.getSharedPreference(Const.SP_ID);
					String cardNo = pref.getSharedPreference(Const.SP_CARDNO);

					Intent intent = new Intent(HPCActivity.this, StampActivity.class);
					intent.putExtra("url", Const.LINK_STAMP);
					intent.putExtra("param", "W_ID="+id+"&cardNum="+cardNo);
					startActivity(intent);
					overridePendingTransition(R.anim.stamp_enter, R.anim.stamp_bg_hide);
				}else{
					Intent intent = new Intent(HPCActivity.this, LoginActivity.class);
					startActivityForResult(intent, Const.REQ_LOGIN_STAMP);
				}
			}
		});
		
		btnMap.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(HPCActivity.this, NMapViewer.class);
				startActivity(intent);
			}
		});

		prepaid.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				UserBean user = HappyPointSync.user;
				String urlStr = Const.HOST_URL_DUNKIN;
				if (user != null) {
					Const.CURRENT_TAB = R.id.top_btn_prepaid;
					Debug_Log.Log_E(this, "HPCActivty.prepaid.OnClickListener()HOST_URL_DUNKIN");
					String	mberNo = user.getUserNo();
					String phoneNum = user.getPhoneNumber();
					String cardNo = pref.getSharedPreference(Const.SP_CARDNO);
					
					String param = "mbNo="+mberNo+"&cardnum="+cardNo+"&buyerMdn="+phoneNum;
					
					Intent intent = new Intent(HPCActivity.this, HPCWebActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
					intent.putExtra("url", urlStr);
					intent.putExtra("param", param);
					startActivity(intent);
				} else if (HappyPointSync.user == null) {
					Debug_Log.Log_E(this, "HPCActivty.prepaid.OnClickListener() -> Login");
					Intent intent = new Intent(HPCActivity.this, LoginActivity.class);
					startActivity(intent);
				}
				MenuAdapter.menuSelected();
			}
		});
		notice = (TextView) findViewById(R.id.txt_notice);
		
		String cardNo = pref.getSharedPreference("cardNo");

		if(!StringUtils.isEmpty(cardNo)){
			pref.putSharedPreference(Const.SP_CARDNO, cardNo);
			pref.putSharedPreference("cardNo", "");
		}
		cardNo = pref.getSharedPreference(Const.SP_CARDNO);

		String memberClass = pref.getSharedPreference(Const.SP_CLASS);
		
		inBox = (LinearLayout) findViewById(R.id.inBox);

		if (!NetworkUtil.chkNetwork(this)) {
			Toast.makeText(HPCActivity.this, "네트워크 상태를 확인해 주십시요.", Toast.LENGTH_SHORT).show();
		}

		String recommendYn = getIntent().getStringExtra("recommendYn");
		if("Y".equals(recommendYn)){
			newmemberIntent = new Intent(HPCActivity.this, NewMemberPopupActivity.class);
			startActivity(newmemberIntent);
			pref.putSharedPreference(Const.SP_RECOMMEND, "N");
			pref.putSharedPreference(Const.SP_RECOMMEND_POPUP, "Y");
			pref.putSharedPreference(Const.SP_MAINPOPUP, "N");
		}
		
		if(!StringUtils.isEmpty(cardNo)){
			getLayoutInflater().inflate(R.layout.main_card, inBox);
			
			cardBox = (ViewGroup) findViewById(R.id.main_card_big);
			frontView = (ImageView) findViewById(R.id.card_front);
			backView = (LinearLayout) findViewById(R.id.card_back);
			imgBarcode = (ImageView) findViewById(R.id.main_img_barcode);
			txtBarcode = (TextView) findViewById(R.id.main_txt_barcode);
			
			ImageView facebook = (ImageView) backView.findViewById(R.id.btn_facebook);
			ImageView tstory = (ImageView) backView.findViewById(R.id.btn_tstory);
			ImageView spcBrand = (ImageView) backView.findViewById(R.id.btn_spc);
			ImageView hpcPartner = (ImageView) backView.findViewById(R.id.btn_hpc);
			ImageView spcMweb = (ImageView) backView.findViewById(R.id.btn_spc_mweb);
			ImageView customer = (ImageView) backView.findViewById(R.id.btn_customer);
			
	        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
	           	new AsyncSetBarcode().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, cardNo);
	        else
	        	new AsyncSetBarcode().execute(cardNo);

			cardBox.setOnTouchListener(cardTouchListener);
			facebook.setOnTouchListener(cardTouchListener);
			tstory.setOnTouchListener(cardTouchListener);
			spcBrand.setOnTouchListener(cardTouchListener);
			hpcPartner.setOnTouchListener(cardTouchListener);
			spcMweb.setOnTouchListener(cardTouchListener);
			customer.setOnTouchListener(cardTouchListener);

			// 맴버 등급별 카드이미지 적용
			setCardImage(Const.CARD_RESID(memberClass));
			
			txtBarcode.setText(cardNo);
			
			ImageButton btnGame = (ImageButton) findViewById(R.id.btn_game);
//			btnGame.setImageResource(R.anim.frame_anim);
//			AnimationDrawable frameAnim = (AnimationDrawable) btnGame.getDrawable();
//			frameAnim.start();
			btnGame.setVisibility(View.GONE);
			
			LinearLayout cardTwistLeft = (LinearLayout) findViewById(R.id.btn_twist_left);
			cardTwistLeft.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if (isFront) {
						applyRotation(0f, 90f, 180f, 0f);
					} else {
						applyRotation(180f, 90f, 0f, 0f);
					}
				}
			});

			LinearLayout cardTwistRight = (LinearLayout) findViewById(R.id.btn_twist_right);
			cardTwistRight.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					if (isFront) {
						applyRotation(0f, 90f, 180f, 0f);
					} else {
						applyRotation(180f, 90f, 0f, 0f);
					}
				}
			});
			
			ImageButton btnPointSearch = (ImageButton) findViewById(R.id.btn_point);
			btnPointSearch.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					String cardNo = pref.getSharedPreference(Const.SP_CARDNO);
					String Param = "?cardNo="+cardNo;
					MenuAdapter.performClick(Const.MENU_ID_POINT, null);
				}
			});
			ImageButton btnPointSave = (ImageButton) findViewById(R.id.btn_point_save);
			btnPointSave.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					MenuAdapter.performClick(Const.MENU_ID_POINT, Const.LINK_HAPPYVIRUS);
				}
			});
			ImageButton btnCouponCheck = (ImageButton) findViewById(R.id.btn_coupon_check);
			btnCouponCheck.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					MenuAdapter.performClick(Const.MENU_ID_POINT, Const.LINK_MYCOUPON);
				}
			});
			
			/**
			 * 캐릭터 애니메이션
			 */
//			startAni((ImageView) findViewById(R.id.icon_happy),300);
			leaderAni(R.id.ani_blue, R.drawable.ani_blue, R.drawable.ani_blue_left, 0);
			
		}else{ // 등록카드 없을시
			getLayoutInflater().inflate(R.layout.main_nocard, inBox);
			
			ImageButton btnLogin = (ImageButton) findViewById(R.id.main_btn_issue);
			ImageButton findIdPw = (ImageButton) findViewById(R.id.main_btn_service);
			ImageButton newjoin = (ImageButton) findViewById(R.id.main_btn_join);
			
			// 로그인
			btnLogin.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(HPCActivity.this, LoginActivity.class);
					startActivityForResult(intent, Const.REQ_LOGIN_POPUP);
				}
			});
			
			// 아이디/패스워드찾기
			findIdPw.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(Intent.ACTION_VIEW);
					intent.setData(Uri.parse(Const.LINK_FIND_IDPW));
					startActivity(intent);
				}
			});
			
			// 신규회원가입
			newjoin.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(HPCActivity.this, PopupActivity.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.putExtra("url", Const.LINK_SIGNUP);
					intent.putExtra("param", "");
					intent.putExtra("type", "SIGNUP");
					startActivity(intent);
				}
			});
		}
		
		// 서버점검 체크
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
           	new AsyncService().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
        else
        	new AsyncService().execute();

    }

	private OnTouchListener cardTouchListener = new OnTouchListener() {
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			// TODO Auto-generated method stub
    		if (event.getAction() == MotionEvent.ACTION_DOWN)
    		{
    			m_nPreTouchPosX = (int)event.getX();
    		}
    		
    		if (event.getAction() == MotionEvent.ACTION_UP)
    		{
    			int nTouchPosX = (int)event.getX();
    			int m_gesture = m_nPreTouchPosX-nTouchPosX;
    			
    			if(m_gesture>16){
					if(isFront){
						applyRotation(0f, -90f, -180f, 0f);
					}else{
						applyRotation(0f, -90f, -180f, 0f);
					}
    			}else if(m_gesture<-16){
					if(isFront){
						applyRotation(0f, 90f, 180f, 0f);
					}else{
						applyRotation(0f, 90f, 180f, 0f);
					}
    				
    			}else{
    				Intent intent = null;
    				CommPopupDialog popup = null;
    				
    				switch(v.getId())
    				{
    				case R.id.btn_facebook:
    					intent = new Intent(Intent.ACTION_VIEW);
    					intent.setData(Uri.parse(Const.LINK_FACEBOOK));
    					startActivity(intent);
    					break;
    				case R.id.btn_tstory:
    					intent = new Intent(Intent.ACTION_VIEW);
    					intent.setData(Uri.parse(Const.LINK_TISTORY));
    					startActivity(intent);
    					break;
    				case R.id.btn_spc:
    					popup = new CommPopupDialog(HPCActivity.this, Const.LINK_SPCBRAND, "SPC", "브랜드");
    					popup.show();
    					break;
    				case R.id.btn_hpc:
    					popup = new CommPopupDialog(HPCActivity.this, Const.LINK_HPCPARTNER, "HPC", "제휴사");
    					popup.show();
    					break;
    				case R.id.btn_spc_mweb:
    					intent = new Intent(Intent.ACTION_VIEW);
    					intent.setData(Uri.parse(Const.LINK_HPC_MOBILE));
    					startActivity(intent);
    					break;
    				case R.id.btn_customer:
    					intent = new Intent(Intent.ACTION_DIAL);
    					intent.setData(Uri.parse("tel:0803201234"));
    					startActivity(intent);
    					break;
    				case R.id.card_front:
						Debug_Log.Log_E(this, "frontView.getWidth : "+frontView.getWidth());
						Debug_Log.Log_E(this, "frontView.getHeight : "+frontView.getHeight());
						break;
    				}
    			}
    			
    		}
			return true;
		}
	};

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(requestCode==Const.REQ_LOGIN_POPUP){
			if(resultCode==RESULT_OK){
				
			}
		}else if(requestCode==Const.REQ_LOGIN_STAMP){
			if(resultCode==RESULT_OK){
				String id = pref.getSharedPreference(Const.SP_ID);
				
				Intent intent = new Intent(HPCActivity.this, StampActivity.class);
				intent.putExtra("url", Const.LINK_STAMP);
				intent.putExtra("param", "W_ID="+id);
				startActivity(intent);
				overridePendingTransition(R.anim.stamp_enter, R.anim.stamp_bg_hide);
			}
		}else if(requestCode==Const.REQ_LOGIN_SUBMENU){
			if(resultCode==RESULT_OK){
				int menuId = data.getIntExtra("menuId", 0);
				ImageButton btnTemp = (ImageButton) findViewById(menuId);
				if(btnTemp!=null){
					btnTemp.performClick();
					isMain = false;
				}
			}
		}
	}

    /**
     * 등급별 카드 이미지 적용
     * @param cardId
     */
    private void setCardImage(int cardId){
    	frontView.setImageResource(cardId);
    }
    
    /**
     * 알림창 생성
     * @param message
     */
	private void alert(String message){
		AlertDialog.Builder alert = new AlertDialog.Builder(this);
		alert.setPositiveButton("확인", null);
		alert.setMessage(message);
		alert.show();
	}

    /**
     * 3D rotation 효과
     * @param start
     * @param mid
     * @param end
     * @param depth
     */
    private void applyRotation(float start, float mid, float end, float depth) {
      this.centerX = cardBox.getWidth() / 2.0f;
      this.centerY = cardBox.getHeight() / 2.0f;
      boolean reverse = false;

      if(start > mid)
    	  reverse = true;
      
      Rotate3dAnimation rot = new Rotate3dAnimation(start, mid, centerX, centerY, depth, reverse);
      rot.setDuration(REV_DURATION);
      rot.setInterpolator(new AccelerateInterpolator());
      rot.setAnimationListener(new DisplayNextView(mid, end, depth, !reverse));
      cardBox.startAnimation(rot);
    }

	private class DisplayNextView implements AnimationListener {
    	private float mid;
    	private float end;
    	private float depth;
        private boolean reverse;

    	public DisplayNextView(float mid, float end, float depth, boolean reverse) {
    		this.mid = mid;
    		this.end = end;
    		this.depth = depth;
    		this.reverse = reverse;
    	}

    	public void onAnimationEnd(Animation arg0) {
    		cardBox.post(new Runnable() {
    			public void run() {
    				Rotate3dAnimation rot = new Rotate3dAnimation(mid, end, centerX, centerY, depth, reverse);
    				rot.setDuration(REV_DURATION);
    				rot.setInterpolator(new AccelerateInterpolator());
    				rot.setAnimationListener(new AnimationListener() {
						@Override
						public void onAnimationStart(Animation animation) {
							// TODO Auto-generated method stub
		    				if (isFront) {
		    					frontView.setVisibility(View.GONE);
		    					backView.setVisibility(View.VISIBLE);
								((ImageView)findViewById(R.id.card_dot_1)).setImageResource(R.drawable.main_dot_non);
								((ImageView)findViewById(R.id.card_dot_2)).setImageResource(R.drawable.main_dotplay);
								isFront = false;
		    				} else {
		    					frontView.setVisibility(View.VISIBLE);
		    					backView.setVisibility(View.GONE);
								((ImageView)findViewById(R.id.card_dot_1)).setImageResource(R.drawable.main_dotplay);
								((ImageView)findViewById(R.id.card_dot_2)).setImageResource(R.drawable.main_dot_non);
								isFront = true;
		    				}
						}
						
						@Override
						public void onAnimationRepeat(Animation animation) {
							// TODO Auto-generated method stub
						}
						
						@Override
						public void onAnimationEnd(Animation animation) {
							// TODO Auto-generated method stub
	    					frontView.setVisibility(View.VISIBLE);
						}
					});
    				cardBox.startAnimation(rot);
    			}
    		});
    	}

		public void onAnimationStart(Animation arg0) {
			frontView.setVisibility(View.VISIBLE);
    	}

    	public void onAnimationRepeat(Animation arg0) {
    	}
    }
    
	// 바코드이미지 셋팅
	private class AsyncSetBarcode extends AsyncTask<String, Void, ArrayList<Object>>{

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressDialog = ProgressDialog.show(HPCActivity.this, "", "바코드 로딩중 입니다...", true, true);
		}

		@Override
		protected ArrayList<Object> doInBackground(String... param) {
			// TODO Auto-generated method stub
			ArrayList<Object> arr = null;
			String cardNo = param[0];
			String pathRoot = "";
			String pathBarcode = "";

			if(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
				pathRoot = Environment.getExternalStorageDirectory().getAbsolutePath() + "/spc";
			else
				pathRoot = Environment.getDataDirectory().getAbsolutePath() + "/spc";

			if(isStorage(false) == false) {
				pathRoot = getFilesDir().getAbsolutePath() + "/spc";
			}
			
			pathBarcode = pathRoot + "/.nomedia"; 
			
			// SD카드가 있을때
			if(!StringUtils.isEmpty(cardNo)){
				boolean check = true;
				String fileName = "spc_"+cardNo+".png";
				
				File file = new File(pathBarcode+"/"+fileName);
				
				if(!file.exists()){
					File dir = new File(pathBarcode);
					if(!dir.exists())
						dir.mkdirs();

					check = downloadBarcode(file, cardNo);
				}

				arr = new ArrayList<Object>();
				arr.add(check);
				arr.add(file.getAbsolutePath());
				arr.add(cardNo);
				
			} 
			
			return arr;
		}

		@Override
		protected void onPostExecute(ArrayList<Object> arr) {
			// TODO Auto-generated method stub
			progressDialog.dismiss();

			if(arr!=null){
				boolean check = (Boolean) arr.get(0);
				
				if(check){
					if(imgBarcode==null){
						imgBarcode = (ImageView) findViewById(R.id.main_img_barcode);
					}
					if(txtBarcode==null){
						txtBarcode = (TextView) findViewById(R.id.main_txt_barcode);
					}
					
					String path = arr.get(1).toString();
					
					Bitmap bitmap = BitmapFactory.decodeFile(path);
					imgBarcode.setImageBitmap(bitmap);
					txtBarcode.setText(arr.get(2).toString());

					imgBarcode.bringToFront();
					imgBarcode.setVisibility(View.VISIBLE);
					imgBarcode.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							// TODO Auto-generated method stub
							mHdlr.sendEmptyMessage(0);
						}
					});
				}
			}else{
				alert("바코드를 가져오는 중 오류가 발생했습니다. 해피포인트카드 어플을 다시 실행해 주세요.");
			}
        	new AutoLogin().execute();
		}
		
		// SD카드 존재여부
		private boolean isStorage(boolean requireWriteAccess) {

	         String state = Environment.getExternalStorageState();

	          if (Environment.MEDIA_MOUNTED.equals(state)) {

	                return true;

	          } else if (!requireWriteAccess && 

	               Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {

	               return true;

	          }
	          return false;
	    }

		
		/**
		 * 바코드 다운로드
		 * @param file
		 * @param mbCardNo
		 * @return
		 */
		private boolean downloadBarcode(File file, String mbCardNo){
			int read;
			try{
				URL url = new URL("http://110.45.199.242:8099/barcode.php?str="+mbCardNo);
//				URL url = new URL("http://115.144.168.14:8088/barcode/barcode.php?str="+mbCardNo);
				HttpURLConnection conn = (HttpURLConnection)url.openConnection();
				int len = conn.getContentLength();
				byte[] bt = new byte[len];
				InputStream is = conn.getInputStream();
				FileOutputStream fos = new FileOutputStream(file);
				
				while(true){
					read = is.read(bt);
					if(read<=0)break;
					fos.write(bt, 0, read);
				}
				is.close();
				fos.close();
				conn.disconnect();
				
			}catch(IOException e){
				Log.e(Const.LOG_TAG, e.getMessage());
				return false;
			}
			return true;
		}
	}

	/**
	 * 최신 컨텐츠 유무 확인
	 * @author NOP
	 *
	 */
	private class AsyncNewItem extends AsyncTask<Void, Void, String>{

		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}
		
		@Override
		protected String doInBackground(Void... arg0) {
			// TODO Auto-generated method stub
			StringBuffer resp = new StringBuffer();

			try{
				PackageManager packageManager = getPackageManager();
				PackageInfo info =  packageManager.getPackageInfo(getPackageName(), PackageManager.GET_META_DATA);
				String version = info.versionName;

				URL url = new URL(Const.URI_NEW_ITEMS+"?verA="+version);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				
				con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				con.setDoOutput(true);
				con.setDoInput(true);
				con.setUseCaches(false);
				con.setConnectTimeout(5000);
				con.setRequestMethod("GET");
				
				PrintWriter pwr = new PrintWriter(new OutputStreamWriter(con.getOutputStream(), "utf-8"));
//				pwr.write("gubun=A");
				pwr.flush();
				
				int resCode = 0;
				resCode = con.getResponseCode();
				
				if(resCode < 400){
					String line = "";
					
					BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
					while((line=br.readLine())!=null){
						resp.append(line);
					}
					br.close();
				}else{
					Log.d(Const.LOG_TAG, "데이터를 가져오는데 실패 하였습니다. 오류코드 : "+resCode);
					return "-";
				}
				pwr.close();
				
			}catch(Exception e){
				e.printStackTrace();
				return "-";
			}
			
			return resp.toString().trim();
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(!StringUtils.isEmpty(result)){
				try {
					InputSource is = new InputSource(new StringReader(result));
					
					DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
					DocumentBuilder db = dbf.newDocumentBuilder();
					Document doc = db.parse(is);
					
					// root노드 구하기
					Element root = doc.getDocumentElement();
					
					// 한줄공지
					String lineNotice = getNodeValue(root, "//mainLinkNotice/noticeContents");
					if(!StringUtils.isEmpty(lineNotice)){
						
						// MYMENU, EVENT, GIFT, CLUB, COUPON, SETTING
						final String noticeType = getNodeValue(root, "//mainLinkNotice/noticeType");
						final String noticeUrl = getNodeValue(root, "//mainLinkNotice/noticeUrl");
						
						notice.setText(lineNotice);
						notice.setSelected(true);
						
						if(!StringUtils.isEmpty(noticeType)){
							notice.setOnClickListener(new OnClickListener() {
								@Override
								public void onClick(View arg0) {
									// TODO Auto-generated method stub
									int menuId = 0;
									
									if("MYMENU".equals(noticeType)){
										menuId=Const.MENU_ID_POINT;
									}else if("EVENT".equals(noticeType)){
										menuId=Const.MENU_ID_EVENT;
									}else if("GIFT".equals(noticeType)){
										menuId=Const.MENU_ID_GIFT;
									}else if("CLUB".equals(noticeType)){
										menuId=Const.MENU_ID_CLUB;
									}else if("COUPON".equals(noticeType)){
										menuId=Const.MENU_ID_COUPON;
									}else if("SETTING".equals(noticeType)){
										menuId=Const.MENU_ID_SETTING;
									}else if("INFO".equals(noticeType)){
										menuId=Const.MENU_ID_INFO;
									} else if ("DUNKIN".equals(noticeType)) {
										menuId = Const.MENU_ID_DUNKIN;
									}
									
									MenuAdapter.performClick(menuId, noticeUrl);
								}
							});
						}
					}
					// 신규 이벤트
					String rspEvent = getNodeValue(root, "//rsp/event");
					String rspEventKey = getNodeValue(root, "//rsp/event_key");
					// 신규 해피패밀리
					String rspHappy = getNodeValue(root, "//rsp/happy");
					// 신규 공지사항
					String rspNotice = getNodeValue(root, "//rsp/notice");
					String rspNoticeKey = getNodeValue(root, "//rsp/notice_key");
					// 최신 버전
					String rspVersion = getNodeValue(root, "//version/android");
					// 메인 이벤트배너
					String rspBanner = getNodeValue(root, "//rsp/mainEvent");
					// 스탬프 이벤트
					String rspStamp = getNodeValue(root, "//rsp/stampEvent");
					// 신규 선물하기
					String rspGift = getNodeValue(root, "//rsp/gift");
					String rspGiftKey = getNodeValue(root, "//rsp/gift_key");
					
					if(!StringUtils.isEmpty(rspStamp) && "N".equals(rspStamp)){
						btnStamp.setVisibility(View.GONE);
					}
					// 메인팝업 유무
					String popup = pref.getSharedPreference(Const.SP_MAINPOPUP);
					/**
					 * 로그인 상태에서 Setting으로가 로그아웃을 했을때 메인으로 다시 돌아오면서 팝업이 뜬다.
					 * 그래서 setting에서 로그아웃할 때에는 Const.SP_MAINPOPUP값을 N으로 두어
					 * 다시 메인으로 돌아올 때 메인팝업 실행을 안하게 했고,
					 * 계속  Const.SP_MAINPOPUP값이 N이게 되면 앞으로 팝업을 볼수 없으니
					 * 처음 앱 실행(IntroActivity을 실행했을때)을 했을 때 Const.SP_MAINPOPUP값을 Y로 바꾸었다.
					 */
					
					if("Y".equals(popup)) {
						if(!StringUtils.isEmpty(rspBanner) && "Y".equals(rspBanner)){
							String imgUrl = getNodeValue(root, "//eventContent/imgUrl");
							String pathUrl = getNodeValue(root, "//eventContent/pathUrl");
							String gubun = getNodeValue(root, "//eventContent/gubun");
							String eventSeq = getNodeValue(root, "//eventContent/seq");
							
							if(!eventSeq.equals(pref.getSharedPreference(Const.SP_BANNER_KEY))){
								pref.putSharedPreference(Const.SP_BANNER_EXPIRE, 0l);
							}
								
							long expireDate = pref.getLongSharedPreference(Const.SP_BANNER_EXPIRE);
							if(expireDate>0){
								long currentDate = System.currentTimeMillis();
								if(currentDate-expireDate > (1000*60*60*24)){
									bannerIntent = new Intent(HPCActivity.this, EventPopupActivity.class);
									bannerIntent.putExtra("imgUrl", imgUrl);
									bannerIntent.putExtra("pathUrl", pathUrl);
									bannerIntent.putExtra("gubun", gubun);
									bannerIntent.putExtra("eventSeq", eventSeq);
									pref.putSharedPreference(Const.SP_BANNER_EXPIRE, 0l);
								}
							}else{
								bannerIntent = new Intent(HPCActivity.this, EventPopupActivity.class);
								bannerIntent.putExtra("imgUrl", imgUrl);
								bannerIntent.putExtra("pathUrl", pathUrl);
								bannerIntent.putExtra("gubun", gubun);
								bannerIntent.putExtra("eventSeq", eventSeq);
							}
						}
					}
					
					String eventKey = pref.getSharedPreference(Const.SP_EVENT_KEY);
					String noticeKey = pref.getSharedPreference(Const.SP_NOTICE_KEY);
					String giftKey = pref.getSharedPreference(Const.SP_GIFT_KEY);
					
					if("Y".equals(rspEvent) && !rspEventKey.equals(eventKey)){
						Const.ISNEW_EVENT = true;
						Const.ISNEW_EVENT_KEY = rspEventKey;
					}
					if("Y".equals(rspHappy))
						Const.ISNEW_HAPPY = true;
					if("Y".equals(rspNotice) && !rspNotice.equals(noticeKey)){
						Const.ISNEW_NOTICE = true;
						Const.ISNEW_NOTICE_KEY = rspNoticeKey;
					}
					if("Y".equals(rspGift) && !rspGiftKey.equals(giftKey)) {
						Const.ISNEW_GIFT = true;
						Const.ISNEW_GIFT_KEY = rspGiftKey;
					}
					
					Const.LATEST_VERSION = rspVersion;
					
					String version = "";
					try 
					{
					    PackageManager packageManager = getPackageManager();
					    PackageInfo info =  packageManager.getPackageInfo(getPackageName(), PackageManager.GET_META_DATA);
					    version = info.versionName;
					 } 
					catch(NameNotFoundException e) 
					{
						e.printStackTrace();
					 }

					try{
						double currentVersion = Double.parseDouble(version);
						double latestVersion = Double.parseDouble(rspVersion);
						
						if(currentVersion < latestVersion){
							Const.ISNEW_VERSION = true;

							if(!(String.valueOf(latestVersion)).equals(pref.getSharedPreference(Const.SP_VERSION_KEY)))
								pref.putSharedPreference(Const.SP_IS_ALERT_VERSION, false);
							
							boolean isAlert = pref.getBooleanSharedPreference(Const.SP_IS_ALERT_VERSION);
							if(!isAlert){
								pref.putSharedPreference(Const.SP_VERSION_KEY, String.valueOf(latestVersion));
								versionParam = "더욱 좋아진 해피포인트 어플리케이션!\n"+latestVersion+" 버전을 지금 업데이트 하시겠습니까?";
							}
						}
					}catch(NumberFormatException e){
						e.printStackTrace();
						Const.ISNEW_VERSION = false;
					}
					
				} catch (ParserConfigurationException e) {
					// TODO Auto-generated catch block
					if(Const.LOG_FLAG){
						Log.d(Const.LOG_TAG, "======= AsyncNewItem ParserConfigurationException ======");
					}
					e.printStackTrace();
				} catch (SAXException e) {
					// TODO Auto-generated catch block
					if(Const.LOG_FLAG){
						Log.d(Const.LOG_TAG, "======= AsyncNewItem SAXException =======");
					}
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					if(Const.LOG_FLAG){
						Log.d(Const.LOG_TAG, "======= AsyncNewItem IOException =======");
					}
					e.printStackTrace();
				} catch (NullPointerException e) {
					if(Const.LOG_FLAG){
						Log.d(Const.LOG_TAG, "======= AsyncNewItem NullPointerException =======");
					}
					e.printStackTrace();
				}
				MenuAdapter.setNewIcon();
				mainPopup();
				
			}
		}
		
		private String getNodeValue(Element rootElem, String xpath){
			String returnVal = "";
			
			try {
				NodeList list = XPathAPI.selectNodeList(rootElem.getFirstChild(), xpath);
				
				if(list!=null){
					returnVal = list.item(0).getTextContent();
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				return "";
			}
			
			return returnVal;
		}
	}
	
	/**
	 * 자동 로그인
	 * @author NOP 201301
	 *
	 */
	private class AutoLogin extends AsyncTask<Void, Void, Boolean>{
		
		@Override
		protected Boolean doInBackground(Void... params) {
			// TODO Auto-generated method stub
			String id = pref.getSharedPreference(Const.SP_ID);
			String pwd = pref.getSharedPreference(Const.SP_PWD);
			String encType = pref.getSharedPreference(Const.SP_ENCTYPE);
			
			int authType = pref.getIntSharedPreference(Const.SP_AUTHTYPE);
			boolean chkAuto = pref.getBooleanSharedPreference(Const.SP_AUTOLOGIN);
			boolean isAuth = false;

			HappyPointSync spcSync = new HappyPointSync(HPCActivity.this);
			
			if(!StringUtils.isEmpty(pwd)){
				try{
					if(!StringUtils.isEmpty(encType) && "AES".equals(encType))
						pwd = SEEDUtil.decryptAES(pwd);
					else
						pwd = SEEDUtil.decrypt(pwd);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();

					pref.putSharedPreference(Const.SP_PWD, "");
					pref.putSharedPreference(Const.SP_ENCTYPE, "");
					return false;
				}
			}
			
			if((Const.TYPE_ACC_ID) == authType){
				if(chkAuto){
					Map<String, String> rsp = null;
					rsp = spcSync.actionLogin(Const.TYPE_ACC_ID, id, pwd, "A");
					String rspCode = rsp.get("rspCode");
					
					isAuth = StringUtils.isEmpty(rspCode)?false:("00".equals(rspCode) || "13".equals(rspCode))?true:false;
				}
			}else{
				String name = pref.getSharedPreference(Const.SP_NAME);
				String idNum = pref.getSharedPreference(Const.SP_IDNUM);
				String ci = pref.getSharedPreference(Const.SP_CI);
				
				if(StringUtils.isEmpty(ci)){
					Map<String,String> rsp = spcSync.actionLogin(Const.TYPE_ACC_NAME, name, idNum, "A"); 
					String rspCode = rsp.get("rspCode");
					isAuth = StringUtils.isEmpty(rspCode)?false:("00".equals(rspCode) || "13".equals(rspCode))?true:false;
					if(isAuth){
						spcSync.setCiByJumin(idNum);
						isAuth = false;
					}
				}else{
					spcSync.actionLogin(Const.TYPE_ACC_NAME_V2, name, ci, "A"); 
				}
				
			}
			return isAuth;
		}

		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			pref.putSharedPreference("isAuth", result);
			
			if(result){
				String cardNo = pref.getSharedPreference(Const.SP_CARDNO);
				 
				// 웹에서 앱 호출후 특정 url로 이동
				if(!StringUtils.isEmpty(Const.ACTION_TYPE)) {
					forwardAction(Const.ACTION_TYPE, Const.ACTION_URL);
				}
				
				if(!StringUtils.isEmpty(cardNo)){
					UserBean user = HappyPointSync.user;
					if(!cardNo.equals(user.getMobileCardNo())){
						if(user!=null && !StringUtils.isEmpty(user.getMobileCardNo())){
							new AsyncSetBarcode().execute(user.getMobileCardNo());
							pref.putSharedPreference(Const.SP_CARDNO, user.getMobileCardNo());
							SmartPushManager mSmartPushManager = SmartPushManager.getInstance();
							mSmartPushManager.setUserMappingKey(mIsetMappingKeyServerInterface, user.getUserNo(), user.getMobileCardNo(), HPCActivity.this);
						}
					}
					pushMapping = pref.getBooleanSharedPreference(Const.SP_PUSH_MAPPYING, false);
					
					// 처음 푸시 등록할때.
					if(!pushMapping) {
						if(user != null) {
							SmartPushManager mSmartPushManager = SmartPushManager.getInstance();
							mSmartPushManager.setUserMappingKey(mIsetMappingKeyServerInterface, user.getUserNo(), user.getMobileCardNo(), HPCActivity.this);
							pref.putSharedPreference(Const.SP_PUSH_MAPPYING, true); 
						}
					}
					
				}
			}/*
			 * else{ // pref.putSharedPreference("isAuth", result); //
			 * HappyPointSync.user = null; }
			 */
		}
	}

	// 서버점검팝업여부
	private class AsyncService extends AsyncTask<Void, Void, String>{
	
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}
		
		protected String doInBackground(Void... params) {
			// TODO Auto-generated method stub
			
			StringBuffer resp = new StringBuffer();
			
			try{
				URI uri = new URI(Const.LINK_SERVICE);
				URL url = uri.toURL();
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				
				con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				con.setDoOutput(true);
				con.setDoInput(true);
				con.setUseCaches(false);
				con.setConnectTimeout(5000);
				con.setRequestMethod("GET");
				
				PrintWriter pwr = new PrintWriter(new OutputStreamWriter(con.getOutputStream(), "utf-8"));
				pwr.flush();
				
				int resCode = 0;
				resCode = con.getResponseCode();
				
				if(resCode < 400){
					String line = "";
					
					BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
					while((line=br.readLine())!=null){
						resp.append(line);
					}
					br.close();
				}else{
					Log.d(Const.LOG_TAG, "데이터를 가져오는데 실패 하였습니다. 오류코드 : "+resCode);
					return "error";
				}
				pwr.close();
				
			}catch(Exception e){
				e.printStackTrace();
				return "error";
			}
			
			return resp.toString().trim();
		}
	
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			if(!StringUtils.isEmpty(result)){
				if("error".equals(result)){
					new AsyncNewItem().execute();
				}else{
					try {
						InputSource is = new InputSource(new StringReader(result));
						
						DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
						DocumentBuilder db = dbf.newDocumentBuilder();
						Document doc = db.parse(is);
						
						// root노드 구하기
						Element root = doc.getDocumentElement();
						String mainNotice = getNodeValue(root, "//channel/mainNotice");
						String bigTitle = getNodeValue(root, "//channel/bigTitle");
						String cont = getNodeValue(root, "//channel/cont");
						
//						mainNotice = "N";
						
						if(!StringUtils.isEmpty(mainNotice) && "Y".equals(mainNotice)) {
							Intent intent = new Intent(HPCActivity.this, NoticeActivity.class);
							intent.putExtra(Const.SP_SERVICE_TITLE, bigTitle);
							intent.putExtra(Const.SP_SERVICE_CONTENT, cont);
							startActivity(intent);
							overridePendingTransition(0, 0);
							finish();
						}else{
							new AsyncNewItem().execute();
						}
					} catch (ParserConfigurationException e) {
						// TODO Auto-generated catch block
						if(Const.LOG_FLAG){
							Log.d(Const.LOG_TAG, "======= AsyncService ParserConfigurationException ======");
						}
						e.printStackTrace();
					} catch (SAXException e) {
						// TODO Auto-generated catch block
						if(Const.LOG_FLAG){
							Log.d(Const.LOG_TAG, "======= AsyncService SAXException =======");
						}
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						if(Const.LOG_FLAG){
							Log.d(Const.LOG_TAG, "======= AsyncService IOException =======");
						}
						e.printStackTrace();
					} catch (NullPointerException e) {
						if(Const.LOG_FLAG){
							Log.d(Const.LOG_TAG, "======= AsyncService NullPointerException =======");
						}
						e.printStackTrace();
					}
				}
			}
		}
	}

private String getNodeValue(Element rootElem, String xpath){
	String returnVal = "";
	
	try {
		NodeList list = XPathAPI.selectNodeList(rootElem.getFirstChild(), xpath);
		
		if(list!=null){
			returnVal = list.item(0).getTextContent();
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		return "";
	}
	
	return returnVal;
}

    /**
     *  setUserMappingKey 요청 결과 정보 수신 Listener 처리
     * */
    private IPushServerInterface mIsetMappingKeyServerInterface = new IPushServerInterface() {
		
		@Override
		public void sendResult(String result, Object obj) {
			if (result.equals(PushErrorCode.RESULT_CODE_200)) {
				// Device Mapping 정보등록 완료
				Log.i("PUSH", "user mapping key 설정에 성공하였습니다.");
			} else {
				// Device Mapping 정보등록 오류
				Log.i("PUSH", "user mapping key 설정을 하지 못했습니다.");
			}
		}
		
		@Override
		public String getResponseResult() {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		public Object getResponseObject() {
			// TODO Auto-generated method stub
			return null;
		}
    };

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		Debug_Log.Log_E(this, "HPCActivity.onResume()");
		super.onResume();
		if(isMain)
			Const.CURRENT_TAB=R.id.menu_card;
		
		// 웹에서 앱 호출시 메뉴이동
		if(!StringUtils.isEmpty(Const.ACTION_TYPE)) {
			if("GIFT".equals(Const.ACTION_TYPE)) {
				Const.CURRENT_TAB = R.id.menu_gift;
			} else if("EVENT".equals(Const.ACTION_TYPE)) {
				Const.CURRENT_TAB = R.id.menu_event;
			} else if("MYMENU".equals(Const.ACTION_TYPE)) {
				Const.CURRENT_TAB = R.id.menu_point;
			} else if("CLUB".equals(Const.ACTION_TYPE)){
				Const.CURRENT_TAB = R.id.menu_happyclub;
			}else if("COUPON".equals(Const.ACTION_TYPE)){
				Const.CURRENT_TAB = R.id.menu_coupon;
			}else if("SETTING".equals(Const.ACTION_TYPE)){
				Const.CURRENT_TAB = R.id.menu_setting;
			}else if("INFO".equals(Const.ACTION_TYPE)){
				Const.CURRENT_TAB = R.id.menu_introduce;
			}else if("INFO".equals(Const.ACTION_TYPE)){
				Const.CURRENT_TAB = R.id.top_btn_prepaid;
			}
//			Const.ACTION_TYPE="";
			clearApplicationCache(null);
		}
		MenuAdapter.setBottomMenu(this, menu);

		// 웹에서 앱 호출후 특정 url로 이동
		boolean isAuth = pref.getBooleanSharedPreference(Const.SP_AUTH);
		boolean isAutoLogin = pref.getBooleanSharedPreference(Const.SP_AUTOLOGIN);
		Debug_Log.Log_E(this, "isAuth : " + isAuth);
		Debug_Log.Log_E(this, "Const.ACTION_TYPE : " + Const.ACTION_TYPE + "   Const.ACTION_URL  : " + Const.ACTION_URL);
		if (!StringUtils.isEmpty(Const.ACTION_TYPE) && !StringUtils.isEmpty(Const.ACTION_URL)) {
			if (HappyPointSync.user == null && !isAutoLogin) {
				Debug_Log.Log_E(this, " 1435 HPCActivity");
				Intent intent = new Intent(HPCActivity.this, LoginActivity.class);
				startActivity(intent);
			} else {
				Debug_Log.Log_E(this, "isAuth -> forwardAction: ");
				forwardAction(Const.ACTION_TYPE, Const.ACTION_URL);
				Const.ACTION_TYPE = null;
				Const.ACTION_URL = null;
			}
		} else {
			MenuAdapter.menuSelected();
		}
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		Debug_Log.Log_E(this, "HPCActivity.onPause()");
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.d("============== ", "HPCActivity.onDestroy()");
		Debug_Log.Log_E(this, "HPCActivity.onDestroy()");
		clearApplicationCache(null);
		if(pref.getBooleanSharedPreference(Const.SP_AUTOLOGIN)== false){
			pref.putSharedPreference(Const.SP_AUTH, false);
			HappyPointSync.user = null;
		}
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (KeyEvent.KEYCODE_BACK == keyCode) {
			if (!isFinish) {
				Toast.makeText(HPCActivity.this, "'뒤로' 버튼을 한번 더 누르시면 종료됩니다.", Toast.LENGTH_SHORT).show();
				isFinish = true;
				new Handler().postDelayed(new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						isFinish = false;
					}
				}, 3000);
			}else{
				finish();
			}
			return false;
		}
		
		return super.onKeyDown(keyCode, event);
	}

	/**
	 * 웹뷰에 케시가 쌓이는것을 앱이 종료할때마다 비우는 함수
	 */
	public void clearApplicationCache(java.io.File dir) {
		if (dir == null) {
			dir = getCacheDir();
		}

		if (dir == null) {
			return;
		}
		java.io.File[] children = dir.listFiles();
		try {
			
			for (int i = 0; i < children.length; i++) {
				if (children[i].isDirectory()) {
					clearApplicationCache(children[i]);
				} else {
					children[i].delete();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 캐릭터 애니메이션 실행
	 * @param resId
	 * @param drawbleId
	 * @param leftDrawbleId
	 * @param offset
	 */
	private void leaderAni(final int resId, final int drawbleId, final int leftDrawbleId, long offset){
		final ImageView happyAni = (ImageView) findViewById(resId);
		
		happyAni.postDelayed(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Animation transAnim = new TranslateAnimation(-20f, -20f, 52f, 32f);
				transAnim.setDuration(500);
				transAnim.setFillAfter(true);
				transAnim.setAnimationListener(new AnimationListener() {
					@Override
					public void onAnimationStart(Animation animation) {
						// TODO Auto-generated method stub
						happyAni.setVisibility(ImageView.VISIBLE);
					}
					@Override
					public void onAnimationRepeat(Animation animation) {
						// TODO Auto-generated method stub
					}
					@Override
					public void onAnimationEnd(Animation animation) {
						// TODO Auto-generated method stub
						happyAni.setImageResource(leftDrawbleId);
						happyAni.postDelayed(new Runnable() {
							@Override
							public void run() {
								// TODO Auto-generated method stub
								happyAni.setImageResource(drawbleId);
								happyAni.postDelayed(new Runnable() {
									@Override
									public void run() {
										// TODO Auto-generated method stub
										Animation transAnim = new TranslateAnimation(-20f, -10f, 32f, -60f);
										transAnim.setDuration(500);
										transAnim.setAnimationListener(new AnimationListener() {
											@Override
											public void onAnimationStart(Animation animation) {
												// TODO Auto-generated method stub
												friendsAni(R.id.ani_green,(int)(Math.random()*700)+300);
												friendsAni(R.id.ani_yellow,(int)(Math.random()*800)+300);
												friendsAni(R.id.ani_red,(int)(Math.random()*600)+400);
											}
											@Override
											public void onAnimationRepeat(Animation animation) {
												// TODO Auto-generated method stub
											}
											@Override
											public void onAnimationEnd(Animation animation) {
												// TODO Auto-generated method stub
												Animation transAnim = new TranslateAnimation(-10f, 0, -60f, 0);
												transAnim.setDuration(300);
												transAnim.setFillAfter(true);
												transAnim.setAnimationListener(new AnimationListener() {
													@Override
													public void onAnimationStart(Animation animation) {
														// TODO Auto-generated method stub
													}
													@Override
													public void onAnimationRepeat(Animation animation) {
														// TODO Auto-generated method stub
													}
													
													@Override
													public void onAnimationEnd(Animation animation) {
														// TODO Auto-generated method stub
														Animation tweenAni = AnimationUtils.loadAnimation(HPCActivity.this, R.anim.tween_rotate);
														tweenAni.setFillAfter(true);
														tweenAni.setDuration((int)(Math.random()*1000)+600);
														tweenAni.setAnimationListener(new AnimationListener() {
															@Override
															public void onAnimationStart(Animation animation) {
																// TODO Auto-generated method stub
															}
															@Override
															public void onAnimationRepeat(Animation animation) {
																// TODO Auto-generated method stub
															}
															@Override
															public void onAnimationEnd(Animation animation) {
																// TODO Auto-generated method stub
																float positionX = 390f;
																if(displayWidth<=480){
																	positionX = 260f;
																}else if(displayWidth<=540){
																	positionX = 300f;
																}else if(displayWidth<=720){
																	positionX = 390f;
																}else if(displayWidth<=800){
																	positionX = 435f;
																}else if(displayWidth<=1080) {
																	positionX = 585f;
																}
																Animation transAnim = new TranslateAnimation(positionX, positionX+10f, 0, -90f);
																transAnim.setDuration(500);
																transAnim.setFillEnabled(false);
																transAnim.setFillAfter(true);
																transAnim.setAnimationListener(new AnimationListener() {
																	@Override
																	public void onAnimationStart(Animation animation) {
																		// TODO Auto-generated method stub
																	}
																	
																	@Override
																	public void onAnimationRepeat(Animation animation) {
																		// TODO Auto-generated method stub
																	}
																	
																	@Override
																	public void onAnimationEnd(Animation animation) {
																		// TODO Auto-generated method stub
																		float positionX = 400f;
																		if(displayWidth<=480){
																			positionX = 270f;
																		}else if(displayWidth<=540){
																			positionX = 310f;
																		}else if(displayWidth<=720){
																			positionX = 400f;
																		}else if(displayWidth<=800){
																			positionX = 445f;
																		}else if(displayWidth<=1080) {
																			positionX = 595f;
																		}
																		Animation transAnim = new TranslateAnimation(positionX, positionX+10f, -90f, 80f);
																		transAnim.setDuration(500);
																		transAnim.setFillAfter(true);
																		transAnim.setAnimationListener(new AnimationListener() {
																			@Override
																			public void onAnimationStart(Animation animation) {
																				// TODO Auto-generated method stub
																			}
																			@Override
																			public void onAnimationRepeat(Animation animation) {
																				// TODO Auto-generated method stub
																			}
																			@Override
																			public void onAnimationEnd(Animation animation) {
																				// TODO Auto-generated method stub
																				happyAni.setVisibility(View.GONE);
																			}
																		});
																		happyAni.startAnimation(transAnim);
																	}
																});
																happyAni.startAnimation(transAnim);
															}
														});
														happyAni.startAnimation(tweenAni);
													}
												});
												happyAni.startAnimation(transAnim);
											}
										});
										happyAni.startAnimation(transAnim);
									}
								}, 300);
							}
						}, 300);
					}
				});
				happyAni.startAnimation(transAnim);
			}
		}, offset);
	}

	private void friendsAni(final int resId, long offset){
		final ImageView friendAni = (ImageView) findViewById(resId);
		
		friendAni.postDelayed(new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Animation transAnim = new TranslateAnimation(-20f, -10f, 52f, -60f);
				transAnim.setDuration(500);
				transAnim.setFillAfter(true);
				transAnim.setAnimationListener(new AnimationListener() {
					@Override
					public void onAnimationStart(Animation animation) {
						// TODO Auto-generated method stub
						friendAni.setVisibility(ImageView.VISIBLE);
					}
					@Override
					public void onAnimationRepeat(Animation animation) {
						// TODO Auto-generated method stub
					}
					@Override
					public void onAnimationEnd(Animation animation) {
						// TODO Auto-generated method stub
						Animation transAnim = new TranslateAnimation(-10f, 0, -60f, 0);
						transAnim.setDuration(300);
						transAnim.setFillEnabled(true);
						transAnim.setFillBefore(true);
						transAnim.setAnimationListener(new AnimationListener() {
							@Override
							public void onAnimationStart(Animation animation) {
								// TODO Auto-generated method stub
							}
							@Override
							public void onAnimationRepeat(Animation animation) {
								// TODO Auto-generated method stub
							}
							
							@Override
							public void onAnimationEnd(Animation animation) {
								// TODO Auto-generated method stub
								Animation tweenAni = AnimationUtils.loadAnimation(HPCActivity.this, R.anim.tween_rotate);
								tweenAni.setFillAfter(true);
								int randomDuration = (int)(Math.random()*1200)+800;
								tweenAni.setDuration(randomDuration);
								tweenAni.setAnimationListener(new AnimationListener() {
									@Override
									public void onAnimationStart(Animation animation) {
										// TODO Auto-generated method stub
									}
									@Override
									public void onAnimationRepeat(Animation animation) {
										// TODO Auto-generated method stub
									}
									@Override
									public void onAnimationEnd(Animation animation) {
										// TODO Auto-generated method stub
										float positionX = 390f;
										if(displayWidth<=480){
											positionX = 260f;
										}else if(displayWidth<=540){
											positionX = 300f;
										}else if(displayWidth<=720){
											positionX = 390f;
										}else if(displayWidth<=800){
											positionX = 435f;
										}else if(displayWidth<=1080) {
											positionX = 585f;
										}
										Animation transAnim = new TranslateAnimation(positionX, positionX+10f, 0, -90f);
										transAnim.setDuration(500);
										transAnim.setFillEnabled(false);
										transAnim.setFillAfter(true);
										transAnim.setAnimationListener(new AnimationListener() {
											@Override
											public void onAnimationStart(Animation animation) {
												// TODO Auto-generated method stub
											}
											
											@Override
											public void onAnimationRepeat(Animation animation) {
												// TODO Auto-generated method stub
											}
											
											@Override
											public void onAnimationEnd(Animation animation) {
												// TODO Auto-generated method stub
												float positionX = 400f;
												if(displayWidth<=480){
													positionX = 270f;
												}else if(displayWidth<=540){
													positionX = 310f;
												}else if(displayWidth<=720){
													positionX = 400f;
												}else if(displayWidth<=800){
													positionX = 445f;
												}else if(displayWidth<=1080) {
													positionX = 595f;
												}
												Animation transAnim = new TranslateAnimation(positionX, positionX+10f, -90f, 80f);
												transAnim.setDuration(500);
												transAnim.setFillAfter(true);
												transAnim.setAnimationListener(new AnimationListener() {
													@Override
													public void onAnimationStart(Animation animation) {
														// TODO Auto-generated method stub
													}
													@Override
													public void onAnimationRepeat(Animation animation) {
														// TODO Auto-generated method stub
													}
													@Override
													public void onAnimationEnd(Animation animation) {
														// TODO Auto-generated method stub
														friendAni.setVisibility(View.GONE);
													}
												});
												friendAni.startAnimation(transAnim);
											}
										});
										friendAni.startAnimation(transAnim);
									}
								});
								friendAni.startAnimation(tweenAni);
							}
						});
						friendAni.startAnimation(transAnim);
					}
				});
				friendAni.startAnimation(transAnim);
			}
		}, offset);
	}
	
//	// 설치된 다른 어플 실행 시키기
//	private void runOtherProcess(){
//		String packageName = "com.hpapp";
//		List<PackageInfo> appinfo = getPackageManager().getInstalledPackages(PackageManager.GET_ACTIVITIES);
//		for(PackageInfo app:appinfo){
//			if(StringUtils.isEquals(packageName, app.packageName)){
//				Intent intent = this.getPackageManager().getLaunchIntentForPackage(packageName);
//				startActivity(intent);
//			}
//		}
//	}

	public void forwardAction(final String actionType, final String actionUrl) {
		int menuId = 0;
		Debug_Log.Log_E(this, "forwardAction().actionType : " + actionType);
		Debug_Log.Log_E(this, "forwardAction().actionUrl : " + actionUrl);

		if ("MYMENU".equals(actionType)) {
			menuId = Const.MENU_ID_POINT;
		} else if ("EVENT".equals(actionType)) {
			menuId = Const.MENU_ID_EVENT;
		} else if ("GIFT".equals(actionType)) {
			menuId = Const.MENU_ID_GIFT;
		} else if ("CLUB".equals(actionType)) {
			menuId = Const.MENU_ID_CLUB;
		} else if ("COUPON".equals(actionType)) {
			menuId = Const.MENU_ID_COUPON;
		} else if ("SETTING".equals(actionType)) {
			menuId = Const.MENU_ID_SETTING;
		} else if ("INFO".equals(actionType)) {
			menuId = Const.MENU_ID_INFO;
		} else if ("DUNKIN".equals(actionType)) {
			menuId = Const.MENU_ID_DUNKIN;
		}
		MenuAdapter.performClick(menuId, actionUrl);
		Const.ACTION_TYPE = "";
	}

	/**
	* 읽음처리 요청에 대한  callback
	*/
	private IPushServerInterface mIsendReadserverInterface = new IPushServerInterface() {
		@Override
		public String getResponseResult() {return null;}
		@Override
		public Object getResponseObject() {return null;}
		@Override
		public void sendResult(String result, Object obj) {
			if(result.equals(PushErrorCode.RESULT_CODE_200)){
			// 요청 성공 경우
				Log.i("INFO", "push 읽음 처리 성공");
				Log.i("INFO", "result = " + result);
			}else{
			// 실패 처리 입니다.
				Log.i("INFO", "push 읽음 처리 실패");
				Log.i("INFO", "result = " + result);
			}
		}
	};
	
}
