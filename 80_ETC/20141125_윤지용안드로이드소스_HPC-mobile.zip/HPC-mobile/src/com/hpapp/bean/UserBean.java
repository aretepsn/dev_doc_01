package com.hpapp.bean;

public class UserBean {

	// 로그인타입 (ID/PWD:0, 이름/주민번호:1)
	private int accessType;
	
	// 사용자 ID
	private String userId;
	
	// 사용자 비밀번호
	private String userPwd;
	
	// 사용자 이름
	private String userName;
	
	// 주민번호
	private String idNumber;
	
	// 사용자인증 CI 코드 (v2.추가, 주민등록번호 대체)
	private String ci;
	
	// 회원구분 코드 (CY:카드정회원, MI:아이핀인증 준회원, MS:실명인증 준회원)
	private String grade;
	
	// 회원 구분 명
	private String gradeName;
	
	// 정상 카드번호 배열값
	private String[] cardsNo;

	// 모바일 카드번호
	private String mobileCardNo;
	
	// 회원번호
	private String userNo;
	
	// 회원 등급
	private String userCl;
	
	// 회원 등급명
	private String userClName;
	
	// 회원 등급안내 (v2. 추가)
	private String userClMent;
	
	// 회원 폰번호
	private String phoneNumber;

	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getGradeName() {
		return gradeName;
	}

	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}

	public String[] getCardsNo() {
		return cardsNo;
	}

	public void setCardsNo(String[] cardsNo) {
		this.cardsNo = cardsNo;
	}

	public String getUserNo() {
		return userNo;
	}

	public void setUserNo(String userNo) {
		this.userNo = userNo;
	}

	public String getUserCl() {
		return userCl;
	}

	public void setUserCl(String userCl) {
		this.userCl = userCl;
	}

	public String getUserClName() {
		return userClName;
	}

	public void setUserClName(String userClName) {
		this.userClName = userClName;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public int getAccessType() {
		return accessType;
	}

	public void setAccessType(int accessType) {
		this.accessType = accessType;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getMobileCardNo() {
		return mobileCardNo;
	}

	public void setMobileCardNo(String mobileCardNo) {
		this.mobileCardNo = mobileCardNo;
	}

	public String getCi() {
		return ci;
	}

	public void setCi(String ci) {
		this.ci = ci;
	}

	public String getUserClMent() {
		return userClMent;
	}

	public void setUserClMent(String userClMent) {
		this.userClMent = userClMent;
	}


}
