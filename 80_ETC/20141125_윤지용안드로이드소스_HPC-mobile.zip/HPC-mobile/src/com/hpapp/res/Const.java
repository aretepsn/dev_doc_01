package com.hpapp.res;

import android.widget.ImageButton;

import com.hpapp.R;
import com.hpapp.util.StringUtils;

public class Const {
	
	public static final boolean IS_DEV = false;

	// GCM SENDER ID
	public static final String GCM_SENDER_ID = "723914048543";
	// 140127 Test
//	public static final String GCM_SENDER_ID = "1037355089317";
	// GCM server api-key
//	public static final String SIMPLE_API_KEY = "AIzaSyAbnJwSt7nHhLD_cJt8eKo8mLwWYFIHRAM";
	// Test
	public static final String SIMPLE_API_KEY = "yuQwDg+tRkVMOidGfzYLfaOERt0=";
	// 140127 Test
//	public static final String SIMPLE_API_KEY = "AIzaSyBelVOmS9VZN0LeB5CPWlVrLpJi_G-RB68";

	public static final boolean LOG_FLAG = false;
	public static final String LOG_TAG = "HPC-mobile";
	
	// 플레이스토어 어플 링크
	public static final String LINK_MARKET = "market://details?id=com.hpapp";
	// 티스토어 어플 링크
//	public static final String LINK_MARKET = "http://m.tstore.co.kr/userpoc/mp.jsp?pid=0000253525";
	
	/* start sharedPreference key */
	public static final String SP_KEY = "SPC-mobile";
	public static final String SP_GCM = "GCM_Active";
	public static final String SP_GCM_REGID = "registration_id";
	public static final String SP_CARDNO = "mobileCardNo";
	public static final String SP_CLASS = "class";
	public static final String SP_AUTH = "isAuth";
	public static final String SP_AUTHTYPE = "authType";
	public static final String SP_ID = "id";
	public static final String SP_PWD = "pwd";
	public static final String SP_ENCTYPE = "encType";	// AES, BASE64
	public static final String SP_NAME = "name";
	public static final String SP_IDNUM = "idNumber";
	public static final String SP_CI = "CI";
	public static final String SP_AUTOLOGIN = "autoLogin";
	public static final String SP_GPS_ALLOW = "allowMyLocation";
	public static final String SP_EVENT_KEY = "event_key";
	public static final String SP_NOTICE_KEY = "notice_key";
	public static final String SP_FIRST_UPDATE = "firstUpdate";
	public static final String SP_VERSION_KEY = "version_key";
	public static final String SP_IS_ALERT_VERSION = "isAlertVersion";
	public static final String SP_BANNER_KEY = "banner_key";
	public static final String SP_BANNER_EXPIRE = "banner_expire";
	public static final String SP_IS_ALERT_BANNER = "isAlertBanner";
	public static final String SP_NEVER_SHOW_TUTORIAL = "neverShowTutorial";
	public static final String SP_GIFT_KEY = "gift_key";
	public static final String SP_PUSH_MAPPYING = "pushMapping";
	// 추천인팝업 처리 여부
	public static final String SP_RECOMMEND = "recommendYn";
	// 추천인팝업 이력 여부 (앱 설치후 1번만 실행시키기 위한 설정값)
	public static final String SP_RECOMMEND_POPUP = "recommendPopup";
	public static final String SP_RECOMMEND_TITLE = "recommendTitle";
	public static final String SP_RECOMMEND_CONTENT = "recommendContent";
	public static final String SP_HPCNO = "hpcNo";
	public static final String SP_MAINPOPUP = "mainPopup";
	public static final String SP_SERVICE_TITLE = "serviceTitle";
	public static final String SP_SERVICE_CONTENT = "serviceContent";
	/* end of sharedPreference key */
	
	// map distance
	public static float MAP_DISTANCE = 1000f;
	
	public static boolean ISNEW_EVENT;
	public static String ISNEW_EVENT_KEY;
	public static boolean ISNEW_NOTICE;
	public static String ISNEW_NOTICE_KEY;
	public static boolean ISNEW_HAPPY;
	public static boolean ISNEW_VERSION;
	public static boolean ISNEW_GIFT;
	public static String ISNEW_GIFT_KEY;
	public static String LATEST_VERSION;
	
	// requestCode for login
	public static int REQ_LOGIN_POPUP = 0x1100;
	public static int REQ_LOGIN_STAMP = REQ_LOGIN_POPUP + 1;
	public static int REQ_LOGIN_SUBMENU = REQ_LOGIN_STAMP + 1;
	public static int REQ_PICK_CONTACT = REQ_LOGIN_SUBMENU + 1;
	public static int REQ_GIFT_PAYMENT = REQ_PICK_CONTACT + 1;
	public static int REQ_LOGIN_PUSH = REQ_GIFT_PAYMENT + 1;
	public static int REQ_LOGIN_INTRO = REQ_LOGIN_PUSH + 1;
	public static int REQ_LOGIN_RECOMMEND = REQ_LOGIN_INTRO + 1;
	
	public static int CURRENT_TAB;
	
	public static ImageButton menuCard, menuPoint, menuEvent, menuGift, menuMore, menuClub, menuCoupon, menuInfo, menuSetting;
	public static int MENU_ID_CARD = 0x2100;
	public static int MENU_ID_POINT = MENU_ID_CARD + 1;
	public static int MENU_ID_EVENT = MENU_ID_POINT + 1;
	public static int MENU_ID_GIFT = MENU_ID_EVENT + 1;
	public static int MENU_ID_CLUB = MENU_ID_GIFT + 1;
	public static int MENU_ID_COUPON = MENU_ID_CLUB + 1;
	public static int MENU_ID_INFO = MENU_ID_COUPON + 1;
	public static int MENU_ID_SETTING = MENU_ID_INFO + 1;
	public static int MENU_ID_DUNKIN = MENU_ID_SETTING + 1;
	
	// input
	public static String ACTION_TYPE;
	public static String ACTION_URL;
	
	
	public static int[] CARD_IDS = {R.drawable.main_img_card,R.drawable.main_img_vipcard, R.drawable.main_img_kidcard_a, R.drawable.main_img_kidcard_b, R.drawable.main_img_kidcard_c, R.drawable.main_img_kidcard_d};
	
	//등급별 카드 이미지 가져오기
	public static int CARD_RESID(String memberClass){
		int classLevel = 0;
		if(!StringUtils.isEmpty(memberClass)){
			if("P0".equals(memberClass))
				classLevel = 0;
			else if("H0".equals(memberClass))
				classLevel = 1;
			else if("K1".equals(memberClass))
				classLevel = 2;
			else if("K2".equals(memberClass))
				classLevel = 3;
			else if("K3".equals(memberClass))
				classLevel = 4;
			else if("K4".equals(memberClass))
				classLevel = 5;
		}
		return CARD_IDS[classLevel];
	}
	// 해피포인트 운영서버 IP
//	public static final String HOST_URL_SPC = "http://110.45.199.242";
//	public static final String HOST_URL_SPC = "https://api.happypointcard.com";
	public static final String HOST_URL_SPC = IS_DEV?"http://115.144.168.14:1208":"https://api.happypointcard.com";
	public static final String HOST_HTTP_URL_SPC = IS_DEV?"http://115.144.168.14:1208":"http://api.happypointcard.com";
	public static final String HOST_URL_WEBVI = "https://www.happypointcard.com";
	public static final String HOST_URL_HAPPYCON = IS_DEV?"http://thappypoint.multicon.co.kr":"https://happypoint.multicon.co.kr";
	public static final String HOST_URL_DUNKIN = IS_DEV? "http://devgiftm.multicon.co.kr":"https://gift.multicon.co.kr";
	public static final String HOST_URL_DANAL_PAGE =  "https://pggw.kcp.co.kr/app.do?ActionResult=app";
	
	// 개발 서버 IP
//	public static final String HOST_URL_SPC = "http://115.144.168.14";
//	public static final String HOST_URL_WEBVI = "http://test.happypointcard.com";
//	public static final String HOST_URL_HAPPYCON = "http://thappypoint.multicon.co.kr";

	// 요청 타입 : 아이디/비밀번호
	public static final int TYPE_ACC_ID = 0;
	// 요청 타입 : 이름/주민번호
	public static final int TYPE_ACC_NAME = 1;
	// 요청 타입 : 이름/CI
	public static final int TYPE_ACC_NAME_V2 = 2;
	
//	// 카드회원 체크 결과값 및 정상 카드번호출력 (아이디/비밀번호)
//	public static final String URI_LOGIN_ID = "https://www.happypointcard.com/HPC_APP/mobile_member_check_cardinfo.jsp";
//	// 카드회원 체크 결과값 및 정상 카드번호출력 (이름/주민번호)
	public static final String URI_LOGIN_NAME = HOST_URL_WEBVI+"/HPC_APP/mobile_member_check_cardinfo_nreg.jsp";
//	// 총포인트 (아이디/비밀번호)
//	public static final String URI_POINTSUM_ID = "https://www.happypointcard.com/HPC_APP/mobile_card_pointsum.jsp";
//	// 총포인트 (이름/주민번호)
//	public static final String URI_POINTSUM_NAME = HOST_URL_WEBVI+"/HPC_APP/mobile_card_pointsum_nreg.jsp";
//	
//	// 카드회원 체크 결과값 및 정상 카드번호출력 (아이디/비밀번호)
	public static final String URI_LOGIN_ID_V2 = HOST_URL_WEBVI+"/HPC_APP/mobile_member_check_cardinfo_v2.jsp";
//	public static final String URI_LOGIN_ID_V3 = HOST_URL_SPC+"/front_v2/login/cardInfo.asp";
//	public static final String URI_LOGIN_ID_V3 = HOST_URL_SPC+"/front_v2/login/cardInfo_v2.asp";
	public static final String URI_LOGIN_ID_V3 = HOST_URL_SPC+"/front_v2/login_v2/cardInfo_v2.asp";
//	public static final String URI_LOGIN_ID_V3 = HOST_URL_SPC+"/front_v2/login_v3/cardInfo_v2.asp";
//	// 카드회원 체크 결과값 및 정상 카드번호출력 (이름/CI)
	public static final String URI_LOGIN_NAME_V2 = HOST_URL_WEBVI+"/HPC_APP/mobile_member_check_cardinfo_nreg_v2.jsp";
//	// 총포인트 (아이디/비밀번호)
//	public static final String URI_POINTSUM_ID_V2 = HOST_URL_WEBVI+"/HPC_APP/mobile_card_pointsum_v2.jsp";
//	// 총포인트 (이름/주민번호)
//	public static final String URI_POINTSUM_NAME_V2 = HOST_URL_WEBVI+"/HPC_APP/mobile_card_pointsum_nreg_v2.jsp";
//	// CI 가져오기 (주민번호 사용자) W_JUMIN, W_PATH
	public static final String URI_CI_JUMIN = HOST_URL_WEBVI+"/HPC_APP/mobile_member_ipin_info_v2.jsp";

	// 메인 한줄 공지사항
//	public static final String LINK_LINENOTICE = HOST_URL_SPC+"/front_v2/help/appNotice.asp";
	// 이름/CI로 카드발급(현재사용안함)
	public static final String LINK_AUTH_CI = HOST_URL_SPC;//+"/front_v2/login_v2/authCheck.asp";
	// 아이디/비밀번호 카드발급
//	public static final String LINK_AUTH_ID = HOST_URL_SPC+"/front_v2/mymenu/info.asp";
//	public static final String LINK_AUTH_ID = HOST_URL_SPC+"/front_v2/login/cardInfo.asp";
//	public static final String LINK_AUTH_ID = HOST_URL_SPC+"/front_v2/login/cardInfo_v2.asp";
//	public static final String LINK_AUTH_ID = HOST_URL_SPC+"/front_v2/login_v2/cardInfo_v2.asp";
//	public static final String LINK_AUTH_ID = HOST_URL_SPC+"/front_v2/login_v3/cardInfo_v2.asp";
	// 아이디/ 패스워드 찾기
	public static final String LINK_FIND_IDPW = "https://members.happypointcard.com/member_mobile/id_search.asp";
	// 모바일 서비스안내
	public static final String LINK_SERVICE_INFO = HOST_URL_SPC+"/front_v2/help/guide.asp";
	// 회원가입
	public static final String LINK_SIGNUP = HOST_URL_SPC+"/front_v2/member/join01.asp";
//	public static final String LINK_SIGNUP = HOST_URL_SPC+"/front_v2/member_v2/join01.asp";
	// 나의 포인트조회
//	public static final String LINK_MY_POINT = HOST_URL_SPC+"/front_v2/mymenu/list.asp";
	public static final String LINK_MY_POINT = HOST_URL_SPC+"/front_v2/mymenu/list_v2.asp";
//	public static final String LINK_MY_POINT = HOST_URL_SPC+"/front_v2/mymenu_v2/list_v2.asp";
	// 나의카드 등록/변경
//	public static final String LINK_MY_CARD = HOST_URL_SPC+"/front/contents/mymenu/cardRegister.asp";
	// facebook
	public static final String LINK_FACEBOOK = "http://www.facebook.com/happypointcard";
	// tistory
//	public static final String LINK_TISTORY = "http://happygirl12.tistory.com";
	public static final String LINK_TISTORY = "http://blog.naver.com/happypoints";
	// 이벤트
	public static final String LINK_EVENT = HOST_URL_SPC+"/front_v2/event/eventList_v2.asp";
	public static final String LINK_EVENT_LIST = HOST_URL_SPC+"/front_v2/event/eventList_v2.asp";
	public static final String LINK_EVENT_VIEW = HOST_URL_SPC + "/front_v2/event/eventView.asp"; //해당이벤트
	// 선물하기
//	public static final String LINK_GIFT = HOST_URL_SPC+"/front_v2/gift/giftList.asp";
	public static final String LINK_MYCOUPON = HOST_URL_SPC + "/front_v2/mymenu/coupon.asp";
	public static final String LINK_HAPPYVIRUS = HOST_URL_SPC + "/front_v2/mymenu/invite.asp";
	public static final String LINK_POINTCHECK = HOST_URL_SPC + "/front_v2/mymenu/point.asp";
	public static final String LINK_GIFT = HOST_URL_HAPPYCON + "";
	public static final String LINK_DUNKIN = HOST_URL_DUNKIN + "";
	// 결제창
	public static final String LINK_PAYMENT = HOST_URL_SPC+"/front_v2/gift/giftPay.asp";
	// 스탬프
	public static final String LINK_STAMP = HOST_URL_SPC+"/front_v2/coupon/stampList.asp";
	// 해피클럽
	public static final String LINK_HAPPYCLUB = HOST_URL_SPC+"/front_v2/happyClub/happyFamily.asp";
	// 해피 랭킹
	public static final String LINK_HAPPYRANK = HOST_URL_SPC+"/front_v2/happyClub/happyRanking.asp";
	// 쿠폰
	public static final String LINK_COUPON = HOST_URL_SPC+"/front_v2/coupon/couponList.asp";
	// 안내
	public static final String LINK_INFO = HOST_URL_SPC+"/front_v2/help/notice.asp";
	// SPC 브랜드
	public static final String LINK_SPCBRAND = HOST_URL_SPC+"/front_v2/help/brandViewAPP.asp";
	// HPC 파트너
	public static final String LINK_HPCPARTNER = HOST_URL_SPC+"/front_v2/help/partnerList.asp";
	// 최신버전정보
	public static final String LINK_LATESTVER = HOST_URL_SPC+"/front_v2/help/appVersion.asp";
	// HPC 모바일 홈
	public static final String LINK_HPC_MOBILE = "http://m.happypointcard.com";
	
	// push 등록
	public static final String LINK_PUSH_REGIST = HOST_URL_SPC+"/front_v2/push/push.asp";
//	public static final String LINK_PUSH_REGIST = "http://61.106.50.27:8080/push/push_regist.jsp";
	// push 삭제
	public static final String LINK_PUSH_REMOVE = HOST_URL_SPC+"/front_v2/push/pushRemove.asp";
//	public static final String LINK_PUSH_REMOVE = "http://61.106.50.27:8080/push/push_remove.jsp";
//	 신규아이템 여부 가져오기
//	public static final String URI_NEW_ITEMS = HOST_URL_SPC+"/front_v2/xml/newIcon_V2.asp";
	public static final String URI_NEW_ITEMS = HOST_URL_SPC+"/front_v2/xml/newIcon_V3.asp";
	// 튜토리얼
	public static final String LINK_TUTORIAL = HOST_URL_SPC+"/front_v2/help/tutorial.asp";
	
	// SNS이벤트 테스트
	public static final String LINK_TEST_SNS = "http://115.144.168.14/front_v2/event/snsEvent.asp";
	// 추천인
//	public static final String LINK_RECOMMEND = HOST_URL_SPC + "/front_v2/clerk/recommendInsert.asp";
	public static final String LINK_RECOMMEND = HOST_URL_SPC + "/front_v2/clerk/recommendInsert_v2.asp";
	// 인카드쿠폰 요청
	public static final String LINK_RECOMMEND_CARD = HOST_URL_SPC + "/front_v2/clerk/getIncard.asp";
	
	// 서비스점검안내
	public static final String LINK_SERVICE = HOST_URL_SPC + "/front_v2/xml/mainNotice.asp";
	
	
}
