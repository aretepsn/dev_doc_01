package com.hpapp.res;

import android.graphics.Color;

public final class CMR {
	
		public static final class control {
			public static final int gallery_fling=100;
			public static final int gallery_fling_select=101;
			public static final int gallery_fling2=102;
		}
		
		public static final class view {
			public static int m_cur_card_issue_num=0;
			public static int m_cur_happycon_view_page=0;
			public static int card_issue1=100;//카드등록 초기 메인화면
	    	public static int card_sub2_select_reg=100;
			public static int card_sub1_select_issue=100;//카드등록 초기 메인화면
	    	public static int card_sub2_user_guide=100;//
	    	public static int hp_card_sub3_step1_verify_name=100;//
	    	public static int hp_card_sub3_step1_1_verify_userself=100;//
	    	public static int hp_card_sub3_step1_verify_login=100;//
	    	public static int hp_card_sub3_step2_confirm_aggree=100;//
	    	public static int hp_card_sub3_step3_confirm_phone=100;//
	    	public static int card_sub4_step1_select_card=100;//
	    	public static int card_user_guide=100;
	    	public static int card_issue_reg1=100;
	    	public static int card_issue_reg1_a1=100;
	    	public static int card_issue_reg1_b1=100;
	    	public static int card_issue_reg1_b2_address_phone=100;
	    	public static int card_issue_zip_address=100;
	    	public static int hp_card_pship=100;
	    	public static int hp_card_pship_detail=100;
	    	public static int hp_card_point_main=100;
	    	public static int hp_card_point1=100;
	    	public static int hp_card_point2=100;
	    	public static int home_sub1=-1;
	    	public static int home_sub2=-1;
	    	public static int home_sub3=-1;
	    	public static int happycon_main_tab1=100;//happycon main
	    	public static int happycon_brand_tab=100;
	    	public static int happycon_main_tab2=100;//인기순,가격순,
	    	public static int happycon_main_tab3_myinfo=100;//내정보
	    	public static int happycon_product_main=-1;//상품자세히 보기 첫화면
	    	public static int happycon_gift_setp1_confirm=-1;//상품선물하기 첫화면
	    	public static int happycon_gift_setp2_authname=-1;//
	    	public static int happycon_gift_setp3_authphone=-1;//
	    	public static int happycon_gift_step3_auth_phone_aggreement=-1;//
	    	public static int happycon_gift_setp4_sendmessage=-1;//
	    	public static int happycon_gift_setp5_paymente=-1;//
	    	public static int happycon_myinfo2_coupon_detail=-1;//
	    	public static int happycon_user_guide=-1;//
	    	public static int map_shop_detail_view=-1;//
	    	public static int map_shop_brand_selector_view=2;//
	    	public static int map_shop_finder=1;//
	    	public static int hlep_main1=-1;//
	    	public static int hlep_main2=-1;//
	    	public static int help_main1_sub1_card=-1;//
	    	public static int help_main1_sub5_version=-1;//
	    	public static int help_main1_sub2_notice=-1;//
	    	public static int help_main1_sub2_notice_detail=-1;//
	    	public static int help_main1_sub4_auto_auth=-1;//
	    	public static int help_main2_sub1_guide_mobile=-1;//
	    	public static int hpapp_passowrd_config=-1;//
	    	public static int hpapp_passowrd_change=-1;//
	    	public static int hpapp_passowrd_change_confirm=-1;//
	    	public static int hpapp_passowrd_verify=-1;//
		}
		
		public static final class id {
		    	public static final int btn_yes=0;
		    	public static final int btn_no=1;
		    	public static final int text_selector_character=2;
		    	public static final int text_bye_text=3;
		    	public static final int edittext_buy=4;
		    	public static final int item_is_click=100;
		    	public static final int group_item_is_click=101;
		    	public static final int card_make_own_card=200;
		    	public static final int fail_to_init_app=201;
		    }
		
		public static class color{
    		public static final int white = Color.rgb(255, 255, 255);
    		public static final int light_blue2 = Color.rgb(133, 219, 255);
    		public static final int dark_blue = Color.rgb(66, 138, 169);
    		public static final int dark_grey = Color.rgb(107, 109, 110);
    		public static final int light_grey = Color.rgb(175, 180, 182);
    		public static final int light_black = Color.rgb(90, 91, 92);
    		public static final int list_back 	= Color.rgb(255, 255, 255);
    		public static final int list_title 	= Color.rgb(46, 151, 197);
    		public static final int list_title_date = Color.rgb(136, 136, 136);
    		public static final int list_grey = Color.rgb(136, 136, 136);
    		public static final int list_light_blue = Color.rgb(46, 151, 197);
    		public static final int title_sub = Color.rgb(56, 78, 137);
    		public static final int month_sun = Color.rgb(184, 73, 73);
    		public static final int month_sat = Color.rgb(70, 126, 170);
    		public static final int month_nor_day = Color.rgb(79, 82, 84);
    		public static final int month_today = Color.rgb(0, 0, 0);
    		public static final int month_next_month_day = Color.rgb(166, 170, 173);
    		public static final int comm_list_low_text1 = Color.rgb(175, 180, 182);
    		public static final int comm_list_low_text2 = Color.rgb(58, 107, 135);
    		public static final int comm_list_low_text3 = Color.rgb(110, 110, 110);
    		public static final int comm_list_low_text4 = Color.rgb(58, 170, 135);
    	 	public static final int a_yellow = Color.rgb(215,70,20);
	    	public static final int b_yellow = Color.rgb(255, 165, 40);
	    	public static final int b_white = Color.rgb(210, 210, 210);
	    	public static final int b_black = Color.rgb(0, 0, 0);
	    	public static final int list_title2 = Color.rgb(44,58,108);
	    	public static final int list_title3 = Color.rgb(79,79,79);
	    	public static final int list_title4 = Color.rgb(218,103,135);
	    	public static final int event_list_title2 = Color.rgb(54,67,116);
	    	public static final int event_list_title3 = Color.rgb(79,79,79);
	    	public static final int event_list_title4 = Color.rgb(218,103,135);
	    	public static final int list_title_selected = Color.rgb(255,255,255);
    	}
    	
    	public static class size{
    		public static final int title = 20;
    		public static final int title_sub = 22;
    		public static final int month_day = 22;
    		public static final int list_low = 14;
    		public static final int list_title = 20;
    		public static final int list_sub_title = 22;
       		public static final int comm_list_low1_20 = 16;
       	 	public static final int comm_list_low2_16 = 14;
       	 	public static final int main_title = 70;
    	}
    	
    	
    	public static final class event{
    		public static final int app_exit = 10;
    		public static final int ok = 11;
    		public static final int cancel = 12;
			public static final int happycon_detail_view = 100;
			public static final int happycon_gift_main_view = 101;
			public static final int happycon_go_user_reg = 102;
			public static final int happycon_send_gift = 103;
			public static final int happycon_gift_cancel = 104;
			public static final int happycon_auth_phone = 105;
			public static final int happycon_show_auth = 106;
			public static final int payment_process_error = 200;
			public static final int payment_process_success = 201;
			public static final int payment_process_cancel = 202;
			public static final int map_notify_goto_shop = 300;
			public static final int map_request_search = 301;
			public static final int map_end_update_shop = 302;
			public static final int map_notifiy_mydesc_selected = 303;
			public static final int map_notifiy_mydesc_unselected = 304;
			public static final int map_notifiy_shop_selected = 305;
			public static final int map_notifiy_shop_find_ok = 306;
			public static final int map_notifiy_go_back = 307;
			public static final int map_notifiy_completed_distance = 308;
			public static final int map_notify_update_list = 309;
			public static final int help_auto_auth_completed = 350;
			public static final int help_question_no_card = 351;
			public static final int card_view_totoal_point = 400;
			public static final int card_selected_zipcode = 401;
			public static final int card_load_barcode = 402;
			public static final int card_make_card = 403;
			public static final int home_go_to_main = 500;
			public static final int home_get_event_list_completed = 501;
			public static final int home_go_to_main_first = 502;
			public static final int home_change_bottom_gallery_item = 503;
			public static final int home_go_to_main_card_reg_selection = 504;
			public static final int passowrd_config_on = 600;
			public static final int passowrd_config_off = 601;
			public static final int passowrd_confirm_ok = 602;
			public static final int passowrd_retry = 603;
			public static final int passowrd_retry_first = 604;
			public static final int passowrd_show_keyboard = 605;
			public static final int file_down_ok = 700;
			public static final int file_down_fail = 701;
			public static final int file_down_cancel = 702;
	     	public static final int REQUEST_SEARCH_ZIP=1000;
	     	public static final int REQUEST_HAPPY_DEL_COUPON=1001;
	     	public static final int REQUEST_SEARCH_CARD_POINT=1002;
	     	public static final int REQUEST_SEARCH_CARD_IMAGE=1003;
	     	public static final int REQUEST_PAYMENT=1004;
	     	public static final int REQUEST_SHOP_DETAIL=1005;
		}



//    	 public static final class board_cd {
// 	    	
// 	    	public static final String sche = "10131013";
// 	    	public static final String edu_one = "10131003";
// 	    }
    	 
    	 
    	  public static class CErrCode{
  	    	public int mIntErr;
  	    	public String mSringErr;
  	    	public int index;
  	    	
  	    	public CErrCode(int errcode, String errmsg, int idx){
  	    		mIntErr 	= errcode;
  	    		mSringErr	= errmsg;
  	    		index  = idx;
  	    	}
  	    }
    
    	public static final class errcode {
			static int  index =1000;
			
			
			public static final CErrCode mOpCodes[]={
			};
			
		
		}
    	
    	public static final class err {
    		
    		public static final String fail_login_invalid_user="해피포인트 회원이 아닙니다.";
    		public static final String fail_login_internal_aspn_error="회원 로그인에 실패하였습니다. ASPN 서비스 시스템에러입니다.";
    		public static final String fail_login_internal_other_error="회원 로그인에 실패하였습니다.";

    		public static final String fail_to_get_data_result="데이타 처리하는데 실패하였습니다.";
    		public static final String fail_to_get_result="데이타 수신에 실패하였습니다.";
    		public static final String fail_to_get_result_invalid_server_data="데이타 수신에 실패하였습니다.수신된 정보가 올바르지 않습니다.";
    		public static final String fail_to_search="조회된 결과가 없습니다.";
    		public static final String fail_to_no_date="등록된 데이타가 없습니다.";
    		public static final String invalid_send_param="데이타 전송에 실패하였습니다.";
    		public static final String invalid_search_word="검색할 단어를 정확히 입력후 다시 시도하여 주십시요.";
    		public static final String contents_is_empty="내용이  존재하지 않습니다. 정확히 입력후 다시 시도하여 주십시요.";
    		
    		
    		public static final String invalid_login_id="아이디를 올바르게 입력한후 다시 시도하여 주십시요.";
    		public static final String invalid_login_password="비밀번호를 올바르게 입력한후 다시 시도하여 주십시요.";
    		public static final String invalid_login_id_pass="아이디/비밀번호를 올바르게 입력한후 다시 시도하여 주십시요.";
    		
    		public static final String user_is_not_exist="존재하지 않는 사용자 아이디 입니다.";
    		public static final String user_is_invalid_password="패스워드가 일치하지 않습니다.";
    		public static final String user_device_is_not_exist="등록되지 않은 장치 입니다.";
    		public static final String user_device_is_invlaid="사용자와  장치아이디가 일치하지 않습니다. 재등록후 사용하시기 바랍니다.";
    		
    	   	public static final String err_fail_to_connect_sdcard ="외장메모리(SDCARD)를 연결할수 없습니다. 확인후 다시 시도하여 주십시요.";
    	   	public static final String user_device_is_empty="폰번호가 존재하지 않습니다. 통신사 가입 확인후 다시 시도하여 주십시요.";
    	   	

    	   	public static final String user_fail_to_auth_self="본인인증에 실패하였습니다.";
    		public static final String user_fail_to_issue_code="인증코드 발급에 실패하였습니다.";
    		
    		public static final String card_fail_to_own_card_reg="모바일 카드등록에 실패하였습니다.";
    		public static final String card_empty_card_reg="등록된 해피포인트 카드가 없습니다.등록하시겠습니까?";
    		public static final String card_empty_popup_card_reg="이용중인 해피포인트 카드가 없습니다. 해피포인트 카드를 만드시겠습니까?";
    		
    		public static final String user_fail_to_user_reg="회원가입에 실패하였습니다.";

    		public static final String payment_0101="미등록 payId 입니다.";
    		public static final String payment_0102="구매자 휴대전화번호 형식이 맞지 않습니다.(길이)";
    		public static final String payment_0103="구매자 휴대전화번호 형식이 맞지 않습니다.(형식)";
    		public static final String payment_0104="수신자 휴대전화번호 형식이 맞지 않습니다.(길이)";
    		public static final String payment_0105="수신자 휴대전화번호 형식이 맞지 않습니다.(형식)";
    		public static final String payment_0106="상품번호 형식이 맞지 않습니다.(길이)";
    		public static final String payment_0107="주문건수 형식이 맞지 않습니다.";
    		public static final String payment_0108="주문금액 형식이 맞지 않습니다.";
    		public static final String payment_0109="결제방식이 잘못되었습니다.";
    		public static final String payment_0112="미등록 상품번호 입니다.";
    		public static final String payment_0210="미등록 payId 입니다.";
    		public static final String payment_other="상품결제에 실패하였습니다.";

    		public static final String happycon_inavlid_user_name="사용자 이름이 존재하지 않습니다.";

    		public static final String happycon_inavlid_plugin="플러그인을 설치후 다시 시도하여주십시요.";
    		public static final String happycon_inavlid_product_price="상품가격이 올바르지 않습니다.";
    		public static final String happycon_inavlid_product_code="상품코드가 올바르지 않습니다.";
    		public static final String happycon_fail_to_view_my_coupon="내쿠폰조회에 실패하였습니다.";

    		public static final String happycon_fail_to_view_buy_list="구매내역조회에 실패하였습니다.";
    		public static final String happycon_already_exist_coupon="이미 찜한 목록입니다.\n내정보 > 찜목록에서 확인하세요.";
    		public static final String happycon_fail_to_save_coupon="쿠폰찜하기에 실패하였습니다.";
    		
    		public static final String happycard_fail_to_view_card="카드조회에 실패하였습니다.";
    		public static final String happycard_empty_user_token="사용자 인증토큰이 존재하지 않습니다. 프로그램을 재구동후 다시 시도 하여주십시요.";

    		
    		public static final String home_invalid_content="조회내용이 올바르지 않습니다.";
    		public static final String home_event_fail_to_down_image="이벤트 내용이 존재하지 않습니다.";
    		
    		
    		public static final String card_empty_own_card_user="등록된 카드가 존재하지 않습니다. 회원가입후에 다시 시도하여 주십시요.";
    		
    	   	public static final String passowrd_inavlid_confirm="비밀번호가 일치하지 않습니다.확인후 다시 시도하여 주십시요.";

    		
    	}
    	
        public static final class string {
        	
        	public static final String app="해피포인트";
        	public static final String exit_app="프로그램을 종료하시겠습니까?";
        	 
        	public static final String net_cant_connection ="인터넷에 연결을 할수 없습니다.";
        	public static final String net_re_connection ="인터넷에 연결을 할수 없습니다. 다시 시도하시겠습니까? 아니오를 선택하시면 프로그램은 종료됩니다.";
        	public static final String net_connection ="안내";
        	
        	
        	public static final String mygroup_empty_message = "올바르게 입력후 다시 시도하여 주십시요.";
        	
        	
        	///210.223.192.103
        	
        	
            	
    	   	public static final String common_no_search_result="조회된 결과가 없습니다.";

    	   	public static final String process_job_exit = "종료중... 잠시만 기다려 주십시요.";
        	public static final String process_job = "로딩중...";
        	public static final String process_job_view = "조회중...";
        	public static final String process_job2 = "처리중...";
        	public static final String process_job_save = "저장중...";
        	public static final String process_job_send  = "전송중...";
        	public static final String process_card_lit_job = "소유카드 조회중...";
        	public static final String process_card_verify_name = "사용자 실명 인증중...";
        	public static final String process_card_verify_login = "로그인중...";
        	
    	   	public static final String home_event_join_period="응모기간: ";
    	   	public static final String home_event_join_date="응모발표: ";
    	   	public static final String happycon_won="원";
    	   	public static final String happycon_select="선택";
    	   	public static final String[] sort_items={
    	   		"인기순",
    	   		"업데이트순",
    	   		"가격순(낮은가격순)",
    	   		"가나다순",
    	   	};
    	   	
    		public static final String[] auth_items={
    	   		"본인인증을 통한 카드발급",
    	   		"ID/PW를 통한 카드발급",
    	   		"취소",
    	   	};
    	   	
    	   	
    	   	

          	public static final String scan_delete_item = "삭제하시겠습니까?";
          	
          	
    	   	public static final String aggrement_ok="약관에 동의해 주세요.";
    	   	public static final String card_reg_ok="해피포인트 모바일 카드 등록이 완료되었습니다.";

    	   	public static final String card_invalid_search_address="주소를 정확히 입력후 다시 시도하여주십시요.";

    	   	public static final String card_aggrement_use="http://members.happypointcard.com/member_02/article02.html";
    	   	public static final String card_aggrement_online="http://members.happypointcard.com/member_02/article01.html";
    	   	public static final String card_aggrement_pri="http://members.happypointcard.com/member_02/article03.html";
          	
    	   	public static final String user_invalid_ssn="주민등록번호가 올바르지 않습니다.";
    	   	
    	   	
    	   	public static final String card_invalid_auth_time="인증코드 입력시간이 초과되었습니다. 다시 시도하여 주십시요.";
    	   	public static final String card_issued_auth_code="인증번호를 발송하였습니다.";
    	   	public static final String card_invalid_auth_code="인증코드가 올바르지 않습니다.";
    	   	public static final String card_invalid_address="우편번호가 올바르지 않습니다.";
    	   	public static final String card_invalid_address_full="주소가 올바르지 않습니다.";
    	   	public static final String card_invalid_phone_number="입력하신 휴대폰 번호가 유효하지 않습니다.";
    	   	public static final String card_invalid_ssn="입력하신 주민번호가 올바르지 않습니다.";
    	   	public static final String card_invalid_user_name="입력하신 이름이 올바르지 않습니다.";
    	   	public static final String card_invalid_user_id="입력하신 아이디가 올바르지 않습니다.";
    	   	public static final String card_invalid_user_pw="입력하신 비밀번호 올바르지 않습니다.";
    	   	
    	   	public static final String card_invalid_user_receiver="받는사람 폰번호가 올바르지 않습니다.";
    	   	public static final String card_invalid_user_sender="보내는사람 폰번호가 올바르지 않습니다.";
    	   	
    	   	public static final String card_select_card="이용중인 해피포인트 카드가 있습니다.\n\n 해피포인트 카드를 만드시겠습니까?";
    	   	public static final String card_select_card_no="이용중인 해피포인트 카드가 없습니다.\n\n 해피포인트 카드를 만드시겠습니까?";
    	   	
    	   	public static final String card_empty_own_card="등록된 카드가 존재하지 않습니다.";
    	   	public static final String card_desc_use_point="개월간 사용한 포인트 내역입니다.";
    	   	public static final String card_desc_save_point="개월간 적립한 포인트 내역입니다.";
    	   	
    	   	public static final String card_empty_card_do_auth="해당아이디로 등록된 카드가 없습니다. 발급을 원하시면 본인인증을 해주세요.";
    	   	
    	   	
    	   	
    	   	public static final String happycon_save_couon_ok="찜하기를 완료하였습니다.\n내정보 > 찜목록에서 확인하세요.";
    	   	public static final String happycon_delete_coupon="선택된 정보를 삭제하시겠습니까?";
    	   	
    	   	public static final String happycon_show_auth_alert="해피콘 구매인증 완료 후 이용할수 있습니다.";
    	   	public static final String happycon_payment_success="해피콘 구매 및 선물하기가  완료되었습니다.";
    	   	public static final String happycon_payment_cancel="해피콘 구매가 취소되었습니다.";
    	   	
    	   	
    	   	public static final String list_empty_item="조회된 항목이 없습니다.";
    	   	
    	   	public static final String user_reg_ok="사용자 등록이 완료되었습니다.";
    	   	
    	   	public static final String help_auth_auto_set_ok="자동인증 설정이 완료되었습니다.";
    	   	public static final String help_auth_auto_phone_ok="해피콘 발송번호 변경이 완료되었습니다.";
    	   	
    	   	public static final String passowrd_config="비밀번호 사용 설정을\n취소 하시겠습니까?";
    	   	public static final String passowrd_config_check="하단에 비밀번호 등록 및 변경 버튼을 눌러 비밀번호를 등록해주세요.";
    	   	
    	   	public static final String passowrd_confirm_completed="비밀번호 변경이 완료되었습니다.";
    	   	public static final String help_call_center="1599-2799";
    	   	public static final String help_call_center2="080-320-1234";
    	   	
    	   	
    	   	

        		      	
		}
        
        
        public static class COpCode{
	    	public int mIntOpcode;
	    	public String mSOpocde;
	    	public int mBoarIndex;
	    	
	    	public COpCode(int opcode, String sopcode, int board_index){
		    	mIntOpcode 	= opcode;
		    	mSOpocde	= sopcode;
		    	mBoarIndex  = board_index;
	    	}
	    }
        
        public static final class opcode {
			static int  index =1;
			
			
			public static final COpCode op_info_list = new COpCode(index++, "op_info_list", 2);
			public static final COpCode op_info_view = new COpCode(index++, "op_info_view", 0);

			public static final COpCode op_coupon_barcode_view = new COpCode(index++, "op_coupon_barcode_view",2);
			public static final COpCode op_barcode_view = new COpCode(index++, "op_barcode_view",2);
			
			public static final COpCode op_menu_list = new COpCode(index++, "op_menu_list",2);
			public static final COpCode op_event_list = new COpCode(index++, "op_event_list",2);
			public static final COpCode op_event_popup_notice = new COpCode(index++, "op_event_popup_notice",2);
			
			
			public static final COpCode op_movie_list = new COpCode(index++, "op_movie_list",2);
			public static final COpCode op_movie_down = new COpCode(index++, "op_movie_down",2);

			public static final COpCode op_user_name_verify = new COpCode(index++, "op_user_name_verify",2);
			public static final COpCode op_user_login_verify = new COpCode(index++, "op_user_login_verify",2);
			
			public static final COpCode op_user_search_address = new COpCode(index++, "op_user_search_address",2);
			public static final COpCode op_user_issue_code = new COpCode(index++, "op_user_issue_code",2);
			public static final COpCode op_user_auth_self = new COpCode(index++, "op_user_auth_self",2);
			public static final COpCode op_user_auth_self2 = new COpCode(index++, "op_user_auth_self2",2);
			
			public static final COpCode op_user_reg = new COpCode(index++, "op_user_reg",2);
			public static final COpCode op_user_own_card_list = new COpCode(index++, "op_user_own_card_list",2);
			public static final COpCode op_user_own_card_reg = new COpCode(index++, "op_user_own_card_reg",2);
			
			
			public static final COpCode op_card_ph_list = new COpCode(index++, "op_card_ph_list",2);
			public static final COpCode op_card_point_list = new COpCode(index++, "op_card_point_list",2);
			public static final COpCode op_card_total_point = new COpCode(index++, "op_card_total_point",2);

			public static final COpCode op_happycon_sort_list = new COpCode(index++, "op_happycon_sort_list",2);

			public static final COpCode op_happycon_list = new COpCode(index++, "op_happycon_list",2);
			public static final COpCode op_happycon_season_banner = new COpCode(index++, "op_happycon_season_banner",2);
			
			
			//내정보 쿠폰내역,보유쿠폰조회
			public static final COpCode op_happycon_buy_history_list = new COpCode(index++, "op_happycon_buy_history_list",2);
			//public static final COpCode op_happycon_coupon_history_list = new COpCode(index++, "op_happycon_coupon_history_list",2);
			public static final COpCode op_happycon_my_coupon_list = new COpCode(index++, "op_happycon_my_coupon_list",2);
			
			
			
			public static final COpCode op_happycon_save_coupon_list = new COpCode(index++, "op_happycon_save_coupon_list",2);
			public static final COpCode op_happycon_delete_coupon = new COpCode(index++, "op_happycon_delete_coupon",2);
			
			
			
			
			
			public static final COpCode op_user_happycon_payment = new COpCode(index++, "op_user_happycon_payment",2);
			
			public static final COpCode op_shop_list = new COpCode(index++, "op_shop_list",2);
			public static final COpCode op_shop_all_list = new COpCode(index++, "op_shop_all_list",2);
			public static final COpCode op_help_notice_list = new COpCode(index++, "op_help_notice_list",2);
			
			
			public static final COpCode op_local_change_sub1 = new COpCode(index++, "op_local_change_sub1",2);
			public static final COpCode op_local_movie_play = new COpCode(index++, "op_local_movie_play",2);
			public static final COpCode op_local_down_image = new COpCode(index++, "op_local_down_image",2);
			public static final COpCode op_local_app_init = new COpCode(index++, "op_local_app_init",2);
			public static final COpCode op_local_app_exit = new COpCode(index++, "op_local_app_exit",2);

			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
	
			
			
			public static final COpCode mOpCodes[]={
				op_info_list,
				
				op_info_view,
				op_menu_list,
				op_coupon_barcode_view,
				op_barcode_view,
				op_event_list,
				op_event_popup_notice,
				op_movie_list,
				op_user_name_verify,
				op_user_login_verify,
				op_user_search_address,
				op_user_issue_code,
				op_user_auth_self,
				op_user_auth_self2,
				
				op_user_reg,
				op_user_own_card_list,
				op_user_own_card_reg,
				op_card_ph_list,
				op_card_point_list,
				
				op_happycon_list,
				op_happycon_sort_list,
				op_happycon_season_banner,
				
				op_happycon_buy_history_list,
				op_happycon_my_coupon_list,
				op_happycon_save_coupon_list,//local
				
				op_happycon_delete_coupon,
				op_user_happycon_payment,
				
				op_shop_list,
				op_card_total_point,
				op_shop_all_list,
				
				op_local_change_sub1,
				op_local_movie_play,
				op_local_down_image,
				op_local_app_init,
				op_local_app_exit
				
			};
			
			public static int getBoardIndex(int iopcode){
				int index = -1;
				
				int size = mOpCodes.length;
				for(int i=0; i<size; i++){
					if(iopcode==mOpCodes[i].mIntOpcode)
						return mOpCodes[i].mBoarIndex;
				}	
				
				return index;
			}
		}
		
        
}
