package com.hpapp.address;

public interface Item {

	public boolean isSectionItem();
	
}
