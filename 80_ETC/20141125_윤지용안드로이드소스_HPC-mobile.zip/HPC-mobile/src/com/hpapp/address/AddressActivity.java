package com.hpapp.address;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.hpapp.R;

public class AddressActivity extends Activity implements TextWatcher {

	private ListView listview;
	private List<Items> Items;
	private List<Items> filterArray = new ArrayList<Items>();
	private List<Items> checkItem = new ArrayList<Items>();
	private ArrayList<Item> ItemssSection = new ArrayList<Item>();
	private ArrayList<String> confirmNumber;
	private int cntCheck = 0;
	private String checkNum = "";
	
	private NamesAdapter objAdapter = null;
	
	private EditText mySearch;
	private String searchString;
	private ImageButton btnSearch, btnSelect, btnCancel, btnClose;
	private int addrcount;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_address);
		
		Intent incount = getIntent();
		addrcount = incount.getIntExtra("count", 5);
		listview = (ListView) findViewById(R.id.list);
		mySearch = (EditText) findViewById(R.id.txt_search);
		mySearch.addTextChangedListener(this);
		
		btnSearch = (ImageButton) findViewById(R.id.img_search);
		btnSearch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				InputMethodManager mgr = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				mgr.hideSoftInputFromWindow(mySearch.getWindowToken(), 0);
			}
		});
		
		listview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> av, View v, int index, long arg3) {
				// TODO Auto-generated method stub
				checkNum = checkItem.get(index).getId();
					for(Items check : checkItem) {
					if(!check.isIndex() && check.getId().equals(checkNum)) {
						if(!check.isCheck() == true) {
							if(cntCheck < addrcount) {
								check.setCheck(true);
								cntCheck++;
							} else {
								check.setCheck(false);
								Toast.makeText(AddressActivity.this, "선택은 "+ addrcount +"명까지 가능합니다.", Toast.LENGTH_LONG).show();
							}
						} else {
							check.setCheck(!check.isCheck());
							cntCheck--;
						}
					}
				}
				
				objAdapter.notifyDataSetChanged();
			}
		});
	
		btnCancel = (ImageButton) findViewById(R.id.img_cancel);
		btnCancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		btnClose = (ImageButton) findViewById(R.id.btn_close);
		btnClose.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		btnSelect = (ImageButton) findViewById(R.id.img_confirm);
		btnSelect.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				confirmNumber = new ArrayList<String>();
				
				for(Items select : Items) {
					if(select.isCheck() == true) {
						confirmNumber.add(select.getPhoneNum());
//						System.out.println(select.getPhoneNum());
					}
				}
				
				setResult(RESULT_OK, (new Intent()).putExtra("peopleNumber", confirmNumber));
				finish();
			}
		});
		
		addItem();
	
	}
	
	public void addItem() {
		
		Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
		
		String sortOrder = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC";

		String disid = ContactsContract.CommonDataKinds.Phone.CONTACT_ID;
		String disName = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME;
		String disNum = ContactsContract.CommonDataKinds.Phone.NUMBER;
//		Cursor cursor = getContentResolver().query(uri, new String[]{disid, disName, disNum}, ContactsContract.CommonDataKinds.Phone.TYPE+"="+ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE , null, sortOrder);
		Cursor cursor = getContentResolver().query(uri, new String[]{disid, disName, disNum}, null, null, sortOrder);
		int count = cursor.getCount();
		int i=0;
		
		String[] id = new String[count];
		String[] name = new String[count];
		String[] number = new String[count];
		boolean[] selection = new boolean[count];
		Items = new ArrayList<Items>();
		System.out.println(cursor.getCount());
		
		if(cursor!=null) {
			cursor.moveToFirst();
			while(!cursor.isAfterLast()) {
				selection[i] = false;
//				id[i] = cursor.getString(0);
				id[i]= i + ""; 
				name[i] = cursor.getString(1);

				try{
					number[i] = cursor.getString(2).replaceAll("-", "");
					if(number[i].indexOf("010")>-1
							|| number[i].indexOf("011")>-1
							|| number[i].indexOf("016")>-1
							|| number[i].indexOf("017")>-1
							|| number[i].indexOf("018")>-1
							|| number[i].indexOf("019")>-1){
						if(number[i].length() == 9) {
							number[i] = number[i].substring(0, 2) + "-" + number[i].substring(2, 5) + "-" + number[i].substring(5);
						} else if(number[i].length() == 10) {
							number[i] = number[i].substring(0, 3) + "-" + number[i].substring(3, 6) + "-" + number[i].substring(6);
						} else if(number[i].length() == 11) {
							number[i] = number[i].substring(0, 3) + "-" + number[i].substring(3, 7) + "-" + number[i].substring(7);
						}
						Items.add(new Items(id[i], selection[i], name[i], number[i]));
					}
				}catch(Exception e){
					i++;
					cursor.moveToNext();
					continue;
				}
				
				i++;
				cursor.moveToNext();
			}
			cursor.close();
		}

		setAdapterToListView(Items);
		
		for(Items item : Items) {
			System.out.println("id : " + item.getId());
		}
		
	}
	
	public char getLabel(char strHeader) {
		
		char label = ' ';
		
		if(SoundSearcher.isHangul(strHeader)) {
			label = SoundSearcher.getInitialSound(strHeader);
		} else if(Character.isDigit(strHeader)) {
			label = '#';
		} else {
			if(Character.isLowerCase(strHeader) == true) {
				label =  Character.toUpperCase(strHeader);
			} else{
				label = strHeader;
			}
		}
		
		return label;
		
	}
	
	public void setAdapterToListView(List<Items> listForAdapter) {
		
		ItemssSection.clear();
		checkItem.clear();
		
		if(null != listForAdapter && listForAdapter.size() != 0) {
			
//			Collections.sort(listForAdapter);
			
			char checkChar = ' ';
			
			for(int index = 0; index < listForAdapter.size(); index++) {
				
				Items objItem = (Items) listForAdapter.get(index);
				Items idxItem = new Items();
				
				char firstChar =  getLabel(objItem.getName().charAt(0));
				
				if(' ' != checkChar) {
					if(checkChar != firstChar) {
						ItemsSelections objSectionItem = new ItemsSelections();
						objSectionItem.setSectionLetter(firstChar);
						ItemssSection.add(objSectionItem);
						idxItem.setIndex(true);
						checkItem.add(idxItem);
					}
				} else {
					ItemsSelections objSectionItem = new ItemsSelections();
					objSectionItem.setSectionLetter(firstChar);
					ItemssSection.add(objSectionItem);
					idxItem.setIndex(true);
					checkItem.add(idxItem);
				}
				
				checkChar = firstChar;
				
				ItemssSection.add(objItem);
				objItem.setIndex(false);
				checkItem.add(objItem);
				
			}
			
		} 
		
		if(null == objAdapter) {
			objAdapter = new NamesAdapter(AddressActivity.this, ItemssSection);
			listview.setAdapter(objAdapter);
		} else {
			objAdapter.notifyDataSetChanged();
		}
		
	}
	
	public void numberSearch() {
		filterArray.clear();
		searchString = mySearch.getText().toString();
		
		if(Items.size() > 0 && searchString.length() > 0) {
			for(Items name : Items) {
				if(name.getName().startsWith(searchString)) {
					filterArray.add(name);
				} else if(name.getPhoneNum().substring(9).equals(searchString) || name.getPhoneNum().substring(8).equals(searchString)) {
					filterArray.add(name);
				}
			}
			setAdapterToListView(filterArray);
		} else {
			filterArray.clear();
			setAdapterToListView(Items);
		}
		
	}
	
	@Override
	public void afterTextChanged(Editable s) {
		// TODO Auto-generated method stub
		
		searchString = mySearch.getText().toString();
		
			filterArray.clear();
			if(Items.size() > 0 && searchString.length() > 0) {
				for(Items name : Items) {
					// 영어검색 (소문자든 대문자든 구분안하고 검색)
					if(Character.isLowerCase(searchString.charAt(0)) || Character.isUpperCase(searchString.charAt(0))) {
						String search = searchString.toLowerCase();
						String value = name.getName().toLowerCase();
						
						if(value.startsWith(search))
							filterArray.add(name);
					
						// 전화번호 검색(뒤에 4자리)
					} else if(name.getPhoneNum().substring(9).equals(searchString) || name.getPhoneNum().substring(8).equals(searchString)) {
						filterArray.add(name);
						// 초성검색도 가능
					} else if(SoundSearcher.matchString(name.getName(), searchString) == true) {
						filterArray.add(name);
					}
				}
				setAdapterToListView(filterArray);
			} else {
				filterArray.clear();
				setAdapterToListView(Items);
			}
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count,
			int after) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		// TODO Auto-generated method stub
	}

}
