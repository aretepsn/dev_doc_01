package com.hpapp.address;

public class Items implements Item, Comparable<Items> {

	private String name;
	private String phoneNum;
	private String id;
	private boolean check;
	private boolean isIndex;
	
	public boolean isIndex() {
		return isIndex;
	}

	public void setIndex(boolean isIndex) {
		this.isIndex = isIndex;
	}

	public Items() {
		this.id= "";
		this.name = "";
		this.phoneNum = "";
		
	}
	
	public Items(String id, boolean check, String name, String phoneNum) {
		this.id = id;
		this.check = check;
		this.name = name;
		this.phoneNum = phoneNum;
	}
	
	public boolean isCheck() {
		return check;
	}

	public void setCheck(boolean check) {
		this.check = check;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public int compareTo(Items another) {
		// TODO Auto-generated method stub
		Items object = (Items) another;
		return this.getName().compareTo(object.getName());
	}

	@Override
	public boolean isSectionItem() {
		// TODO Auto-generated method stub
		return false;
	}
}
