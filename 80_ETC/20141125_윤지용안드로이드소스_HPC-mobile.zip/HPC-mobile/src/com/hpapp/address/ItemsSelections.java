package com.hpapp.address;

public class ItemsSelections implements Item {

	private char sectionLetter;
	
	
	public char getSectionLetter() {
		return sectionLetter;
	}


	public void setSectionLetter(char sectionLetter) {
		this.sectionLetter = sectionLetter;
	}


	@Override
	public boolean isSectionItem() {
		// TODO Auto-generated method stub
		return true;
	}
	
}
