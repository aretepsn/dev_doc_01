package com.hpapp.gcm;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.IntentService;
import android.app.Notification;
import android.app.Notification.Builder;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.RingtoneManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.hpapp.IntroActivity;
import com.hpapp.R;
import com.hpapp.res.Const;
import com.hpapp.util.SharedPref;
import com.hpapp.util.StringUtils;

public class GCMIntentService extends IntentService {

	public static int pushCount = 0;
	private double[] objectLoc = {37.5236686, 127.0314074};

    public GCMIntentService() {
		super("GCMIntentService");
		// TODO Auto-generated constructor stub
	}

	private static PowerManager.WakeLock sWakeLock;
    private static final Object LOCK = GCMIntentService.class;
    
    static void runIntentInService(Context context, Intent intent) {
        synchronized(LOCK) {
            if (sWakeLock == null) {
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                sWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "my_wakelock");
            }
        }
        sWakeLock.acquire();
        intent.setClassName(context, GCMIntentService.class.getName());
        context.startService(intent);
    }
    
	@Override
	protected void onHandleIntent(Intent intent) {
		// TODO Auto-generated method stub
		try {
			String action = intent.getAction();
			if (action.equals("com.google.android.c2dm.intent.REGISTRATION")) {
				handleRegistration(intent);
			} else if (action.equals("com.google.android.c2dm.intent.RECEIVE")) {
				handleMessage(intent);
			}
		} finally {
			synchronized(LOCK) {
				sWakeLock.release();
			}
		}
	}

	private void handleRegistration(Intent intent) {
	    String registrationId = intent.getStringExtra("registration_id");
	    String error = intent.getStringExtra("error");
	    String unregistered = intent.getStringExtra("unregistered");
	    
		TelephonyManager telManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE); 
		String phoneNum = telManager.getLine1Number();
		if(!StringUtils.isEmpty(phoneNum) && phoneNum.startsWith("+82")){
			phoneNum = phoneNum.replace("+82", "0");
		}

	    // registration succeeded
	    if (registrationId != null) {
	        // store registration ID on shared preferences
	        // notify 3rd-party server about the registered ID
	    	
			SharedPref pref = new SharedPref(getBaseContext(), Const.SP_KEY);
			pref.putSharedPreference(Const.SP_GCM_REGID, registrationId);
			pref.putSharedPreference(Const.SP_GCM, true);

	    	String[] params = new String[6];
	    	try {
				params[0] = "gubun=A";
				params[1] = "deviceID="+URLEncoder.encode(Secure.getString(this.getContentResolver(), Secure.ANDROID_ID), "utf-8");
				params[2] = "deviceModel="+URLEncoder.encode(Build.MODEL, "utf-8");
				params[3] = "deviceVersion="+URLEncoder.encode(Build.VERSION.RELEASE, "utf-8");
				params[4] = "phone="+phoneNum;
				params[5] = "deviceToken="+URLEncoder.encode(registrationId, "utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    	new SendData().execute(Const.LINK_PUSH_REGIST, params);
	    }
	        
	    // unregistration succeeded
	    if (unregistered != null) {
	        // get old registration ID from shared preferences
	        // notify 3rd-party server about the unregistered ID
			SharedPref pref = new SharedPref(getBaseContext(), Const.SP_KEY);
			registrationId = pref.getSharedPreference(Const.SP_GCM_REGID);
			pref.putSharedPreference(Const.SP_GCM, false);

    		if(!StringUtils.isEmpty(registrationId)){
    			String[] params = new String[1];
    	    	try {
        			params[0] = "deviceToken="+URLEncoder.encode(registrationId, "utf-8");
    			} catch (UnsupportedEncodingException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    	    	
    	    	new SendData().execute(Const.LINK_PUSH_REMOVE, params);
    		}
	    } 
	        
	    // last operation (registration or unregistration) returned an error;
	    if (error != null) {
	        if ("SERVICE_NOT_AVAILABLE".equals(error)) {
	           // optionally retry using exponential back-off
	           // (see Advanced Topics)
	        } else {
	            // Unrecoverable error, log it
	            Log.i(Const.LOG_TAG, "Received error: " + error);
	        }
	    }
	}

	private void handleMessage(Intent intent) {
	    // server sent 2 key-value pairs, score and time
	    String title = intent.getStringExtra("title");
	    String contents = intent.getStringExtra("contents");
	    String type = intent.getStringExtra("type");
	    String seq = intent.getStringExtra("seq");
	    
	    if(!StringUtils.isEmpty(contents)){
		    try {
		    	contents = URLDecoder.decode(contents, "utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    if("BADGE".equals(type)){
	    	// 아이콘에 개수 표시
	    	int count=0;
	    	try{
	    		count=Integer.parseInt(contents);
	    	}catch(Exception e){
	    		count=0;
	    	}
	    	intent = new Intent("android.intent.action.BADGE_COUNT_UPDATE");
	    	intent.putExtra("badge_count", count);
	    	intent.putExtra("badge_count_package_name", "com.hpapp");
	    	intent.putExtra("badge_count_class_name","com.hpapp.IntroActivity");
	    	sendBroadcast(intent);
	    }else if("LBS".equals(type)){
	    	new LbsAlert(getApplicationContext(), contents).findMyLocation();
	    }else{
	    	String params = type+"://"+contents;
	    	generateNotification(getApplicationContext(), "["+title+"] "+contents, params, seq);
	    	// generates a system notification to display the score and time
	    }
	    
	}
	
    /**
     * Issues a notification to inform the user that server has sent a message.
     */
	@SuppressLint("NewApi")
	private void generateNotification(Context context, String message, String params, String seq) {
        int icon = R.drawable.ic_launcher;
        String title = context.getString(R.string.app_name);
        boolean isRunning = false;
        
        String strPackage = "com.hpapp";
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<RunningAppProcessInfo> processes = am.getRunningAppProcesses();
        
        for(RunningAppProcessInfo process:processes){
            if(process.importance == RunningAppProcessInfo.IMPORTANCE_FOREGROUND)
            {
            	if(strPackage.equals(process.processName)){
//            		isRunning = true;
            		break;
            	}
            }
        }
        
        if(isRunning){
    		Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
        }else{
        	if(Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB){
                long when = System.currentTimeMillis();
                
                NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                Notification notification = new Notification(icon, message, when);
                notification.setLatestEventInfo(context, title, message, pendingIntent(context, params, seq));
                notification.flags |= Notification.FLAG_AUTO_CANCEL;
                notification.sound = RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION);
                
                notificationManager.notify(0, notification);
        	}else if(Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN){
        		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        		
        		if(pushCount<1){
        			Builder builder = new Builder(context);
        			builder.setTicker(message);
        			builder.setAutoCancel(true);
        			builder.setSmallIcon(icon);
        			builder.setNumber(pushCount+1);
        			builder.setContentTitle(title);
        			builder.setContentText(message);
        			builder.setContentIntent(pendingIntent(context, params, seq));
        			builder.setOnlyAlertOnce(true);
        			builder.setSound(RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION));
        			notificationManager.notify(pushCount, builder.getNotification());
        			pushCount++;
        		}
        	}else{
        		NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        		
        		if(pushCount<1){
        			Builder builder = new Builder(context);
        			builder.setTicker(message);
        			builder.setAutoCancel(true);
        			builder.setSmallIcon(icon);
        			builder.setNumber(pushCount+1);
        			builder.setContentTitle(title);
        			builder.setContentText(message);
        			builder.setContentIntent(pendingIntent(context, params, seq));
        			builder.setOnlyAlertOnce(true);
        			builder.setSound(RingtoneManager.getActualDefaultRingtoneUri(context, RingtoneManager.TYPE_NOTIFICATION));
        			notificationManager.notify(pushCount, builder.build());
        			pushCount++;
        		}
        	}
        }
    }
	
    private PendingIntent pendingIntent(Context context, String params, String seq){
        Intent notificationIntent = new Intent(context, IntroActivity.class);
        // set intent so it does not start a new activity
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        notificationIntent.putExtra("params", params);
        notificationIntent.putExtra("seq", seq);
        PendingIntent intent = PendingIntent.getActivity(context, pushCount, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
		return intent;
    }
    
	private class SendData extends AsyncTask<Object, Void, Integer>{

		@Override
		protected Integer doInBackground(Object... arg0) {
			// TODO Auto-generated method stub
			int resCode = 0;
			String uri = (String) arg0[0];
			String[] params = (String[]) arg0[1];
			URL url = null;

			try{
				url = new URL(uri);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
				
				con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				con.setDoOutput(true);
				con.setDoInput(true);
				con.setUseCaches(false);
				con.setConnectTimeout(5000);
				con.setRequestMethod("POST");
				
				StringBuffer sb = new StringBuffer();
				for(int i=0;i<params.length;i++){
					if(i>0)
						sb.append("&");
					sb.append(params[i]);
				}
				
				PrintWriter pwr = new PrintWriter(new OutputStreamWriter(con.getOutputStream(), "utf-8"));
				pwr.write(sb.toString());
				pwr.flush();
				
				resCode = con.getResponseCode();
			}catch(SocketTimeoutException e){
				e.printStackTrace();
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return resCode;		
		}

		@Override
		protected void onPostExecute(Integer result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			int resCode = (Integer) result;
			if(resCode < 400){
//				Toast.makeText(getApplicationContext(), "success", Toast.LENGTH_SHORT).show();
			}else{
//				Toast.makeText(getApplicationContext(), "fail", Toast.LENGTH_SHORT).show();
			}

		}
	}

	public class LbsAlert implements LocationListener{
		
		private Context context;
		private String message;
		private LocationManager locManager;
		private double myLat, myLon; 

		LbsAlert(Context context, String message){
			this.context = context;
			this.message = message;
		}
		
		public void findMyLocation(){
			// LocationListener 핸들
			locManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
			// GPS로 부터 위치 정보를 업데이트 요청
			locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this, Looper.getMainLooper());
			// 기지국으로부터 위치 정보를 업데이트 요청
			locManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, this, Looper.getMainLooper());
			// 주소를 가져오기 위해 설정 - KOREA, KOREAN 모두 가능 
//			geoCoder = new Geocoder(getApplicationContext(), Locale.KOREA);
		}
		
		@SuppressLint("NewApi")
		@Override
		public void onLocationChanged(Location myLoc) {
			// TODO Auto-generated method stub
			myLat = myLoc.getLatitude();
			myLon = myLoc.getLongitude();

			float[] result = new float[3];
			Location.distanceBetween(myLat, myLon, objectLoc[0], objectLoc[1], result);
			float distance = result[0];
			if(distance <= 1000f){
				generateNotification(context, message, "LBS://"+message, "");
			}
			
			locManager.removeUpdates(this);
			locManager = null;
		}
		
		@Override
		public void onStatusChanged(String paramString, int paramInt, Bundle paramBundle) {
			// TODO Auto-generated method stub
		}
		
		@Override
		public void onProviderEnabled(String paramString) {
			// TODO Auto-generated method stub
		}
		
		@Override
		public void onProviderDisabled(String paramString) {
			// TODO Auto-generated method stub
		}
	}

	
}
