package com.hpapp.gcm;

import android.app.Application;

import com.daou.smartpush.smartpushmng.SmartPushManager;
import com.daou.smartpush.view.INotificationBuilder;
import com.hpapp.res.Const;

/**
 * 
 * 반드시 정의해야 하는 class 입니다. 
 * push 가 왔을 경우 push 를 받는 ( dialog 와  notification 의 형태를 셋팅 합니다.)
 * 
 * @author 
 * 
 */
public class SmartPushApplication extends Application {

	private final static String APPKEY = Const.SIMPLE_API_KEY;
    private final static String SENDER = Const.GCM_SENDER_ID;      // google gcm서비스 등록시 발급받은 sender id 입니다. (project id)
	
//  push를 받을 형태를 결정 합니다.
	//  SmartPushManager.ALARM_TYPE_DIALOG 를 사용할 경우 DialogView 를 extends 받은 class 를 반드시 작성 하여야 합니다.
	//  SmartPushManager.ALARM_TYPE_NOTI 를 사용할 경우 NotificationBuilder 를 extends 받은 class 를 반드시 작성 하여야 합니다.
//	private final static String ALARMTYPE = SmartPushManager.ALARM_TYPE_DIALOG;	    // dialog 형태 입니다.  
	private final static String ALARMTYPE = SmartPushManager.ALARM_TYPE_NOTI;	    // notification 형태 입니다.  
	
	@Override
	public void onCreate() {      
		super.onCreate();
		// manager 객체를 얻어 옵니다. 
		SmartPushManager mSmartPushManager = SmartPushManager.getInstance();
//		mSmartPushManager.setSmartPushServerURL("http://mdev.terracetech.co.kr:9090/server", this);
		mSmartPushManager.setSmartPushServerURL("http://push.happypointcard.com:35000/server", this);
		mSmartPushManager.setSmartPushRichServerURL("http://richcontents.happypointcard.com/rc", this);
		
		// push service 이용에 필요한 값들을 설정 합니다.
        // gcm 또는 gcm 과 hydro를 모두 이용할 경우 입니다.
		mSmartPushManager.setInfo(APPKEY, SENDER, ALARMTYPE, this);
		
        // push를 받을 dialog view를 지정 합니다. PushDialog.class 대신 
		// DialogView 를 extends 받아 작성한 class 를 설정 합니다.
        mSmartPushManager.setPopupDialogView(PushDialog.class);
        
        // push를 받을 notification 을 지정 합니다. NotificationView 대신
        // NotificationBuilder 를 extends 받아 작성한 class 를 설정합니다.
        INotificationBuilder notificationView = new NotificationView();
    	mSmartPushManager.setNotificationBuilder(notificationView);
	}
}
