package com.hpapp.gcm;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.util.Log;

import com.daou.smartpush.ConstValue.ConstValue;
import com.daou.smartpush.servermodel.PushErrorCode;
import com.daou.smartpush.servermodel.callback.IPushServerInterface;
import com.daou.smartpush.smartpushmng.SmartPushManager;
import com.daou.smartpush.view.INotificationBuilder;
import com.hpapp.IntroActivity;
/**
 * Notification 의 layout 및 icon 전체 layout 을 지정해 줍니다.
 * push 를 notitication 으로 받도록 설정 하였을시 반드시 구현해야 합니다.
 * NotificationBuilder 를 상속 받아 구현 합니다.
 *
 * @author 
 * 
 */
public class NotificationView implements INotificationBuilder{

	private static int NotificationRequestCode = 1;
	private static int JELLYBEAN_API_VERSION = 16;
	String seq = "", type = "", message="";
	
	@Override
	public int notiIcon() {
		// icon drawable 을 지정 합니다.
		return com.hpapp.R.drawable.ic_launcher;
	}
	
	@Override
	public PendingIntent normalPushPendingIntent(String pushType, HashMap<String, String> hashMap, Context context) {
		// notification을 touch 시 PendingInten를 설정합니다.
		// 이 옵션은 NormalPush일경우만 해당하며 RichPush 일경우 RichView로 바로 연결됩니다. 
		try {

			message = hashMap.get(ConstValue.IntentKey.MESSAGE).toString();
			JSONObject json = new JSONObject(hashMap.get(ConstValue.IntentKey.OPTION).toString());
			if(!json.isNull("etype"))
				type = String.valueOf(json.get("etype"));
			if(!json.isNull("seq"))
				seq = String.valueOf(json.get("seq"));
			
			Log.i("INFO===", "message=" +  message);
			Log.i("INFO===", "etype=" +  type);
			Log.i("INFO===", "seq=" +  seq);
			Log.i("INFO===", "NotificationRequestCode=" +  NotificationRequestCode);
		} catch (JSONException e) {
			Log.d("INFO","normalPushPendingIntent Exception - " +e.getMessage());
		}
		Intent intent = new Intent();
		PendingIntent launcherIntent;
		intent.setClass(context, IntroActivity.class);
		
		String params = type+"://"+message;
		intent.putExtra("params", params);
		intent.putExtra(ConstValue.IntentKey.MSG_TAG, hashMap.get(ConstValue.IntentKey.MSG_TAG));

		if("EVENT".equals(type)) {
			intent.putExtra("seq", seq);
		}
		
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
		launcherIntent = PendingIntent.getActivity(context, NotificationRequestCode, intent, PendingIntent.FLAG_ONE_SHOT);
		NotificationRequestCode++;
		return launcherIntent;
//		return null;
	}
	
	@Override
	public String titleText() {
		// notification 의 title text 를 생성 합니다.
		// title text 를 따로 생성하지 않고 기본 title 을 쓰려면 해당 메소드를
		// override 받지 않거나 return 값을 null 로 설정 하면 됩니다.
		
		// 예) 
		// return "[알림]";
		return null;
	}

	@Override
	public String messageText() {
		// notification 의 message text 를 생성 합니다.
		// message text 를 따로 생성하지 않고 기본 message 를 쓰려면  해당 메소드를
		
		return null;
	}
	
	@SuppressLint("NewApi")
	@Override
	public Notification notification(String pushType, HashMap<String, String> hashMap,
			Bitmap bitmap, Context context) { 
		
		if( Build.VERSION.SDK_INT >= JELLYBEAN_API_VERSION && bitmap != null) {

			   String notiMessage = "";
			   String notiTitle = "";
			    if(messageText() == null)
			           notiMessage = hashMap.get("msg").toString();
			          else 
			           notiMessage = messageText();
			          
			          if(titleText() == null){
			           String msg = hashMap.get("msg").toString();
			           notiTitle = msg.length() > 15 ?msg.substring(0, 15) : msg ;
			          }else 
			           notiTitle = titleText();
			   
			   // jelly bean 이상일 경우에만 BigPictureStyle notification 사용이 가능 합니다.
			   Notification notification = new Notification.BigPictureStyle(new Notification.Builder(context)
			   .setContentTitle(notiTitle).setContentText(notiMessage).setSmallIcon(notiIcon()).setTicker(notiTitle))
			   .setBigContentTitle(notiTitle).setSummaryText(notiMessage)
			   .bigPicture(bitmap).build();
			    
			    // pending intent를 설정합니다.  
			    notification.contentIntent = normalPushPendingIntent(pushType, hashMap, context);
			   return notification;
			  } else {
			    // jelly bean 미만인 경우 입니다.
			   return null;
			  }
		
//		// bitmap은 image path 가 있을경우에만 전달되고 그외에는 null 값이 전달 됩니다.
//		if( Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN&& bitmap != null) {
//			Log.i("bitmap", " notification SDK_INT=" + Build.VERSION.SDK_INT );
//			
//			// jelly bean 이상일 경우에만 BigPictureStyle notification 사용이 가능 합니다.
//			Notification notification = new Notification.BigPictureStyle(new Notification.Builder(context)
//			.setContentTitle("title").setContentText("text").setSmallIcon(notiIcon()).setTicker("ticker"))
//			.setBigContentTitle("BigContentTitle").setSummaryText("SummaryText")
//			.bigPicture(bitmap).build();
//			 
//			 // pending intent를 설정합니다.  
//			 notification.contentIntent = normalPushPendingIntent(pushType, hashMap, context);
//			return notification;
//		} else {
//			Log.i("Build.VERSION.SDK_INT JELLYBEAN_API_VERSION", "Build.VERSION.SDK_INT = " + Build.VERSION.SDK_INT  + "        JELLYBEAN_API_VERSION = " +JELLYBEAN_API_VERSION
//					+", bitmap path = " + bitmap );
//			// jelly bean 미만인 경우 입니다.
//			// 미만인 경우 일반 notification을 처리 합니다. 
//			return null;
//		}
////		else if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB){
////			 // jelly bean 미만인 경우 입니다.
////				Notification notification = new Notification.Builder(context)
////				.setContentTitle("title").setContentText("text").setSmallIcon(notiIcon()).setTicker("ticker").build();
////				
////				notification.contentIntent = normalPushPendingIntent(pushType, hashMap, context);
////				return notification;
////		} else{
////			// HONEYCOMB 미만인 경우 입니다.
////			long when = System.currentTimeMillis();
////			Notification notification = new Notification(notiIcon(), "text", when);
////			notification.setLatestEventInfo(context, "title", "text", normalPushPendingIntent(pushType, hashMap, context));
////			
////			return notification;
////			
////		}
//		

	}
	
	@Override
	public Class<?> richView() {
		// RichPush를 수신시 Notification을 Touch 시 이동되는 Activity 클래스를 설정합니다.
		return RichView.class;
	}
	
}
