package com.hpapp.gcm;

import org.json.JSONException;
import org.json.JSONObject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageButton;

import com.daou.smartpush.ConstValue.ConstValue;
import com.daou.smartpush.servermodel.PushErrorCode;
import com.daou.smartpush.servermodel.callback.IPushServerInterface;
import com.daou.smartpush.smartpushmng.SmartPushManager;
import com.daou.smartpush.view.RichPushView;
import com.hpapp.IntroActivity;
import com.hpapp.R;
import com.hpapp.activity.LoginActivity;
import com.hpapp.adapter.HappyPointSync;
import com.hpapp.adapter.MenuAdapter;
import com.hpapp.bean.UserBean;
import com.hpapp.res.Const;
import com.hpapp.util.SharedPref;
import com.hpapp.util.StringUtils;

/**
 * rich push 를 사용시 반드시 구현해야 합니다.
 * RichPushView 를 상속 받아 구현 합니다.
 *
 * @author
 * 
 */
public class RichView extends RichPushView {
	
	String pushSeq = "", pushType="";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.i("SMART_PUSH", "RichPush view create");
	}

	/**
	 * onCreate() 후 호출 됩니다.
	 */
	@Override
	public void initialize(Intent intent) {
		final Intent inten = intent;
		
		setContentView(R.layout.richview);
		// webView 를 지정해 줍니다.
		WebView webView = (WebView) findViewById(R.id.webview); 
		// 웹view 사이즈 조정시 사용 
		webView.setWebChromeClient(new WebChromeClient());
		webView.getSettings().setJavaScriptEnabled(true); 
		webView.getSettings().setPluginsEnabled(true);
		// 스크롤 영역을 내부로 지정 합니다
		webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		// webView 에 rich push 내용을 보여 줍니다.
//		getData(webView);
		postData(webView);
	    // webView 닫기 버튼을 설정 합니다.
	    Button close = (Button) findViewById(R.id.close_button);
	    close.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				// pushMessage 읽음 처리 요청을 보냅니다.
				// mIsendReadserverInterface : pushMessage 읽음 처리 요청에 대한 결과 처리 Listener 입니다.
				SmartPushManager smartPushManager = SmartPushManager.getInstance();
				smartPushManager.readPushMessage(mIsendReadserverInterface, inten.getStringExtra(ConstValue.IntentKey.MSG_TAG), RichView.this);
				finish();
			}
		});
	    
	    Button move = (Button) findViewById(R.id.move_button);
	    move.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				// pushMessage 읽음 처리 요청을 보냅니다.
				// mIsendReadserverInterface : pushMessage 읽음 처리 요청에 대한 결과 처리 Listener 입니다.
				SmartPushManager smartPushManager = SmartPushManager.getInstance();
				smartPushManager.readPushMessage(mIsendReadserverInterface, inten.getStringExtra(ConstValue.IntentKey.MSG_TAG), RichView.this);
				try {
					JSONObject json = new JSONObject(getIntent().getStringExtra(ConstValue.IntentKey.OPTION).toString());
					Log.i("INFO", "richpush etype=" +  json.get("etype"));
					Log.i("INFO", "richpush seq=" +  json.get("seq"));
					
					pushType = String.valueOf(json.get("etype"));
					pushSeq = String.valueOf(json.get("seq"));
					Log.i("Test", "seq=" +  pushSeq + "       type = " + pushType);
					
//					if(pustType.equals("EVENT")) {
//						
//						if(StringUtils.isEmpty(pushSeq)) {
//							MenuAdapter.performClick(Const.MENU_ID_EVENT, Const.LINK_EVENT_LIST);
//						}else {
//							MenuAdapter.performClick(Const.MENU_ID_EVENT, Const.LINK_EVENT_VIEW+"?eventSeq="+pushSeq);
//						}
//        			
//					} else {
					
    				Intent intent = new Intent(RichView.this, IntroActivity.class);
    				intent.putExtra("params", "MENULINK://"+pushType);
//    				intent.putExtra("delegateUrl", "http://----------");
					intent.putExtra("seq", pushSeq);
					intent.putExtra(ConstValue.IntentKey.MSG_TAG, inten.getStringExtra(ConstValue.IntentKey.MSG_TAG));
    				startActivity(intent);

				} catch (JSONException e) {
					Log.d("INFO","richpush/initialize Exception - " +e.getMessage());
				}
				finish();
				
			}
		});
	    
	}
	
	
	/**
	 * pushMessage 읽음 처리 요청 callback
	 */
	private IPushServerInterface mIsendReadserverInterface = new IPushServerInterface() {
		
		@Override
		public String getResponseResult() {return null; }
		@Override
		public Object getResponseObject() {return null; }
		@Override
		public void sendResult(String result, Object obj) {
			if(result.equals(PushErrorCode.RESULT_CODE_200)){
				// pushMessage 읽음 처리 요청 성공 의 경우 입니다.
				Log.i("INFO", "rich 읽음 처리 성공");
			}else{
				// pushMessage 읽음 처리요청 실패의 경우 입니다.
				Log.i("INFO", "rich 읽음 처리 실패");
			}
		}
	};
	
}
