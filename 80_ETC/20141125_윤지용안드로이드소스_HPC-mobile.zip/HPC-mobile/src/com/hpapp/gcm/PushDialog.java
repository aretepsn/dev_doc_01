package com.hpapp.gcm;

import java.util.HashMap;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.daou.smartpush.ConstValue.ConstValue;
import com.daou.smartpush.servermodel.PushErrorCode;
import com.daou.smartpush.servermodel.callback.IPushServerInterface;
import com.daou.smartpush.smartpushmng.SmartPushManager;
import com.daou.smartpush.view.DialogView;
import com.hpapp.IntroActivity;

/**
 * push 를 dialog로 받도록 설정 하였을시 반드시 구현해야 합니다.
 * push 를 받았을시의 action 에 대한 설정을 합니다.
 * DialogView 를 상속 받아 구현 합니다.
 *
 * @author
 * 
 */
public class PushDialog extends DialogView{
	
	private AlertDialog mDialog;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("SMART_PUSH", "Dialog view create");
	}

	/**
	 * rich push 의 경우 webView 바로 띄우는 예제를 사용 할 경우 입니다.
	 * normal push 의 경우는 동일 합니다.
	 * onCreate() 후 호출 됩니다.
	 */
//	@Overrid
//	public void createDialog(String pushFormat, HashMap<String, String> hashMap) {
//		// mIsRichPush : richPush 여부
//		if(pushFormat.equals(DialogView.RICH_PUSH)){
//			// rich push 일 경우에는 richView 를 바로 띄웁니다. ( RichPushView 를 상속 받아 만든 rich view 지정 합니다. )
//			awakeScreen();
//			callRichView(RichView.class);
//			// activity 를 종료 합니다.
//			finish(); 
//		}else if (pushFormat.equals(DialogView.NORMAL_PUSH)){
//			// normal push 일 경우에는 alertDialog 를 생성 합니다.
//			AlertDialog.Builder alertDialog = new AlertDialog.Builder(PushDialog.this);
//	        alertDialog.setPositiveButton("닫기", new DialogInterface.OnClickListener() {
//				
//				public void onClick(DialogInterface dialog, int which) {
//					// 닫기 버튼 클릭시 activity 종료 합니다.
//					PushDialog.this.finish();
//				}
//			});
//	       
//	        alertDialog.setNegativeButton("보기", new DialogInterface.OnClickListener() {
//				
//				public void onClick(DialogInterface dialog, int which) {
//					
//					// 보기버튼 클릭시 , 아래의 code 대신 원하는 code 를 넣으면 됩니다.
//					// 예제 에서는 main 페이지( SmartPush.class ) 로 이동하고 activity 를 닫도록 설정되어 있습니다.
//					startActivity(new Intent(PushDialog.this, SmartPush.class));
//					// activity 종료
//					PushDialog.this.finish();
//				}
//			});
//	        alertDialog.setTitle("알림");
//	        // bundle.getString(ConstValue.MESSAGE) -> hashMap 객체 안의 push message 입니다.
//	        alertDialog.setMessage(hashMap.get(ConstValue.IntentKey.MESSAGE));
//	        mDialog = alertDialog.show();
//		}
//	}
	
	/**
	 * rich push 의 경우 webView 바로 띄우지 않고 dialog 생성후 '보기' 
	 * 버튼을 클릭 하였을 시에 webView 를 띄우는 예제 입니다.
	 * normal push 의 경우는 동일 합니다.
	 * onCreate() 후 호출 됩니다.
	 */
	@Override
	public void createDialog(String pushFormat, final HashMap<String, String> hashMap) {
		final String format = pushFormat;
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(PushDialog.this);
		
		alertDialog.setPositiveButton("닫기", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int which) {
				PushDialog.this.finish();
				}
			});
	       
		alertDialog.setNegativeButton("보기", new DialogInterface.OnClickListener() {
			
			public void onClick(DialogInterface dialog, int which) {
				
				if(format.equals(DialogView.RICH_PUSH)){
					// rich push 일 경우에는 richView 로 이동 합니다.
					// (RichView.class) 대신 RichPushView 를 상속 받아 만든 rich view 를 설정 합니다. 
					callRichView(RichView.class);
					// rich push 의 경우에는 현 예제에서는 rich push 를 화면에 나타내는 view 쪽에서 ( RichView.java ) 
					// 읽음처리를 하고 있으므로 dialog 에서 따로 읽음 처리를 해주지 않아도 됩니다. 
				}else{
					// 보기버튼 클릭시 , 아래의 code 대신 원하는 code 를 넣으면 됩니다.
					// 예제 에서는 메시지 읽음 처리 후 / main 페이지( SmartPush.class ) 로 이동하고 activity 를 닫도록 설정되어 있습니다.
					SmartPushManager smartPushManager = SmartPushManager.getInstance();
					smartPushManager.readPushMessage(mIsendReadserverInterface, hashMap.get(ConstValue.IntentKey.MSG_TAG), PushDialog.this);
					String msg = (String)hashMap.get(ConstValue.IntentKey.MESSAGE);
					
					startActivity(new Intent(PushDialog.this, IntroActivity.class).putExtra("msg", msg));
				}
				PushDialog.this.finish();
			}
		});
	    alertDialog.setTitle("알림");
	    // bundle.getString("msg") -> hashMap 객체 안의 push message 입니다.
	    alertDialog.setMessage(hashMap.get(ConstValue.IntentKey.MESSAGE));
	    mDialog = alertDialog.show();
	}
	
	/**
	 * pushMessage 읽음 처리 요청 callback
	 */
	private IPushServerInterface mIsendReadserverInterface = new IPushServerInterface() {
		
		@Override
		public String getResponseResult() {return null; }
		@Override
		public Object getResponseObject() {return null; }
		@Override
		public void sendResult(String result, Object obj) {
			if(result.equals(PushErrorCode.RESULT_CODE_200)){
				// pushMessage 읽음 처리 요청 성공 의 경우 입니다.
				Log.i("INFO", "읽음 처리 성공");
			}else{
				// pushMessage 읽음 처리요청 실패의 경우 입니다.
				Log.i("INFO", "읽음 처리 실패");
			}
		}
	}; 
	
	@Override
	protected void onStop() {
		super.onStop();
		// activity 가 종료 될시에 dialog 를 닫습니다.
		if(mDialog != null){
			mDialog.dismiss();
		}
	}
}
