import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class xlsRead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			xls();
		}catch(Exception e){
			System.out.println(e);
		}
	}

	//출처: https://hellogk.tistory.com/14#recentEntries [IT Code Storage]
	//출처: https://hellogk.tistory.com/12
	//http://poi.apache.org/components/spreadsheet/quick-guide.html#Iterator
	public static void xls() throws Exception{
		//파일을 읽기위해 엑셀파일을 가져온다
		FileInputStream fis=new FileInputStream("Z:\\01_xls.xls");
		HSSFWorkbook workbook=new HSSFWorkbook(fis);
		int rowindex=0;
		int columnindex=0;
		//시트 수 (첫번째에만 존재하므로 0을 준다)
		//만약 각 시트를 읽기위해서는 FOR문을 한번더 돌려준다
		HSSFSheet sheet=workbook.getSheetAt(0);
		//행의 수
		int rows=sheet.getPhysicalNumberOfRows();
		for(rowindex=0;rowindex<rows;rowindex++){
			//행을 읽는다
			HSSFRow row=sheet.getRow(rowindex);
			if(row !=null){
				System.out.println("-----------------------rowindex : "+rowindex + "-----------------------");
				//셀의 수
				int cells=row.getPhysicalNumberOfCells();
				for(columnindex=0;columnindex<=cells;columnindex++){
					//셀값을 읽는다
					HSSFCell cell=row.getCell(columnindex);
					String value="";
					//셀이 빈값일경우를 위한 널체크
					if(cell==null){
						continue;
					}else{
						//타입별로 내용 읽기
						value = "--columnindex : " + columnindex + ", type : " + cell.getCellType() + ", value : ";
						switch (cell.getCellType()){
							case STRING:
								value += cell.getRichStringCellValue().getString();
								break;
							case NUMERIC:
								if (DateUtil.isCellDateFormatted(cell)) {
									value += ""+cell.getDateCellValue();
								} else {
									//소수점 없애기
									if( cell.getNumericCellValue()*10 == (int)cell.getNumericCellValue()*10 ){
										value += ""+(int)cell.getNumericCellValue();
									}else{
										value += ""+cell.getNumericCellValue();
									}
								}
								break;
							case BOOLEAN:
								value += ""+cell.getBooleanCellValue();
								break;
							case FORMULA:
								value += ""+cell.getCellFormula();
								break;
							case BLANK:
								value += "";
								break;
							default:
								value += "";
						}
					}
					System.out.println(value);
					}
				}
		}
	}

}
