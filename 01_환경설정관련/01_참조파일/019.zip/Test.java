package test;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runtime runtime = Runtime.getRuntime();
		String cmd = "D:\\98_temp\\ffmpeg\\bin\\";
//		//flv로 인코딩한다.
		cmd += "ffmpeg -i d:\\98_temp\\come_back_home.mp4 -ar 44100 -ab 32 -f flv -s 640x480 d:\\98_temp\\2.flv";
//		//썸네일 추출
//		cmd += "ffmpeg -i d:\\98_temp\\come_back_home.mp4 -an -r 1 -y -s 640x480 test%d.jpg";
//		//동영상 정보추출
//		cmd += "ffmpeg -i d:\\98_temp\\come_back_home.mp4";
		

		System.out.println("---------START----------");
		try{
			runtime.exec(cmd);
		}catch(Exception e){
			System.out.println("error:" + e.getMessage());
			e.printStackTrace();
		}
		System.out.println("---------END----------");
	}

}
