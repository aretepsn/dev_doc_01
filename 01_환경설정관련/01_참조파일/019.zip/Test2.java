package test;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Test2 {

	public static void main(String[] args) {
		String command = "ping www.codejava.net";
		command = "d:\\99_temp\\ffprobe.exe -v quiet -print_format json -show_error -show_format -show_streams d:\\99_temp\\1.mp4";
		 
		try {
		    Process process = Runtime.getRuntime().exec(command);
		 
		    BufferedReader reader = new BufferedReader(
		            new InputStreamReader(process.getInputStream()));
		    String line;
		    while ((line = reader.readLine()) != null) {
		        System.out.println(line);
		    }
		 
		    reader.close();
		 
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//ref : http://www.codejava.net/java-se/file-io/execute-operating-system-commands-using-runtime-exec-methods

}
