package egovframework.example.sample.web;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;


//ref
// - http://scw0531.blog.me/221005412595
// - https://docs.mongodb.com/manual/reference/operator/query/lt/
// - http://cocomo.tistory.com/364
// - http://loveiskey.tistory.com/156
public class MongoTest {
    private MongoTemplate mongoTemplate;
    private MongoOperations mongoOperation;
	 
	    public MongoTest() {
	        String mongoContextPath = "/egovframework/spring/context-mongodb.xml";
	        AbstractApplicationContext ctx = new ClassPathXmlApplicationContext(mongoContextPath);
	        mongoTemplate = (MongoTemplate) ctx.getBean("mongoTemplate");
	        mongoOperation =(MongoOperations) ctx.getBean("mongoTemplate");
	    }
	    
	    static String tableNm = "hiroo";
	    
	    public static void main(String[] args) {
	        MongoTest mongoTest = new MongoTest();
	        //테이블생성/ 데이타 입력
//	        for(int i=0 ; i<5 ; i++){
//	        	mongoTest.insertTestData("둘리---"+i,"고길동 집 1억년전 어딘가.1ddd..", i);
//	        }
//	        mongoTest.findOne("name","abc");				//조회
//	        mongoTest.findOne2("{age:{$lt:3},name:'둘리---3'}");				//조회
//	        mongoTest.remove("name","둘리---2");		//삭제
//	        mongoTest.update("name","둘리---2");		//수정
	    }

	    //insert
	    private void insertTestData(String name, String value, int age) {
	        MongoTestVO testVO = new MongoTestVO();
	        testVO.setName(name);
	        testVO.setAddress(value);
	        testVO.setAge(age);
	        // testVO에 있는 내용을 tableNm Collection에 넣겠다.
	        mongoTemplate.insert(testVO, tableNm);
	    }
	    
	    //update
	    public void update(String key, String value){
	        Criteria criteria = new Criteria(key);
	        criteria.is(value);
	        Query query = new Query(criteria);
	        Update update = new Update();
	        update.set("address", "백수");
	        
	        mongoTemplate.updateFirst(query, update, tableNm);
	        /*mongoTemplate.updateMulti(query, update, tableNm);
	        //조건없이 모든걸 다 바꿔버림
	        mongoTemplate.updateMulti(new Query(), update, tableNm);*/
	    }

	    //findOne2
	    private void findOne2(String where){
	    	BasicQuery query = new BasicQuery(where);
	    	MongoTestVO mongoTestVO = mongoOperation.findOne(query, MongoTestVO.class, tableNm);
	    	output(mongoTestVO);
	    }
	    //findOne
	    private void findOne(String key, String value){
	    	Criteria criteria = new Criteria(key);
	    	criteria.is(value);
	    	Query query = new Query(criteria);
	    	MongoTestVO mongoTestVO = mongoTemplate.findOne(query, MongoTestVO.class, tableNm);
	    	output(mongoTestVO);
	    }
	    
	    //삭제
	    public void remove(String key, String value){
	        Criteria criteria = new Criteria(key);
	        criteria.is(value);
	        Query query = new Query(criteria);
	        mongoTemplate.remove(query, tableNm);
//	        mongoTemplate.remove(new Query(), tableNm);
	    }

	    //출력
	    private void output(MongoTestVO mongoTestVO){
	    	if(mongoTestVO == null) {
	    		System.out.println("DATA 없음");
	    		return;
	    	}
	    	System.out.println("ID----------->" + mongoTestVO.getId());
	    	System.out.println("NAME----------->" + mongoTestVO.getName());
	    	System.out.println("ADDRESS----------->" + mongoTestVO.getAddress());
	    }
	 
	    private class MongoTestVO {
	    	//생성자가 없으면 find시 에러발생
	    	public MongoTestVO(){}
	        // 반드시 id annotation이 붙은 id 변수가 필요!
	        @Id
	        private String id;
	        private String name;
	        private String address;
	        private int age;
	        
			public int getAge() {
				return age;
			}
			public void setAge(int age) {
				this.age = age;
			}
			public String getId() {
				return id;
			}
			public void setId(String id) {
				this.id = id;
			}
			public String getName() {
	            return name;
	        }
	        public void setName(String name) {
	            this.name = name;
	        }
	        public String getAddress() {
	            return address;
	        }
	        public void setAddress(String address) {
	            this.address = address;
	        }
	 
	    }
	}



