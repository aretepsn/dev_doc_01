package ttlabc.api.web;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import ttlabc.api.service.ApiService;
import ttlabc.api.service.BasicVO;
import ttlabc.api.service.ResultMap01VO;

/**
 * 
 * @author aretett
 */

@Controller
public class ApiController {
	
	@Resource(name = "apiService")
	private ApiService apiService;

	@RequestMapping("/basic.do")
	public ModelAndView test(@ModelAttribute("searchVO") BasicVO searchVO, ModelMap model) throws Exception {
		String sa = apiService.returnString(searchVO);

		List<?> appinfoList = apiService.basicList(searchVO);
		model.addAttribute("mediaFiles", appinfoList);
		Map resultMap = new HashMap();
		resultMap.put("result1", "11111");
		resultMap.put("result2", "22222");
		ModelAndView mav = new ModelAndView("jsonView",resultMap);
		return mav;
	}

	@RequestMapping("/resultMap01.do")
	public ModelAndView resultMap01(@ModelAttribute("searchVO") ResultMap01VO searchVO, ModelMap model) throws Exception {
		model.remove("searchVO");

		Map resultMap = new HashMap();
		resultMap.put("code","1000");
		resultMap.put("msg","SUCCESS");
		resultMap.put("host","api.tvontv.co");
		resultMap.put("hash","");

		Map dataMap = new HashMap();
		List<?> mediaDownList = apiService.resultMap01(searchVO);
		dataMap.put("count", mediaDownList.size());
		dataMap.put("mediaFiles", mediaDownList);

		Map<String, Object> outputMap = new LinkedHashMap<String, Object>();
		outputMap.put("result", resultMap);
		outputMap.put("data", dataMap);
		ModelAndView mav = new ModelAndView("jsonView",outputMap);
		return mav;
	}
}
