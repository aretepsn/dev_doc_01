﻿
import java.io.IOException;

public class Test3 {

	public static void main(String[] args) throws Exception{

		String command = "ping www.codejava.net";
		//command = "d:\\99_temp\\ffprobe.exe -v quiet -print_format json -show_error -show_format -show_streams d:\\99_temp\\1.mp4";
//		command = "d:\\99_temp\\ffmpeg -ss 00:50:00 -i 1.mp4 -an -vcodec png -vframes 1 -y d:\\99_teimp\\2.png";
//		command = "d:\\99_temp\\aa.bat";
		command = "d:\\99_temp\\aa.bat";
//		command = "d:\\99_temp\\ffmpeg -ss 00:50:00 -i d:\\99_temp\\1.mp4 -an -vcodec png -vframes 1 -y d:\\99_temp\\233.png";
		 
		try {
			System.out.println("11111111111111");
//		    Runtime.getRuntime().exec(command);
		    Process p = Runtime.getRuntime().exec(command);
		    p.waitFor();
			System.out.println("--------------");
		    
		//- ref : http://lowstar9.tistory.com/entry/%EC%9E%90%EB%B0%94%EC%97%90%EC%84%9C-window-batch-%ED%8C%8C%EC%9D%BC-%EC%8B%A4%ED%96%89%ED%95%98%EA%B8%B0
		 
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		//ref : http://www.codejava.net/java-se/file-io/execute-operating-system-commands-using-runtime-exec-methods
		
	}

}
