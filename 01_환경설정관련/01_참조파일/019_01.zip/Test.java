import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.math.Fraction;

import net.bramp.ffmpeg.FFmpeg;
import net.bramp.ffmpeg.FFmpegExecutor;
import net.bramp.ffmpeg.FFprobe;
import net.bramp.ffmpeg.builder.FFmpegBuilder;
import net.bramp.ffmpeg.probe.FFmpegFormat;
import net.bramp.ffmpeg.probe.FFmpegProbeResult;
import net.bramp.ffmpeg.probe.FFmpegStream;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ffmpegPath = "d:\\99_temp\\ffmpeg.exe";
		String ffprobePath = "d:\\ffprobe.exe";
//		String inVodPath = "d:\\컴백홈.mp4";
		String inVodPath = "d:\\99_temp\\2.mp4";
		String outVodName = "d:\\99_temp\\7";
		String outVodType = "flv";
		String imgFileName = "d:\\99_temp\\abcdefg.png";
		
		System.out.println("------- START -------");
		//git에서 소스를 받으면 xxxTest.java파일을 열어보면 샘플처럼 볼수 있다.
		//ex. ffmpeg-cli-wrapper\src\test\java\net\bramp\ffmpeg\builder\FFmpegBuilderTest.java
		
		//동영상정보
		//getFileInfo(ffprobePath,inVodPath);
		//동영상 인코딩
//		encoding(ffmpegPath, ffprobePath, inVodPath, outVodName, outVodType);
		//동영상 스냅샷
		snapshot(ffmpegPath, ffprobePath, inVodPath, imgFileName);
		System.out.println("------- END -------");
		
	}
	
	//동영상 스냅샷		70초 부분 프레임 한장 찍기
	public static void snapshot(String ffmpegPath, String ffprobePath, String inVodPath, String imgFileName){
		//ffmpeg -i 2.mp4 -an -vframes 1 -y %2d.png
		//ffmpeg -ss 00:10:00 -i 2.mp4 -an -vcodec png -vframes 1 -y %2d.png
		try{
			FFmpeg ffmpeg = new FFmpeg(ffmpegPath);
			FFprobe ffprobe = new FFprobe(ffprobePath);
			
			//첫프레임 한장 찍기
			FFmpegBuilder builder = new FFmpegBuilder()
					.setInput(inVodPath)
					  .overrideOutputFiles(true) // Override the output if it exists
					  .addOutput(imgFileName)
//					    .setDuration(20, TimeUnit.SECONDS)
					  	.disableAudio()
					  	.setStartOffset(70, TimeUnit.SECONDS)
					  	.setFrames(1)
					  	.done();

			FFmpegExecutor executor = new FFmpegExecutor(ffmpeg, ffprobe);
			// Run a one-pass encode
			executor.createJob(builder).run();
//			executor.createTwoPassJob(builder).run();
		}catch(Exception e){
			System.out.println("e:"+e);
		}
	}
	
	//동영상 스냅샷		첫프레임 한장 찍기
	public static void snapshot1(String ffmpegPath, String ffprobePath, String inVodPath, String imgFileName){
		//ffmpeg -i 2.mp4 -an -vframes 1 -y %2d.png
		//ffmpeg -ss 00:10:00 -i 2.mp4 -an -vcodec png -vframes 1 -y %2d.png
		try{
			FFmpeg ffmpeg = new FFmpeg(ffmpegPath);
			FFprobe ffprobe = new FFprobe(ffprobePath);
			
			//첫프레임 한장 찍기
			FFmpegBuilder builder = new FFmpegBuilder()
					.setInput(inVodPath)
					  .overrideOutputFiles(true) // Override the output if it exists
					  .addOutput("d:\\99_temp\\abcdefg.png")
					  	.disableAudio()
					  	.setFrames(1)
					  	.done();

			FFmpegExecutor executor = new FFmpegExecutor(ffmpeg, ffprobe);
			// Run a one-pass encode
			executor.createJob(builder).run();
//			executor.createTwoPassJob(builder).run();
		}catch(Exception e){
			System.out.println("e:"+e);
		}
	}
	
	//동영상 인코딩
	public static void encoding(String ffmpegPath, String ffprobePath, String inVodPath, String outVodName, String outVodType){
		try{
			FFmpeg ffmpeg = new FFmpeg(ffmpegPath);
			FFprobe ffprobe = new FFprobe(ffprobePath);

			FFmpegBuilder builder = new FFmpegBuilder()
			  .setInput(inVodPath)     // Filename, or a FFmpegProbeResult
			  .overrideOutputFiles(true) // Override the output if it exists

			  .addOutput(outVodName+"."+outVodType)   // Filename for the destination
			    .setFormat(outVodType)        // Format is inferred from filename, or can be set
				//에러 발생 : .setTargetSize(250_000)
//			    .setTargetSize(250_000)  // Aim for a 250KB file

			    .disableSubtitle()       // No subtiles

			    .setAudioChannels(1)         // Mono audio
			    .setAudioCodec("aac")        // using the aac codec
			    .setAudioSampleRate(48_000)  // at 48KHz
			    .setAudioBitRate(32768)      // at 32 kbit/s

			    .setVideoCodec("libx264")     // Video using x264
			    .setVideoFrameRate(24, 1)     // at 24 frames per second
			    .setVideoResolution(640, 480) // at 640x480 resolution

			    .setStrict(FFmpegBuilder.Strict.EXPERIMENTAL) // Allow FFmpeg to use experimental specs
			    .done();

			FFmpegExecutor executor = new FFmpegExecutor(ffmpeg, ffprobe);

			// Run a one-pass encode
			executor.createJob(builder).run();

			// Or run a two-pass encode (which is slower at the cost of better quality)
//			executor.createTwoPassJob(builder).run();
			
		}catch(Exception e){
			System.out.println("e:"+e);
		}
	}
	//동영상 정보.
	public static void getFileInfo(String ffprobePath, String inVodPath){
		try{
			//ffprobe.exe파일 위치
			FFprobe ffprobe = new FFprobe(ffprobePath);
			//동영상파일 위치
			FFmpegProbeResult probeResult = ffprobe.probe(inVodPath);

			FFmpegFormat format = probeResult.getFormat();
			System.out.format("%nFile: '%s' ; Format: '%s' ; Duration(재생시간): %.3fs", 
				format.filename, 
				format.format_long_name,
				format.duration
			);

			FFmpegStream stream = probeResult.getStreams().get(0);
			System.out.format("%nCodec: '%s' ; Width: %dpx ; Height: %dpx ; fps: ",
				stream.codec_long_name,
				stream.width,
				stream.height
			);
			
			System.out.println("------fps cal--------");
			float a = (float)stream.r_frame_rate.getNumerator() / (float)stream.r_frame_rate.getDenominator();
			System.out.println("-->stream.r_frame_rate.getNumerator() : " + stream.r_frame_rate.getNumerator());
			System.out.println("-->stream.r_frame_rate.getDenominator() : " + stream.r_frame_rate.getDenominator());
			String fps = String.format("%.2f", a);
			System.out.println("-->fps : " + fps);
			System.out.println(stream);
			
		}catch(Exception e){
			System.out.println("e:"+e);
		}
	}

}
