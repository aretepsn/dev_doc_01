package atesta;

public class Test2 {

	public static void main(String[] args) throws Exception{
		 
		// TODO Auto-generated method stub
		String cmd = "";
//		//동영상 정보추출
		cmd = "d:\\99_temp\\vod_info.bat";
		
		// TODO Auto-generated method stub
		Runtime runtime = Runtime.getRuntime();
		

		System.out.println("---------START----------");
		try{
			System.out.println("11111111111111");
//		    Runtime.getRuntime().exec(command);
		    Process p = Runtime.getRuntime().exec(cmd);
		    p.waitFor();
			System.out.println("--------------");
		}catch(Exception e){
			System.out.println("error:" + e.getMessage());
			e.printStackTrace();
		}
		System.out.println("---------END----------");
		
	}

}
