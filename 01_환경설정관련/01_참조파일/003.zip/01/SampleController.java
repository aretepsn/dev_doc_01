package ttlabc.cms.sample.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import ttlabc.cms.com.code.service.CodeComCodeNameService;
import ttlabc.cms.com.code.vo.CodeComCodeNameVO;

/**
 * 샘플 controller
 * @author aretett
 *
 */

@Controller
//@RequestMapping("/sample")
public class SampleController{
	
	@Resource(name = "com.code.service.codeComCodeNameService")
	private CodeComCodeNameService codeComCodeNameService;


	/**
	 * index
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "sample/index.do")
	public String sampleList() throws Exception {
		return "sample/sampleIndex";
	}	
	/**
	 * 프로토콜
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleProtocol.do")
	public String sampleProtocol() throws Exception {
		return "/sample/sampleProtocol";
	}	
	

	/**
	 * 공통코드 조회 : 자식코드 리스트 조회
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleChildCodeList.do")
	public String sampleChildCodeList(@ModelAttribute("searchVO") CodeComCodeNameVO VO, ModelMap model) throws Exception {
		if( VO.getParent_code() == null ){
			return "/sample/sampleCodeNameList";
		}
		//-- 공통코드 호출 -----------------------------
		List<?> selectChildCodeList = codeComCodeNameService.selectChildCodeList(VO);
		//----------------------------- 공통코드 호출 --
		
		model.addAttribute("searchVO", VO);
		model.addAttribute("resultList", selectChildCodeList);
		return "/sample/sampleCodeNameList";
	}	
	/**
	 * 공통코드 조회(ajax) : index
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleChildCodeListAjaxIndex.do")
	public String sampleChildCodeListAjaxIndex() throws Exception {
		return "/sample/sampleChildCodeListAjaxIndex";
	}	
	/**
	 * 공통코드 조회(ajax)
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleChildCodeListAjax.do")
	public ModelAndView selectSampleListAjax(@ModelAttribute("searchVO") CodeComCodeNameVO VO, ModelMap model) throws Exception {

		//-- 공통코드 호출 -----------------------------
		List<?> selectChildCodeList = codeComCodeNameService.selectChildCodeList(VO);
		//----------------------------- 공통코드 호출 --

		model.addAttribute("resultList", selectChildCodeList);
		
		Map resultMap = new HashMap();
		resultMap.put("result1", "11111");
		resultMap.put("result2", "22222");
		ModelAndView mav = new ModelAndView("jsonView");
		mav.addObject("resultList",selectChildCodeList);
		mav.addObject("resultMap", resultMap);
		return mav;
	}

	/**
	 * 첨부파일
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleFileUpload.do")
	public String sampleFileUpload() throws Exception {
		return "/sample/sampleFileUpload";
	}	
}
