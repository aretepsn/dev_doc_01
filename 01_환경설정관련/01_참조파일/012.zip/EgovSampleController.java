/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.example.sample.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.annotation.Id;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import egovframework.example.sample.service.SampleDefaultVO;

/**
 * @Class Name : EgovSampleController.java
 * @Description : EgovSample Controller Class
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2009.03.16           최초생성
 *
 * @author 개발프레임웍크 실행환경 개발팀
 * @since 2009. 03.16
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */

@Controller
public class EgovSampleController {

	//접속설정
    String mongoContextPath = "/egovframework/spring/context-mongodb.xml";
    AbstractApplicationContext ctx = new ClassPathXmlApplicationContext(mongoContextPath);

    private MongoTemplate mongoTemplate		= (MongoTemplate) ctx.getBean("mongoTemplate");
    private MongoOperations mongoOperation	=(MongoOperations) ctx.getBean("mongoTemplate");
    
	@RequestMapping(value = "/queryList.ajax")
	public ModelAndView queryList(@ModelAttribute("searchVO") SampleDefaultVO searchVO, ModelMap model) throws Exception {
        //-- 테이블 -------------------------------------------------------------------------
        String tableNm = "person";
        //------------------------------------------------------------------------- 테이블 --
        
        //-- where --------------------------------------------------------------------------
        String key = "address";
        String value = "고길동 집 1억년전 어딘가.1ddd..";
    	Criteria criteria = new Criteria(key);
    	criteria.is(value);
//    	Query query = new Query(criteria);
//    	Query query = new Query(Criteria.where("age").is(2).and("name").is("둘리---2"));
    	Query query = new Query();
    	query.addCriteria(Criteria.where("age").lt(2));
    	query.with(new Sort(Sort.Direction.DESC,"age"));
        //-------------------------------------------------------------------------- where --
    	
    	//-- 쿼리수행 ----------------------------------------------------------------------
    	List<MongoTestVO2> mongoTestVO = mongoTemplate.find(query, MongoTestVO2.class, tableNm);
    	//-- 쿼리수행 ----------------------------------------------------------------------
    	
    	//-- 데이타셋 담기 ----------------------------------------------------------------
    	System.out.println("----------------------------------------"+mongoTestVO);
		Map resultMap = new HashMap();
		resultMap.put("result", mongoTestVO);
		resultMap.put("result1", "11111");
		resultMap.put("result2", "22222");
		ModelAndView mav = new ModelAndView("jsonView",resultMap);
    	//---------------------------------------------------------------- 데이타셋 담기 --
		return mav;
	}    
	@RequestMapping(value = "/basicList.ajax")
	public ModelAndView basicList(@ModelAttribute("searchVO") SampleDefaultVO searchVO, ModelMap model) throws Exception {
		// manual-ref : https://docs.mongodb.com/manual/tutorial/query-embedded-documents/
        //-- 테이블 -------------------------------------------------------------------------
        String tableNm = "person";
        //------------------------------------------------------------------------- 테이블 --
        
        //-- where --------------------------------------------------------------------------
//        String where = "{age:{$lt:3},address:'고길동 집 1억년전 어딘가.1ddd..'}";
//      String where = "{'item.0.job':'홍길동동'}";
        String where = "{name:'둘리---0'}";
    	BasicQuery query = new BasicQuery(where);
//    	query.with(new Sort(Sort.Direction.DESC,"age"));		//age기준 sort
        //-------------------------------------------------------------------------- where --
    	
    	//-- 쿼리수행 ----------------------------------------------------------------------
    	List<MongoTestVO2> mongoTestVO = mongoOperation.find(query, MongoTestVO2.class, tableNm);
    	//-- 쿼리수행 ----------------------------------------------------------------------
    	
    	//-- 데이타셋 담기 ----------------------------------------------------------------
    	System.out.println("----------------------------------------"+mongoTestVO);
		Map resultMap = new HashMap();
		resultMap.put("result", mongoTestVO);
		resultMap.put("result1", "11111");
		resultMap.put("result2", "22222");
		ModelAndView mav = new ModelAndView("jsonView",resultMap);
    	//---------------------------------------------------------------- 데이타셋 담기 --
		return mav;
	}    
	@RequestMapping(value = "/basicJoin.ajax")
	public ModelAndView basicJoin(@ModelAttribute("searchVO") SampleDefaultVO searchVO, ModelMap model) throws Exception {
		// manual-ref : https://docs.mongodb.com/manual/tutorial/query-embedded-documents/
        //-- 테이블 -------------------------------------------------------------------------
        String tableNm = "person";
//        join테이블생성
//        db.person_join.insertMany( [
//                                  { age: '1', name:"둘리---0" },
//                                  { age: '2', name:"둘리---1" },
//                               ]);
        //------------------------------------------------------------------------- 테이블 --
        
        //-- where --------------------------------------------------------------------------
        tableNm="person_join";
        String where = "{name:'둘리---0'}";
    	BasicQuery query = new BasicQuery(where);
        //-------------------------------------------------------------------------- where --
    	//-- 쿼리수행 ----------------------------------------------------------------------
    	MongoTestVO2 getAge = mongoOperation.findOne(query, MongoTestVO2.class, tableNm);
    	//-- 쿼리수행 ----------------------------------------------------------------------

        //-- where --------------------------------------------------------------------------
        tableNm="person";
        where = "{age:" + getAge.getAge() + "}";
    	query = new BasicQuery(where);
        //-------------------------------------------------------------------------- where --
    	//-- 쿼리수행 ----------------------------------------------------------------------
    	List<MongoTestVO2> mongoTestVO = mongoOperation.find(query, MongoTestVO2.class, tableNm);
    	//-- 쿼리수행 ----------------------------------------------------------------------
    	
    	//-- 데이타셋 담기 ----------------------------------------------------------------
    	System.out.println("----------------------------------------"+mongoTestVO);
		Map resultMap = new HashMap();
		resultMap.put("result", mongoTestVO);
		resultMap.put("result1", "11111");
		resultMap.put("result2", "22222");
		ModelAndView mav = new ModelAndView("jsonView",resultMap);
    	//---------------------------------------------------------------- 데이타셋 담기 --
		return mav;
	}    
	
    
	@RequestMapping(value = "/queryGet.ajax")
	public ModelAndView queryGet(@ModelAttribute("searchVO") SampleDefaultVO searchVO, ModelMap model) throws Exception {
        //-- 테이블 -------------------------------------------------------------------------
        String tableNm = "person";
        //------------------------------------------------------------------------- 테이블 --
        
        //-- where --------------------------------------------------------------------------
        String key = "address";
        String value = "고길동 집 1억년전 어딘가.1ddd..";
    	Criteria criteria = new Criteria(key);
    	criteria.is(value);
    	Query query = new Query(criteria);
        //-------------------------------------------------------------------------- where --
    	
    	//-- 쿼리수행 ----------------------------------------------------------------------
    	MongoTestVO2 mongoTestVO = mongoTemplate.findOne(query, MongoTestVO2.class, tableNm);
    	//-- 쿼리수행 ----------------------------------------------------------------------
    	
    	//-- 데이타셋 담기 ----------------------------------------------------------------
    	System.out.println("----------------------------------------"+mongoTestVO);
		Map resultMap = new HashMap();
		resultMap.put("result", mongoTestVO);
		resultMap.put("result1", "11111");
		resultMap.put("result2", "22222");
		ModelAndView mav = new ModelAndView("jsonView",resultMap);
    	//---------------------------------------------------------------- 데이타셋 담기 --
		return mav;
	}
	
    private class MongoTestVO2 {
    	//생성자가 없으면 find시 에러발생
    	public MongoTestVO2(){}
        // 반드시 id annotation이 붙은 id 변수가 필요!
        @Id
        private String id;
        private String name;
        private String address;
        private int age;
        private Object item;
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public Object getItem() {
			return item;
		}
		public void setItem(Object item) {
			this.item = item;
		}
    	
    }
	
}
