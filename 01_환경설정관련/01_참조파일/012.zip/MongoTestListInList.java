package egovframework.example.sample.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;


public class MongoTestListInList {
    private MongoTemplate mongoTemplate;
    private MongoOperations mongoOperation;
	 
	    public MongoTestListInList() {
	        String mongoContextPath = "/egovframework/spring/context-mongodb.xml";
	        AbstractApplicationContext ctx = new ClassPathXmlApplicationContext(mongoContextPath);
	        mongoTemplate = (MongoTemplate) ctx.getBean("mongoTemplate");
	        mongoOperation =(MongoOperations) ctx.getBean("mongoTemplate");
	    }
	 
	    public static void main(String[] args) {
	        MongoTestListInList mongoTest = new MongoTestListInList();
	        System.out.println("----start------");
	        //테이블생성/ 데이타 입력
	        for(int i=0 ; i<5 ; i++){
	        	mongoTest.insertTestData("둘리---"+i,"고길동 집 1억년전 어딘가.1ddd..", i);
	        }
	        mongoTest.findOne("name","둘리---2");				//조회
	    }
	    

	    //findOne
	    private void findOne(String key, String value){
	    	Criteria criteria = new Criteria(key);
	    	criteria.is(value);
	    	Query query = new Query(criteria);
//	    	MongoTestVO2 mongoTestVO = mongoTemplate.findOne(query, MongoTestVO2.class, "person");
	    	List<MongoTestVO2> mongoTestVOList = mongoTemplate.find(query, MongoTestVO2.class, "person");
	    	System.out.println("----------------------------------------"+mongoTestVOList);
//	    	output(mongoTestVO2);
	    }

	    //출력
	    private void output(MongoTestVO mongoTestVO){
	    	if(mongoTestVO == null) {
	    		System.out.println("DATA 없음");
	    		return;
	    	}
	    	System.out.println("ID----------->" + mongoTestVO.getId());
	    	System.out.println("NAME----------->" + mongoTestVO.getName());
	    	System.out.println("ADDRESS----------->" + mongoTestVO.getAddress());
	    }
	    //insert
	    private void insertTestData(String name, String value, int age) {
	        MongoTestVO testVO = new MongoTestVO();
	        List<MongoTestItemVO> itemList = new ArrayList();
	        testVO.setName(name);
	        testVO.setAddress(value);
	        testVO.setAge(age);
	        MongoTestItemVO item;
	        for(int i=0;i<5;i++){
	        	item = new MongoTestItemVO();
		        item.setJob("변호사---"+i);
		        item.setJob_name("의사---"+i);
		        itemList.add(item);
	        }
	        testVO.setItem(itemList);
	        // testVO에 있는 내용을 "person" Collection에 넣겠다.
	        mongoTemplate.insert(testVO, "person");
	    }

	    private class MongoTestItemVO {
	    	public MongoTestItemVO(){}
	    	private String job;
	    	private String job_name;
			public String getJob() {
				return job;
			}
			public void setJob(String job) {
				this.job = job;
			}
			public String getJob_name() {
				return job_name;
			}
			public void setJob_name(String job_name) {
				this.job_name = job_name;
			}
	    }
	    private class MongoTestVO {
	    	//생성자가 없으면 find시 에러발생
	    	public MongoTestVO(){}
	        // 반드시 id annotation이 붙은 id 변수가 필요!
	        @Id
	        private String id;
	        private String name;
	        private String address;
	        private int age;
	        private List<MongoTestItemVO> item;
	        
			public List<MongoTestItemVO> getItem() {
				return item;
			}
			public void setItem(List<MongoTestItemVO> item) {
				this.item = item;
			}
			public int getAge() {
				return age;
			}
			public void setAge(int age) {
				this.age = age;
			}
			public String getId() {
				return id;
			}
			public void setId(String id) {
				this.id = id;
			}
			public String getName() {
	            return name;
	        }
	        public void setName(String name) {
	            this.name = name;
	        }
	        public String getAddress() {
	            return address;
	        }
	        public void setAddress(String address) {
	            this.address = address;
	        }
	 
	    }
	    private class MongoTestVO2 {
	    	//생성자가 없으면 find시 에러발생
	    	public MongoTestVO2(){}
	        // 반드시 id annotation이 붙은 id 변수가 필요!
	        @Id
	        private String id;
	        private String name;
	        private String address;
	        private int age;
	        private Object item;
			public String getId() {
				return id;
			}
			public void setId(String id) {
				this.id = id;
			}
			public String getName() {
				return name;
			}
			public void setName(String name) {
				this.name = name;
			}
			public String getAddress() {
				return address;
			}
			public void setAddress(String address) {
				this.address = address;
			}
			public int getAge() {
				return age;
			}
			public void setAge(int age) {
				this.age = age;
			}
			public Object getItem() {
				return item;
			}
			public void setItem(Object item) {
				this.item = item;
			}
	        
	    }
	}



