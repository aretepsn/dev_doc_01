package ttlabc.cms.sample.web;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import ttlabc.cms.com.ExcelRead;
import ttlabc.cms.com.ExcelReadOption;
import ttlabc.cms.com.code.service.CodeComCodeNameService;
import ttlabc.cms.com.code.vo.CodeComCodeNameVO;
import ttlabc.cms.com.fileupload.service.FileUploadService;
import ttlabc.cms.com.web.ComMainController;
import ttlabc.cms.sample.board.vo.BoardVO;
import ttlabc.cms.sample.vo.SampleFileuploadVO;

/**
 * 샘플 controller
 * @author aretett
 *
 */

@Controller
//@RequestMapping("/sample")
public class SampleController extends ComMainController{
	
	private static final Logger logger = LoggerFactory.getLogger(SampleController.class);
		
	@Resource(name = "com.code.service.codeComCodeNameService")
	private CodeComCodeNameService codeComCodeNameService;

	@Resource(name = "com.fileupload.service.fileUploadService")
	private FileUploadService fileUploadService;

	/**
	 * index
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "sample/index.do")
	public String sampleList() throws Exception {
		return "sample/sampleIndex";
	}	
	/**
	 * 개발규약
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleProtocol.do")
	public String sampleProtocol() throws Exception {
		return "/sample/sampleProtocol";
	}	
	/**
	 * JSP 메세지 정의
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleMessage.do")
	public String sampleMessage(Locale locale) throws Exception {
		logger.info("common.search : {}"		, getMessage("common.search"		, null, locale)	);
		logger.info("fail.common.sql222 : {}"	, getMessage("fail.common.sql222"	, new String[] {"첫번째1","두번째2"}, locale)	);
		logger.info("fail.common.sql : {}"		, getMessage("fail.common.sql"		, new String[] {"첫번째1","두번째2"}, locale)	);
		
		return "/sample/sampleMessage";
	}	
	/**
	 * 자바스크립트 공통추출요망.
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleJavascript.do")
	public String sampleJavascript(Locale locale) throws Exception {
		return "/sample/sampleJavascript";
	}	
	

	/**
	 * 공통코드 조회 : 자식코드 리스트 조회
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleChildCodeList.do")
	public String sampleChildCodeList(@ModelAttribute("searchVO") CodeComCodeNameVO VO, ModelMap model) throws Exception {
		if( VO.getParent_code() == null ){
			return "/sample/sampleCodeNameList";
		}
		//-- 공통코드 호출 -----------------------------
		List<?> selectChildCodeList = codeComCodeNameService.selectCodeList(VO);
		//----------------------------- 공통코드 호출 --
		
		model.addAttribute("searchVO", VO);
		model.addAttribute("resultList", selectChildCodeList);
		return "/sample/sampleCodeNameList";
	}	
	/**
	 * 공통코드 조회(ajax) : index
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleChildCodeListAjaxIndex.do")
	public String sampleChildCodeListAjaxIndex() throws Exception {
		return "/sample/sampleChildCodeListAjaxIndex";
	}	
	/**
	 * 공통코드 조회(ajax)
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleChildCodeListAjax.do")
	public ModelAndView selectSampleListAjax(@ModelAttribute("searchVO") CodeComCodeNameVO VO, ModelMap model) throws Exception {

		//-- 공통코드 호출 -----------------------------
		List<?> selectChildCodeList = codeComCodeNameService.selectCodeList(VO);
		//----------------------------- 공통코드 호출 --

		model.addAttribute("resultList", selectChildCodeList);
		
		Map resultMap = new HashMap();
		resultMap.put("result1", "11111");
		resultMap.put("result2", "22222");
		ModelAndView mav = new ModelAndView("jsonView");
		mav.addObject("resultList",selectChildCodeList);
		mav.addObject("resultMap", resultMap);
		return mav;
	}

	/**
	 * 첨부파일 : index
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleFileUpload.do")
	public String sampleFileUpload() throws Exception {
		return "/sample/sampleFileUpload";
	}	
	/**
	 * 첨부파일 : 저장
	 * @param VO
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/sample/sampleFileUploadInsert.do")
	public String sampleFileUploadSave(@ModelAttribute("searchVO") SampleFileuploadVO VO, ModelMap model) throws Exception {
		logger.info("VO.getMemo() : " + VO.getMemo() );
		//-- 첨부파일 저장 -----------------------------------------------------------
		String fileId = fileUploadService.insUpdateFileMediaList(VO.getFileUploadMediaVO());
		//----------------------------------------------------------- 첨부파일 저장 --
		logger.info("file_id : " + fileId);
		return "/sample/sampleFileUpload";
	}

	@RequestMapping(value = "/sample/xls.do")
	public void sampleXls() throws Exception {
		 
        File destFile = new File("D:/abc.xlsx");
        ExcelReadOption readOption = new ExcelReadOption();
	  readOption.setFilePath(destFile.getAbsolutePath());
	  readOption.setOutputColumns("A","B","C","D");
	  readOption.setStartRow(2);
	  
	  List<Map<String, String>> excelContent = ExcelRead.read(readOption);
	  
	  for(Map<String, String> article : excelContent){
		   System.out.println(article.get("A"));
		   System.out.println(article.get("B"));
		   System.out.println(article.get("C"));
		   System.out.println(article.get("D"));
	  }
	}
}
