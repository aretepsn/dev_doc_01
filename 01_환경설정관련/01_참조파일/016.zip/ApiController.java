package ttlabc.api.web;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import egovframework.example.sample.service.impl.EgovSampleServiceImpl;
import egovframework.rte.fdl.property.EgovPropertyService;
import ttlabc.api.com.util.Common;
import ttlabc.api.exception.ManagedException;
import ttlabc.api.exception.ManagedExceptionCode;
import ttlabc.api.service.AppinfoService;
import ttlabc.api.service.CategorylistService;
import ttlabc.api.service.ChannelContentsAllService;
import ttlabc.api.service.ChannelContentsService;
import ttlabc.api.service.ChannelProgramService;
import ttlabc.api.service.ContentslistService;
import ttlabc.api.service.FwService;
import ttlabc.api.service.MediadownlistService;
import ttlabc.api.service.NoticeService;
import ttlabc.api.service.NoticeboardService;
import ttlabc.api.service.SvcinfoService;
import ttlabc.api.service.WeatherService;
import ttlabc.api.util.ApiConvert;
import ttlabc.api.util.CommonConstants;
import ttlabc.api.util.StaticFunc;
import ttlabc.api.vo.ResultFwVO;
import ttlabc.api.vo.SearchAppinfoVO;
import ttlabc.api.vo.SearchCategorylistVO;
import ttlabc.api.vo.SearchChannelContentsAllVO;
import ttlabc.api.vo.SearchChannelContentsVO;
import ttlabc.api.vo.SearchChannelProgramVO;
import ttlabc.api.vo.SearchContentslistVO;
import ttlabc.api.vo.SearchFwVO;
import ttlabc.api.vo.SearchNoticeVO;
import ttlabc.api.vo.SearchNoticeboardVO;
import ttlabc.api.vo.SearchSvcinfoVO;
import ttlabc.api.vo.SearchWeatherVO;

/**
 * 
 * @author aretett
 */

@Controller
//@RequestMapping("/api")
public class ApiController{

	@Resource(name = "appinfoService")
	private AppinfoService appinfoService;

	@Resource(name = "svcinfoService")
	private SvcinfoService svcinfoService;

	@Resource(name = "categorylistService")
	private CategorylistService categorylistService;

	@Resource(name = "channelContentsAllService")
	private ChannelContentsAllService channelContentsAllService;

	@Resource(name = "contentslistService")
	private ContentslistService contentslistService;

	@Resource(name = "channelContentsService")
	private ChannelContentsService channelContentsService;

	@Resource(name = "channelProgramService")
	private ChannelProgramService channelProgramService;

	@Resource(name = "noticeService")
	private NoticeService noticeService;

	@Resource(name = "noticeboardService")
	private NoticeboardService noticeboardService;
	
	@Resource(name = "weatherService")
	private WeatherService weatherService;
	
	@Resource(name = "fwService")
	private FwService fwService;
	
	@Resource(name = "mediadownlistService")
	private MediadownlistService mediadownlistService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EgovSampleServiceImpl.class);
	
	/**
	 * 
	 * @param searchVO ( 필수값 : svcId or mac )
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/appinfo")
//	@SuppressWarnings("unchecked")
	public ModelAndView appinfo(@ModelAttribute("searchVO") SearchAppinfoVO searchVO,ModelMap model) throws Exception {

		List<?> getBaseInfo = appinfoService.getBaseInfo(searchVO);
		LOGGER.debug("--->"+getBaseInfo.size());
		
		if( getBaseInfo.size() <1 ){
			throw new ManagedException(ManagedExceptionCode.NotExistSvc, CommonConstants.DEFAULT_FG_LANG);
			
		}else{
			Map<?,?> getSvcInfoMap = (HashMap<?,?>)getBaseInfo.get(0);
			
			List<?> appList = appinfoService.selectAppList(getSvcInfoMap.get("launcherId"));

			Map<String, Object> tempMap = new LinkedHashMap<String, Object>();
			tempMap.put("svcid"				, getSvcInfoMap.get("svcId"));
			tempMap.put("service_no"			, getSvcInfoMap.get("launcherId"));
			tempMap.put("service_type"		, "");
			tempMap.put("api_service_url"	, getSvcInfoMap.get("apiDomainUrl"));
			tempMap.put("toggle"				, "Y");
			tempMap.put("opts"				, "");
			tempMap.put("app_info", appList);
			
			Map<String, Object> resultMap = ApiConvert.convertAll(tempMap);
			ModelAndView mav = new ModelAndView("jsonView",resultMap);
			return mav;
		}
	}


	/**
	 * 
	 * @param searchVO ( 필수값 : svcId )
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/svcinfo")
	public ModelAndView svcinfo(@ModelAttribute("searchVO") SearchSvcinfoVO searchVO,ModelMap model) throws Exception {

		if( searchVO.getSvcId().equals("") ){
			throw new ManagedException(ManagedExceptionCode.NotExistSvc, CommonConstants.DEFAULT_FG_LANG);
			
		}else{
			List<?> getBaseInfo = svcinfoService.getBaseInfo(searchVO);
			Map getBaseInfoMap = (HashMap)getBaseInfo.get(0);
			
			searchVO.setLauncherId( (String)getBaseInfoMap.get("launcher_id") );
			List<?> itemInfoList = svcinfoService.selectItemsInfo(searchVO);
			List<?> channelInfoList = svcinfoService.selectChannelInfo(searchVO);
			
			Map tempMap = new LinkedHashMap<String, Object>();
			tempMap.put("url_logo"						, getBaseInfoMap.get("url_logo"));
			tempMap.put("url_bg_main"					, getBaseInfoMap.get("url_bg_main"));
			tempMap.put("url_bg_content"				, getBaseInfoMap.get("url_bg_content"));
			tempMap.put("url_content_load"				, getBaseInfoMap.get("url_content_load"));
			tempMap.put("url_content_watermark"		, getBaseInfoMap.get("url_content_watermark"));
			tempMap.put("menu_type"						, getBaseInfoMap.get("menu_type"));
			tempMap.put("content_watermark_loc"		, getBaseInfoMap.get("content_watermark_loc"));
			tempMap.put("items_info"						, itemInfoList);
			tempMap.put("channels_info"					, channelInfoList);
			
			Map resultMap = ApiConvert.convertAll(tempMap);
			ModelAndView mav = new ModelAndView("jsonView",resultMap);
			return mav;
			
		}
	}
	
	@RequestMapping("/categorylist")
	public ModelAndView categorylist(@ModelAttribute("searchVO") SearchCategorylistVO searchVO,ModelMap model) throws Exception {
		if( StaticFunc.emptyStr(searchVO.getItemId())) {
			throw new ManagedException(ManagedExceptionCode.NotExistSvc, CommonConstants.DEFAULT_FG_LANG);
			
		}else{
			List<?> getBaseInfo = categorylistService.getBaseInfo(searchVO);

			List<?> itemInfoList = categorylistService.selectItemsInfo(searchVO);
			
			Map getBaseInfoMap = (HashMap)getBaseInfo.get(0);
			Map tempMap = new LinkedHashMap<String, Object>();
			tempMap.put("url_bg"					, getBaseInfoMap.get("url_bg"));
			tempMap.put("item_id"					, getBaseInfoMap.get("item_id"));
			tempMap.put("columns"				, getBaseInfoMap.get("columns"));
			tempMap.put("rows"					, getBaseInfoMap.get("rows"));
			tempMap.put("items"					, itemInfoList);
			
			
			Map resultMap = ApiConvert.convertAll(tempMap);
			ModelAndView mav = new ModelAndView("jsonView",resultMap);
			return mav;
		}
	}
	
	@RequestMapping("/contentslist")
	public ModelAndView contentslist(@ModelAttribute("searchVO") SearchContentslistVO searchVO,ModelMap model) throws Exception {
		if( StaticFunc.emptyStr(searchVO.getItemId())) {
			throw new ManagedException(ManagedExceptionCode.NotExistSvc, CommonConstants.DEFAULT_FG_LANG);
			
		}else{
			List<?> getBaseInfo = contentslistService.getBaseInfo(searchVO);
			List<?> itemList = contentslistService.selectItemList(searchVO);
			
			Map getBaseInfoMap = (HashMap)getBaseInfo.get(0);
			Map tempMap = new LinkedHashMap<String, Object>();
			tempMap.put("url_bg"					, getBaseInfoMap.get("url_bg"));
			tempMap.put("page_no"				, getBaseInfoMap.get("page_no"));
			tempMap.put("page_count"			, getBaseInfoMap.get("page_count"));
			tempMap.put("items"					, itemList);
			
			Map resultMap = ApiConvert.convertAll(tempMap);
			ModelAndView mav = new ModelAndView("jsonView",resultMap);
			return mav;
		}
	}
	
	@RequestMapping("/channel/program")
	public ModelAndView channelProgram(@ModelAttribute("searchVO") SearchChannelProgramVO searchVO,ModelMap model) throws Exception {
		if( StaticFunc.emptyStr(searchVO.getChannelId())) {
			throw new ManagedException(ManagedExceptionCode.NotExistSvc, CommonConstants.DEFAULT_FG_LANG);
			
		}else{
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat fdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String strCal = fdf.format(cal.getTime());
			searchVO.setDateTime(strCal);
			
			// channel/contents와 동일한 결과를 가져옴.
			//컨텐츠정보
			List<?> getBaseInfo = channelProgramService.getBaseInfo(searchVO);
			Map getBaseInfoMap = (HashMap)getBaseInfo.get(0);
			Map tempMap = new LinkedHashMap<String, Object>();
			tempMap.put("id"							, getBaseInfoMap.get("program_id"));
			tempMap.put("name"						, getBaseInfoMap.get("program_nm"));
			tempMap.put("start_time"					, getBaseInfoMap.get("program_start_dt"));
			tempMap.put("end_time"					, getBaseInfoMap.get("program_end_dt"));
			tempMap.put("now"						, getBaseInfoMap.get("now"));
			tempMap.put("duration"					 ,getBaseInfoMap.get("program_duration"));
			tempMap.put("play_index"					, getBaseInfoMap.get("play_index"));
			tempMap.put("seek_to"						, getBaseInfoMap.get("seek_to"));
			Map tempMap2 = new LinkedHashMap<String, Object>();
				tempMap2.put("media_type"					, getBaseInfoMap.get("media_type"));
				tempMap2.put("media_name"					, getBaseInfoMap.get("media_nm"));
				tempMap2.put("media_url"						, getBaseInfoMap.get("media_file"));
				tempMap2.put("start_time"						, getBaseInfoMap.get("media_start_dt"));
				tempMap2.put("end_time"						, getBaseInfoMap.get("media_end_dt"));
				tempMap2.put("duration"						, getBaseInfoMap.get("media_play_time"));
				tempMap2.put("play_start"						, getBaseInfoMap.get("play_start"));
				tempMap2.put("play_end"						, getBaseInfoMap.get("play_end"));
				tempMap2.put("url_thumbnail"				, getBaseInfoMap.get("thumbnail_file"));
				tempMap2.put("imgs"							, getBaseInfoMap.get("imgs"));
			tempMap.put("contents"					, tempMap2);
			
			Map resultMap = ApiConvert.convertAll(tempMap);
			ModelAndView mav = new ModelAndView("jsonView",resultMap);
			return mav;
		}
	}

	/**
	 * @param model ( 필수값 : svcId, channelId )
	 * 특정 channelId에 현재시간에 방영중인 컨텐츠(한개) 항목 가져오기 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/channel/contents")
	public ModelAndView channelContents(@ModelAttribute("searchVO") SearchChannelContentsVO searchVO,ModelMap model) throws Exception {
		if( StaticFunc.emptyStr(searchVO.getChannelId())) {
			throw new ManagedException(ManagedExceptionCode.NotExistSvc, CommonConstants.DEFAULT_FG_LANG);
			
		}else{
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat fdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String strCal = fdf.format(cal.getTime());
			searchVO.setDateTime(strCal);

			//컨텐츠정보
			List<?> mediaInfo = channelContentsService.getContents(searchVO);
			
			Map resultMap = ApiConvert.convertAll(mediaInfo);
			ModelAndView mav = new ModelAndView("jsonView",resultMap);
			return mav;
		}
	}

	/**
	 * @param model ( 필수값 : svcId )
	 * 모든 채널의 방송프로그램정보 리스트 가져오기
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/channel/contents/all")
	public ModelAndView channelContentsAll(@ModelAttribute("searchVO") SearchChannelContentsAllVO searchVO,ModelMap model) throws Exception {
		if( StaticFunc.emptyStr(searchVO.getSvcId())) {
			throw new ManagedException(ManagedExceptionCode.NotExistSvc, CommonConstants.DEFAULT_FG_LANG);
			
		}else{
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat fdf = new SimpleDateFormat("yyyyMMdd");
			String strCal = fdf.format(cal.getTime());
			LOGGER.debug("debug strCal:"+strCal);
			searchVO.setDateTime(strCal);


			List<Object> resultList = new ArrayList<Object>();
			Map tempMap;
			
			//채널정보
			List<?> channelList = channelContentsAllService.selectChannelList(searchVO);
			Map channelListMap;
			//프로그램정보
			for(int i=0 ; i < channelList.size() ; i++){
				channelListMap = (HashMap)channelList.get(i);
				searchVO.setParamChannelId( (String)channelListMap.get("id") );
				List<?> programList = channelContentsAllService.selectProgramList(searchVO);
				//한개의 채널정보에 여러개의 프로그램정보를 담는다.
				tempMap	=	new LinkedHashMap<String, Object>();
				tempMap.put("id"					, channelListMap.get("id") );
				tempMap.put("name"				, channelListMap.get("name") );
				tempMap.put("channel_no"		, channelListMap.get("channel_no") );
				tempMap.put("url_channel_logo"	, channelListMap.get("url_channel_logo") );
				tempMap.put("start_time"			, channelListMap.get("start_time") );
				tempMap.put("end_time"			, channelListMap.get("end_time") );
				tempMap.put("schedules"			, programList );
				resultList.add(tempMap);
			}
			Map resultMap = ApiConvert.convertAll(resultList);
			ModelAndView mav = new ModelAndView("jsonView",resultMap);
			return mav;
		}
	}
	
	/**
	 * 
	 * @param searchVO ( 필수값 : svcId )
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/notice")
	public ModelAndView notice(@ModelAttribute("searchVO") SearchNoticeVO searchVO,ModelMap model) throws Exception {

		if (StaticFunc.emptyStr(searchVO.getSvcId())) {
			throw new ManagedException(ManagedExceptionCode.InvalidParameter, CommonConstants.DEFAULT_FG_LANG);
			
		} else {
			//baseInfo
			List<?> getBaseInfo = noticeService.getBaseInfo(searchVO);
			Map getBaseInfoMap = (HashMap)getBaseInfo.get(0);
			//공지사항
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat fdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String strCal = fdf.format(cal.getTime());
			searchVO.setDateTime(strCal);
			List<?> noticesList = noticeService.selectNoticeList(searchVO);
			
			Map tempMap = new LinkedHashMap<String, Object>();
			tempMap.put("url_bg_notice"			, getBaseInfoMap.get("url_bg_notice"));
			tempMap.put("duration"				, getBaseInfoMap.get("duration"));
			tempMap.put("notices"					, noticesList);
			
			Map resultMap = ApiConvert.convertAll(tempMap);
			ModelAndView mav = new ModelAndView("jsonView",resultMap);
			return mav;
		}
	}

	/**
	 * @param model ( 필수값 : svcId )
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/noticeboard")
	public ModelAndView noticeboard(@ModelAttribute("searchVO") SearchNoticeboardVO searchVO,ModelMap model) throws Exception {
		// TODO arete [확인요망] : 사용안하는듯함. (tb_noti_board 테이블에 데이타 없음.)
		if( StaticFunc.emptyStr(searchVO.getSvcId())) {
			throw new ManagedException(ManagedExceptionCode.NotExistSvc, CommonConstants.DEFAULT_FG_LANG);
			
		}else{
			Calendar cal = Calendar.getInstance();
			SimpleDateFormat fdf = new SimpleDateFormat("yyyyMMddHHmmss");
			String strCal = fdf.format(cal.getTime());
			LOGGER.debug("debug strCal:"+strCal);
			searchVO.setDateTime(strCal);
			
//			List<?> noticeboardList = noticeboardService.selectNoticeboardList(searchVO);

			Map tempMap = new LinkedHashMap<String, Object>();
			tempMap.put("COMMENT"			, "개발예정(클라이언트에서도 구현?)");
			
			Map resultMap = ApiConvert.convertAll(tempMap);
			ModelAndView mav = new ModelAndView("jsonView",resultMap);
			return mav;
		}
	}
	

	/**
	 * @param model ( 필수값 : svcId )
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/weather")
	public ModelAndView weather(@ModelAttribute("searchVO") SearchWeatherVO searchVO,ModelMap model) throws Exception {

		if( StaticFunc.emptyStr(searchVO.getSvcId())) {
			throw new ManagedException(ManagedExceptionCode.NotExistSvc, CommonConstants.DEFAULT_FG_LANG);
			
		}else{
			List<?> weatheList = weatherService.selectWeatherList(searchVO);
			Map tempMap = new LinkedHashMap<String, Object>();
			tempMap.put("weather_info",	weatheList);
			
			Map resultMap = ApiConvert.convertAll(tempMap);
			ModelAndView mav = new ModelAndView("jsonView",resultMap);
			return mav;
		}
	}
	
	/**
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@Autowired
	EgovPropertyService propertiesService;
	@RequestMapping(value="/fw",method=RequestMethod.POST)
	public ModelAndView fw(
			@RequestHeader(value="mac"		,defaultValue="empty") String headerMac,
			@ModelAttribute("apiSearchVO") SearchFwVO searchVO,
			HttpServletRequest request,
			ModelMap modelMap) throws Exception {

		String aaa1 = propertiesService.getString("Globals.UserName");
		
		// 필수파라미터 체크
		if( searchVO.getMac() == null || searchVO.getModel() ==null || searchVO.getVer() == null){
			return ApiConvert.error("3100");
		}
//		System.out.println(request.getHeader("host") );
//		searchVO.setIp( request.getRemoteAddr() );
		String reqIp = Common.getRemoteIp(request);
		searchVO.setIp( reqIp +" headerMac : " + headerMac );
		
		List<?> getStbInfo = fwService.getFwInfo(searchVO);
		if( getStbInfo.size() <1 ){
			return ApiConvert.error("1100");
		}

		ResultFwVO resultFwVO = (ResultFwVO)getStbInfo.get(0);
		
		Map<String, Object> tempMap = new LinkedHashMap<String, Object>();
		tempMap.put("upgrade"			, resultFwVO.getUpgrade());
		tempMap.put("ver"					, resultFwVO.getVer());
		tempMap.put("state"				, resultFwVO.getState());
		tempMap.put("url"					, resultFwVO.getUrl());
		tempMap.put("auto"				, resultFwVO.getAuto());
		
		Map<String, Object> resultMap = ApiConvert.convertAll(tempMap);
		ModelAndView mav = new ModelAndView("jsonView",resultMap);
		

		fwService.insertFwLog(searchVO);		//mac 로그 기록
		return mav;
	}
	
	/**
	 * 미디어파일 다운로드 목록 조회
	 * @param 파라미터값 없음.
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/mediadownlist")
	public ModelAndView mediadownlist(ModelMap model) throws Exception {
		List<?> mediaDownList = mediadownlistService.selectMediaDownList();

		Map tempMap = new LinkedHashMap<String, Object>();
		tempMap.put("count"				, mediaDownList.size());
		tempMap.put("mediaFiles"			, mediaDownList);
		
		Map resultMap = ApiConvert.convertAll(tempMap);
		ModelAndView mav = new ModelAndView("jsonView",resultMap);
		return mav;
	}

}
