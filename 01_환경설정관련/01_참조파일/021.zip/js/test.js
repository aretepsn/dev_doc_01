
/**
 * 테스트임둥
 * @class 클래스명11
 * @param param1 : 파라미터입니다.
 * @param param2 : 두번째 파라미터입니다.
 * @returns {String}
 */
function test_abc(param1, param2){
	param1= param1 + "+" + param2;
	return param1;
}

/**
 * 테스트임둥
 * @class 클래스명1
 * @param param1 : 파라미터입니다.11
 * @param param2 : 두번째 파라미터입니다.
 * @returns {String}
 */
function test_abc2(param1, param2){
	param1= param1 + "+" + param2;
	return param1;
}

/**
 * 테스트파일임둥.
 * @class 클래스명2
 * @param aabb
 * @returns
 */
function aaa(aabb){
	return aabb;
}