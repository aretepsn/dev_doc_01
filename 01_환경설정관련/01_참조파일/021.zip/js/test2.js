/**
 * test2
 * @class 
 */

/**
 * 테스트임둥
 * @class 클래스명1
 * @param param1 : 파라미터입니다.
 * @param param2 : 두번째 파라미터입니다.
 * @returns {String}
 * @global ss.aa
 */
function test2_abc(param1, param2){
	param1= param1 + "+" + param2;
	return param1;
}

/**
 * 테스트임둥
 * @class 클래스명1
 * @param param1 : 파라미터입니다.
 * @param param2 : 두번째 파라미터입니다.
 * @see test2_abc2
 * @returns {String}
 * @global ss.bb
 */
function test2_abc2(param1, param2){
	param1= param1 + "+" + param2;
	return param1;
}

/**
 * 테스트파일임둥.
 * @class 클래스명2
 * @param aabb
 * @returns {String}
 * @see test2_abc2함수와 유사함.
 * @see test2_abc 함수와 유사함.
 * @constructor constructor항목
 * @type type항목
 * @global ss.aa
 */
function test2_aaa(aabb){
	return aabb;
}